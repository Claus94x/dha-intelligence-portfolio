﻿#Requires -Version 5.1
<#
.SYNOPSIS
    DHA Intelligence v1 â€” Setup completo su Windows Server
.DESCRIPTION
    Installa Python, dipendenze, ODBC Driver, registra il servizio Windows
    e configura il firewall. Eseguire con privilegi elevati.
.NOTES
    Testato su Windows Server 2019 / 2022
    Eseguire dalla cartella radice del progetto:
        Set-Location "C:\DHA\nuovo sito"
        .\deploy\setup_windows_server.ps1
#>

param(
    [string]$AppDir     = (Split-Path $PSScriptRoot -Parent),
    [string]$ServiceName = "DHA-Intelligence",
    [string]$Port        = "8000",
    [string]$PythonMinVersion = "3.11"
)

$ErrorActionPreference = "Stop"
$ProgressPreference    = "SilentlyContinue"

# â”€â”€ Colori helper â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function Write-Step  { param($msg) Write-Host "`n>>> $msg" -ForegroundColor Cyan }
function Write-OK    { param($msg) Write-Host "    [OK] $msg"    -ForegroundColor Green }
function Write-Warn  { param($msg) Write-Host "    [!!] $msg"    -ForegroundColor Yellow }
function Write-Fail  { param($msg) Write-Host "    [XX] $msg"    -ForegroundColor Red; exit 1 }

Write-Host ""
Write-Host "  â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ•—  â–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—  Intelligence v1" -ForegroundColor Blue
Write-Host "  Setup Windows Server" -ForegroundColor Blue
Write-Host ""

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 1 â€” Verifica cartella progetto
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Verifica cartella progetto"

if (-not (Test-Path "$AppDir\backend\main.py")) {
    Write-Fail "backend\main.py non trovato in '$AppDir'. Eseguire dalla cartella radice del progetto."
}
Write-OK "Cartella progetto: $AppDir"

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 2 â€” Verifica / Installazione Python
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Verifica Python $PythonMinVersion+"

$python = $null
foreach ($cmd in @("python", "python3", "py")) {
    try {
        $ver = & $cmd --version 2>&1
        if ($ver -match "Python (\d+\.\d+)") {
            $found = [version]$Matches[1]
            if ($found -ge [version]$PythonMinVersion) {
                $python = $cmd
                Write-OK "Python trovato: $ver  ($cmd)"
                break
            }
        }
    } catch {}
}

if (-not $python) {
    Write-Warn "Python $PythonMinVersion+ non trovato. Download in corso..."
    $pyUrl  = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
    $pyInst = "$env:TEMP\python-installer.exe"
    Invoke-WebRequest -Uri $pyUrl -OutFile $pyInst
    Write-Host "    Avvio installer Python (segui le istruzioni, seleziona 'Add to PATH')..." -ForegroundColor Yellow
    Start-Process -FilePath $pyInst -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 Include_pip=1" -Wait
    Remove-Item $pyInst -Force
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    $python = "python"
    Write-OK "Python installato."
}

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 3 â€” Crea Virtual Environment
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Creazione Virtual Environment"

$venvDir = "$AppDir\.venv"
if (-not (Test-Path "$venvDir\Scripts\python.exe")) {
    & $python -m venv "$venvDir"
    Write-OK "Virtual environment creato in $venvDir"
} else {
    Write-OK "Virtual environment giÃ  presente."
}

$venvPy  = "$venvDir\Scripts\python.exe"
$venvPip = "$venvDir\Scripts\pip.exe"

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 4 â€” Installa dipendenze
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Installazione dipendenze Python"

& $venvPip install --upgrade pip --quiet
& $venvPip install -r "$AppDir\backend\requirements.txt" --quiet
Write-OK "Dipendenze installate."

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 5 â€” ODBC Driver 18 per SQL Server
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Verifica ODBC Driver 18 for SQL Server"

$odbcCheck = Get-OdbcDriver -Name "ODBC Driver 18 for SQL Server" -ErrorAction SilentlyContinue
if (-not $odbcCheck) {
    Write-Warn "ODBC Driver 18 non trovato. Download in corso..."
    $odbcUrl  = "https://go.microsoft.com/fwlink/?linkid=2283163"
    $odbcInst = "$env:TEMP\msodbcsql18.msi"
    Invoke-WebRequest -Uri $odbcUrl -OutFile $odbcInst
    Start-Process msiexec -ArgumentList "/i `"$odbcInst`" /quiet IACCEPTMSODBCSQLLICENSETERMS=YES" -Wait
    Remove-Item $odbcInst -Force
    Write-OK "ODBC Driver 18 installato."
} else {
    Write-OK "ODBC Driver 18 giÃ  presente."
}

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 6 â€” File .env
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Configurazione .env"

$envFile = "$AppDir\.env"
if (-not (Test-Path $envFile)) {
    Copy-Item "$AppDir\.env.example" $envFile
    Write-Warn ".env creato da template. MODIFICA i valori reali prima di avviare:"
    Write-Host "    notepad `"$envFile`"" -ForegroundColor Yellow
} else {
    Write-OK ".env giÃ  presente."
}

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 7 â€” Crea cartella logs
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Cartelle di supporto"

New-Item -ItemType Directory -Force -Path "$AppDir\logs"   | Out-Null
New-Item -ItemType Directory -Force -Path "$AppDir\models" | Out-Null
Write-OK "Cartelle logs\ e models\ pronte."

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 8 â€” Scarica NSSM (Windows Service manager)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Download NSSM (Non-Sucking Service Manager)"

$nssmDir = "$AppDir\deploy\nssm"
$nssmExe = "$nssmDir\nssm.exe"

if (-not (Test-Path $nssmExe)) {
    $nssmZip = "$env:TEMP\nssm.zip"
    Invoke-WebRequest -Uri "https://nssm.cc/release/nssm-2.24.zip" -OutFile $nssmZip
    Expand-Archive -Path $nssmZip -DestinationPath "$env:TEMP\nssm_extract" -Force
    New-Item -ItemType Directory -Force -Path $nssmDir | Out-Null
    Copy-Item "$env:TEMP\nssm_extract\nssm-2.24\win64\nssm.exe" $nssmExe
    Remove-Item $nssmZip -Force
    Remove-Item "$env:TEMP\nssm_extract" -Recurse -Force
    Write-OK "NSSM scaricato."
} else {
    Write-OK "NSSM giÃ  presente."
}

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 9 â€” Crea wrapper .bat per il servizio
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Creazione script di avvio servizio"

$startScript = "$AppDir\deploy\start_service.bat"
@"
@echo off
REM Avviato da NSSM come servizio Windows
cd /d "$AppDir"
call "$venvDir\Scripts\activate.bat"
uvicorn backend.main:app --host 127.0.0.1 --port $Port --workers 1 --no-access-log
"@ | Set-Content $startScript -Encoding UTF8
Write-OK "Script servizio creato: $startScript"

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 10 â€” Registra servizio Windows con NSSM
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Registrazione servizio Windows '$ServiceName'"

# Rimuovi servizio esistente se presente
$existing = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($existing) {
    Write-Warn "Servizio '$ServiceName' giÃ  esistente. Rimozione in corso..."
    Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
    & $nssmExe remove $ServiceName confirm
}

# Registra nuovo servizio
& $nssmExe install $ServiceName "$venvDir\Scripts\uvicorn.exe"
& $nssmExe set     $ServiceName AppParameters "backend.main:app --host 127.0.0.1 --port $Port"
& $nssmExe set     $ServiceName AppDirectory  "$AppDir"
& $nssmExe set     $ServiceName DisplayName   "DHA Intelligence v1"
& $nssmExe set     $ServiceName Description   "DHA Intelligence - Biometric Fleet Monitoring"
& $nssmExe set     $ServiceName Start         SERVICE_AUTO_START
& $nssmExe set     $ServiceName AppStdout     "$AppDir\logs\service.log"
& $nssmExe set     $ServiceName AppStderr     "$AppDir\logs\service_error.log"
& $nssmExe set     $ServiceName AppRotateFiles 1
& $nssmExe set     $ServiceName AppRotateSeconds 86400
& $nssmExe set     $ServiceName AppRotateBytes 10485760
# Variabili d'ambiente dal .env
& $nssmExe set     $ServiceName AppEnvironmentExtra "PYTHONPATH=$AppDir"
& $nssmExe set     $ServiceName ObjectName       "LocalService"

Write-OK "Servizio '$ServiceName' registrato."

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 11 â€” Regola Firewall
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Regola Windows Firewall (porta $Port)"

$ruleName = "DHA Intelligence v1"
$ruleExists = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
if ($ruleExists) { Remove-NetFirewallRule -DisplayName $ruleName }

New-NetFirewallRule `
    -DisplayName $ruleName `
    -Direction   Inbound `
    -Protocol    TCP `
    -LocalPort   $Port `
    -Action      Allow `
    -Profile     Any | Out-Null

Write-OK "Regola firewall aggiunta per porta $Port."

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 12 â€” Avvia il servizio
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Write-Step "Avvio servizio"

Start-Service -Name $ServiceName
Start-Sleep -Seconds 3

$svc = Get-Service -Name $ServiceName
if ($svc.Status -eq "Running") {
    Write-OK "Servizio avviato con successo!"
} else {
    Write-Warn "Servizio non in Running (stato: $($svc.Status)). Controlla i log:"
    Write-Host "    type `"$AppDir\logs\service_error.log`"" -ForegroundColor Yellow
}

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# RIEPILOGO FINALE
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
$ip = (Get-NetIPAddress -AddressFamily IPv4 -InterfaceAlias "Ethernet*" -ErrorAction SilentlyContinue | Select-Object -First 1).IPAddress
if (-not $ip) { $ip = "IP_SERVER" }

Write-Host ""
Write-Host "â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•" -ForegroundColor Green
Write-Host "  âœ…  SETUP COMPLETATO" -ForegroundColor Green
Write-Host "â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•" -ForegroundColor Green
Write-Host ""
Write-Host "  App disponibile su:  http://${ip}:${Port}" -ForegroundColor White
Write-Host "  Servizio Windows:    $ServiceName" -ForegroundColor White
Write-Host "  Log applicazione:    $AppDir\logs\service.log" -ForegroundColor White
Write-Host "  Log errori:          $AppDir\logs\service_error.log" -ForegroundColor White
Write-Host ""
Write-Host "  COMANDI UTILI:" -ForegroundColor Cyan
Write-Host "  Stop:    Stop-Service   $ServiceName" -ForegroundColor Gray
Write-Host "  Start:   Start-Service  $ServiceName" -ForegroundColor Gray
Write-Host "  Restart: Restart-Service $ServiceName" -ForegroundColor Gray
Write-Host "  Status:  Get-Service    $ServiceName" -ForegroundColor Gray
Write-Host ""
Write-Host "  âš ï¸  Ricorda di modificare .env con i dati reali!" -ForegroundColor Yellow
Write-Host "     notepad `"$AppDir\.env`"" -ForegroundColor Yellow
Write-Host ""


