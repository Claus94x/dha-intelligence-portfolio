#Requires -Version 5.1
<#
.SYNOPSIS
    Genera segreto sessione e hash password PBKDF2 per l'autenticazione enterprise.
.DESCRIPTION
    Stampa valori pronti da usare in variabili d'ambiente:
    - SECRET_KEY
    - DHA_AUTH_USERS_JSON
    Non scrive segreti su disco a meno che non venga richiesto manualmente.
#>

param(
    [string]$UserName = "admin",
    [string]$DisplayName = "Administrator",
    [string]$Role = "admin"
)

$ErrorActionPreference = "Stop"

function New-RandomBase64([int]$Bytes = 32) {
    $buffer = New-Object byte[] $Bytes
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($buffer)
    return [Convert]::ToBase64String($buffer)
}

function New-Pbkdf2Hash {
    param(
        [Parameter(Mandatory=$true)][string]$Password,
        [int]$Iterations = 210000
    )

    $salt = New-Object byte[] 16
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($salt)
    $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes(
        $Password,
        $salt,
        $Iterations,
        [System.Security.Cryptography.HashAlgorithmName]::SHA256
    )
    $hash = $derive.GetBytes(32)
    $saltB64 = [Convert]::ToBase64String($salt).TrimEnd('=').Replace('+','-').Replace('/','_')
    $hashB64 = [Convert]::ToBase64String($hash).TrimEnd('=').Replace('+','-').Replace('/','_')
    return "pbkdf2_sha256`$$Iterations`$$saltB64`$$hashB64"
}

Write-Host ""
Write-Host "DHA Intelligence v1 - Generazione config auth enterprise" -ForegroundColor Cyan
Write-Host ""
$password = Read-Host "Password per l'utente $UserName" -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($password)
try {
    $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
} finally {
    if ($bstr -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}

$secretKey = New-RandomBase64 32
$passwordHash = New-Pbkdf2Hash -Password $plain
$json = @"
[{"username":"$UserName","display_name":"$DisplayName","role":"$Role","password_hash":"$passwordHash"}]
"@

Write-Host ""
Write-Host "Copia questi valori nelle variabili d'ambiente o nel service manager:" -ForegroundColor Yellow
Write-Host "SECRET_KEY=$secretKey" -ForegroundColor Gray
Write-Host "DHA_AUTH_USERS_JSON=$json" -ForegroundColor Gray
Write-Host ""

try {
    Set-Clipboard -Value ("SECRET_KEY=$secretKey`r`nDHA_AUTH_USERS_JSON=$json")
    Write-Host "Valori copiati negli appunti." -ForegroundColor Green
} catch {
    Write-Host "Impossibile copiare negli appunti: $($_.Exception.Message)" -ForegroundColor Yellow
}
