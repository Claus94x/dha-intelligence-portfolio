﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Install a watchdog task that checks the app every 5 minutes and restarts it if needed.
#>

param(
    [string]$AppDir = (Split-Path $PSScriptRoot -Parent),
    [string]$ServiceName = "DHA-Intelligence",
    [int]$Port = 8000,
    [string]$HealthUrl = "",
    [string]$TaskName = "DHA-Watchdog",
    [int]$IntervalMin = 5
)

if ([string]::IsNullOrWhiteSpace($HealthUrl)) {
    $HealthUrl = "http://localhost:$Port/api/status"
}

Write-Host "`n>>> Installazione Watchdog DHA Intelligence" -ForegroundColor Cyan

$watchdogScriptPath = Join-Path $AppDir "deploy\watchdog.ps1"
$logFilePath = Join-Path $AppDir "logs\watchdog.log"

$template = @'
# DHA Intelligence v1 - Watchdog
# Eseguito ogni __INTERVAL__ minuti da Task Scheduler

$ServiceName = "__SERVICE__"
$HealthUrl   = "__HEALTH__"
$LogFile     = "__LOGFILE__"
$MaxLogLines = 500

function Log {
    param($msg)
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg"
    Add-Content $LogFile $line
    $content = Get-Content $LogFile -ErrorAction SilentlyContinue
    if ($content.Count -gt $MaxLogLines) {
        $content | Select-Object -Last $MaxLogLines | Set-Content $LogFile
    }
}

$healthy = $false
try {
    $r = Invoke-WebRequest -Uri $HealthUrl -TimeoutSec 10 -UseBasicParsing
    if ($r.StatusCode -eq 200) { $healthy = $true }
} catch {
    $healthy = $false
}

if (-not $healthy) {
    Log "API non risponde. Riavvio servizio '$ServiceName'..."
    try {
        Restart-Service -Name $ServiceName -Force -ErrorAction Stop
        Start-Sleep -Seconds 8
        $null = Invoke-WebRequest -Uri $HealthUrl -TimeoutSec 10 -UseBasicParsing -ErrorAction Stop
        Log "Servizio riavviato con successo. API risponde."
    } catch {
        Log "RIAVVIO FALLITO: $($_.Exception.Message)"
        Write-EventLog -LogName Application -Source "DHA-Watchdog" -EventId 1001 -EntryType Error -Message "DHA Intelligence non risponde e il riavvio e' fallito."
    }
} else {
    if ((Get-Date).Minute % 30 -eq 0) {
        Log "OK - API risponde normalmente."
    }
}
'@

$watchdogScript = $template.
    Replace("__INTERVAL__", [string]$IntervalMin).
    Replace("__SERVICE__", $ServiceName).
    Replace("__HEALTH__", $HealthUrl).
    Replace("__LOGFILE__", $logFilePath)

Set-Content -Path $watchdogScriptPath -Value $watchdogScript -Encoding UTF8

if (-not [System.Diagnostics.EventLog]::SourceExists("DHA-Watchdog")) {
    New-EventLog -LogName Application -Source "DHA-Watchdog" -ErrorAction SilentlyContinue
}

$trigger = New-ScheduledTaskTrigger -RepetitionInterval (New-TimeSpan -Minutes $IntervalMin) -Once -At (Get-Date)
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NonInteractive -ExecutionPolicy Bypass -File `"$watchdogScriptPath`""
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 2) -MultipleInstances IgnoreNew
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue |
    Unregister-ScheduledTask -Confirm:$false -ErrorAction SilentlyContinue

Register-ScheduledTask `
    -TaskName $TaskName `
    -Trigger $trigger `
    -Action $action `
    -Settings $settings `
    -Principal $principal `
    -Description "DHA Intelligence v1 - Watchdog every $IntervalMin minutes" `
    -Force | Out-Null

Write-Host "    [OK] Watchdog installed (every $IntervalMin minutes)" -ForegroundColor Green
Write-Host "    [OK] Log: $logFilePath" -ForegroundColor Green
Write-Host ""


