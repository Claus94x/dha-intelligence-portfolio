﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Quick management for the DHA Intelligence v1 Windows service.
.EXAMPLE
    .\deploy\manage_service.ps1 -Action start
    .\deploy\manage_service.ps1 -Action stop
    .\deploy\manage_service.ps1 -Action restart
    .\deploy\manage_service.ps1 -Action status
    .\deploy\manage_service.ps1 -Action logs
    .\deploy\manage_service.ps1 -Action uninstall
    .\deploy\manage_service.ps1 -Action update
#>
param(
    [ValidateSet("start", "stop", "restart", "status", "logs", "uninstall", "update")]
    [string]$Action = "status",
    [string]$ServiceName = "DHA-Intelligence",
    [string]$AppDir = (Split-Path $PSScriptRoot -Parent),
    [int]$Port = 8000
)

$nssmExe = Join-Path $AppDir "deploy\nssm\nssm.exe"
$statusUrl = "http://localhost:$Port/api/status"

switch ($Action) {
    "start" {
        Start-Service -Name $ServiceName
        Write-Host "Service started." -ForegroundColor Green
        Get-Service -Name $ServiceName | Select-Object Name, Status, StartType
    }

    "stop" {
        Stop-Service -Name $ServiceName -Force
        Write-Host "Service stopped." -ForegroundColor Yellow
    }

    "restart" {
        Restart-Service -Name $ServiceName -Force
        Start-Sleep -Seconds 2
        Write-Host "Service restarted." -ForegroundColor Cyan
        Get-Service -Name $ServiceName | Select-Object Name, Status
    }

    "status" {
        $svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
        if (-not $svc) {
            Write-Host "Service '$ServiceName' not found." -ForegroundColor Red
            break
        }

        $color = if ($svc.Status -eq "Running") { "Green" } else { "Yellow" }
        Write-Host ""
        Write-Host "  Service:  $($svc.DisplayName)" -ForegroundColor White
        Write-Host "  State:    $($svc.Status)" -ForegroundColor $color
        Write-Host "  Startup:  $($svc.StartType)" -ForegroundColor White
        Write-Host ""

        try {
            $r = Invoke-RestMethod -Uri $statusUrl -TimeoutSec 5
            Write-Host "  API:      OK - DB: $($r.message)" -ForegroundColor Green
        } catch {
            Write-Host "  API:      Not reachable" -ForegroundColor Red
        }

        Write-Host ""
    }

    "logs" {
        $logFile = Join-Path $AppDir "logs\service.log"
        $errFile = Join-Path $AppDir "logs\service_error.log"

        Write-Host "=== SERVICE LOG (last 50 lines) ===" -ForegroundColor Cyan
        if (Test-Path $logFile) {
            Get-Content $logFile -Tail 50
        } else {
            Write-Host "Log not found: $logFile" -ForegroundColor Yellow
        }

        Write-Host ""
        Write-Host "=== ERROR LOG (last 20 lines) ===" -ForegroundColor Red
        if (Test-Path $errFile) {
            Get-Content $errFile -Tail 20
        } else {
            Write-Host "Error log not found." -ForegroundColor Yellow
        }
    }

    "uninstall" {
        $confirm = Read-Host "Remove service '$ServiceName'? (yes/no)"
        if ($confirm -eq "yes") {
            Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
            if (Test-Path $nssmExe) {
                & $nssmExe remove $ServiceName confirm
            } else {
                sc.exe delete $ServiceName
            }

            Remove-NetFirewallRule -DisplayName "DHA Intelligence v1" -ErrorAction SilentlyContinue
            Write-Host "Service removed." -ForegroundColor Green
        }
    }

    "update" {
        Write-Host "Updating application..." -ForegroundColor Cyan

        Stop-Service -Name $ServiceName -Force
        Write-Host "   Service stopped." -ForegroundColor Yellow

        $venvPip = Join-Path $AppDir ".venv\Scripts\pip.exe"
        if (Test-Path $venvPip) {
            Write-Host "   Updating Python dependencies..." -ForegroundColor Gray
            & $venvPip install -r (Join-Path $AppDir "backend\requirements.txt") --quiet
        }

        Start-Service -Name $ServiceName
        Start-Sleep -Seconds 3
        $svc = Get-Service -Name $ServiceName
        if ($svc.Status -eq "Running") {
            Write-Host "Update complete. Service is running." -ForegroundColor Green
        } else {
            Write-Host "Service is not running after update. Check the logs." -ForegroundColor Red
        }
    }
}


