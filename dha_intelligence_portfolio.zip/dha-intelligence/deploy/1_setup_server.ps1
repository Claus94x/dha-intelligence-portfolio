﻿# =============================================================================
# DHA Intelligence v1 - Setup automatico Windows Server
# Esegui con privilegi elevati:
#   powershell -ExecutionPolicy Bypass -File "C:\Program Files (x86)\DHA\app\deploy\1_setup_server.ps1"
# =============================================================================

param(
    [string]$AppPath    = "C:\Program Files (x86)\DHA\app",
    [string]$PythonUrl  = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe",
    [string]$NssmUrl    = "https://nssm.cc/release/nssm-2.24.zip",
    [int]   $Port       = 8000
)

$ErrorActionPreference = "Stop"

function Write-Step([string]$msg) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "  $msg" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
}

function Write-OK([string]$msg)   { Write-Host "  [OK]  $msg" -ForegroundColor Green }
function Write-Info([string]$msg) { Write-Host "  >>   $msg" -ForegroundColor White }
function Write-Warn([string]$msg) { Write-Host "  [!]  $msg" -ForegroundColor Yellow }
function Write-Err([string]$msg)  { Write-Host "  [X]  $msg" -ForegroundColor Red }

# =============================================================================
Write-Host ""
Write-Host "  DHA Intelligence v1 - Setup Windows Server" -ForegroundColor Magenta
Write-Host "  Cartella app: $AppPath" -ForegroundColor Magenta
Write-Host "  Porta:        $Port" -ForegroundColor Magenta
Write-Host ""

# =============================================================================
Write-Step "STEP 1 - Verifica cartella applicazione"
if (-not (Test-Path $AppPath)) {
    Write-Err "Cartella non trovata: $AppPath"
    Write-Err "Copia prima il progetto in C:\Program Files (x86)\DHA\app"
    exit 1
}
Write-OK "Cartella trovata: $AppPath"

# =============================================================================
Write-Step "STEP 2 - Verifica / Installa Python 3.11"

# Forza TLS 1.2 per download su Windows Server
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Aggiorna PATH per trovare Python appena installato
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")

$pyCmd = Get-Command python -ErrorAction SilentlyContinue
if (-not $pyCmd) {
    # Prova anche py launcher
    $pyCmd = Get-Command py -ErrorAction SilentlyContinue
}

if ($pyCmd) {
    $pyVer = (python --version 2>&1).ToString()
    Write-OK "Python installato: $pyVer"
} else {
    Write-Warn "Python non trovato nel PATH."
    Write-Warn "Scaricalo manualmente da:"
    Write-Warn "  https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
    Write-Warn "Installa con 'Add Python to PATH' selezionato, poi ri-esegui questo script."
    Write-Info "Tentativo download automatico..."
    try {
        $pyInstaller = "$env:TEMP\python_installer.exe"
        Invoke-WebRequest -Uri $PythonUrl -OutFile $pyInstaller -UseBasicParsing
        Write-Info "Installazione Python (silenziosa)..."
        Start-Process $pyInstaller -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1" -Wait
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        Write-OK "Python installato automaticamente"
    } catch {
        Write-Err "Download fallito: $_"
        Write-Err "Installa Python manualmente e ri-esegui lo script."
        exit 1
    }
}

# =============================================================================
Write-Step "STEP 3 - Crea virtualenv e installa dipendenze"
Set-Location $AppPath

if (-not (Test-Path ".venv")) {
    Write-Info "Creazione virtualenv..."
    python -m venv .venv
    Write-OK "Virtualenv creato: $AppPath\.venv"
} else {
    Write-OK "Virtualenv gia' presente"
}

Write-Info "Aggiornamento pip..."
& ".venv\Scripts\python.exe" -m pip install --upgrade pip -q

Write-Info "Installazione dipendenze da requirements.txt..."
& ".venv\Scripts\pip.exe" install -r backend\requirements.txt

Write-OK "Dipendenze installate"

# =============================================================================
Write-Step "STEP 4 - Verifica file .env"
if (-not (Test-Path "$AppPath\.env")) {
    if (Test-Path "$AppPath\.env.example") {
        Copy-Item "$AppPath\.env.example" "$AppPath\.env"
        Write-Warn "File .env creato da .env.example - MODIFICA LA STRINGA DI CONNESSIONE!"
    } else {
        $envContent = "DHA_DB_CONNECTION_STRING=DRIVER={ODBC Driver 18 for SQL Server};SERVER=IL_TUO_SERVER;DATABASE=DHA_WEBAPP;UID=sa;PWD=LA_TUA_PASSWORD;Encrypt=yes;TrustServerCertificate=yes;Connection Timeout=15;"
        Set-Content "$AppPath\.env" $envContent -Encoding UTF8
        Write-Warn "File .env creato con valori placeholder - MODIFICA PRIMA DI AVVIARE!"
    }
} else {
    Write-OK "File .env presente"
}

# =============================================================================
Write-Step "STEP 5 - Crea cartelle necessarie"
$dirs = @("logs", "models")
foreach ($d in $dirs) {
    $full = "$AppPath\$d"
    if (-not (Test-Path $full)) {
        New-Item -ItemType Directory -Path $full | Out-Null
        Write-OK "Cartella creata: $full"
    } else {
        Write-OK "Cartella presente: $full"
    }
}

# =============================================================================
Write-Step "STEP 6 - Regola firewall porta $Port"
$ruleName = "DHA Intelligence v1 - Port $Port"
$existing = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
if ($existing) {
    Write-OK "Regola firewall gia' presente"
} else {
    New-NetFirewallRule `
        -DisplayName $ruleName `
        -Direction   Inbound `
        -Protocol    TCP `
        -LocalPort   $Port `
        -Action      Allow `
        -Profile     Any | Out-Null
    Write-OK "Regola firewall creata per porta $Port"
}

# =============================================================================
Write-Step "STEP 7 - Download e installa NSSM (Windows Service Manager)"
$nssmDir = "C:\Program Files (x86)\DHA\tools\nssm"
$nssmExe = "$nssmDir\nssm.exe"

if (Test-Path $nssmExe) {
    Write-OK "NSSM gia' presente: $nssmExe"
} else {
    Write-Info "Download NSSM..."
    $nssmZip = "$env:TEMP\nssm.zip"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $NssmUrl -OutFile $nssmZip -UseBasicParsing
    New-Item -ItemType Directory -Path $nssmDir -Force | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($nssmZip)
    foreach ($entry in $zip.Entries) {
        if ($entry.Name -eq "nssm.exe" -and $entry.FullName -like "*win64*") {
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $nssmExe, $true)
            break
        }
    }
    $zip.Dispose()
    Write-OK "NSSM installato in $nssmDir"
}

# Aggiungi NSSM al PATH di sistema se non c'e'
$syspath = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
if ($syspath -notlike "*$nssmDir*") {
    [System.Environment]::SetEnvironmentVariable("Path", "$syspath;$nssmDir", "Machine")
    Write-OK "NSSM aggiunto al PATH di sistema"
}

# =============================================================================
Write-Step "STEP 8 - Registra Windows Service 'DHA-Intelligence'"
$svcName   = "DHA-Intelligence"
$uvicornEx = "$AppPath\.venv\Scripts\uvicorn.exe"
$svcArgs   = "backend.main:app --host 127.0.0.1 --port $Port --workers 1"
$logDir    = "$AppPath\logs"

# Rimuovi servizio esistente (se presente)
$existing = Get-Service $svcName -ErrorAction SilentlyContinue
if ($existing) {
    Write-Info "Servizio gia' presente - rimozione per aggiornamento..."
    Stop-Service $svcName -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    & $nssmExe remove $svcName confirm | Out-Null
    Start-Sleep -Seconds 2
}

# Installa servizio
& $nssmExe install $svcName $uvicornEx $svcArgs
& $nssmExe set $svcName AppDirectory      $AppPath
& $nssmExe set $svcName AppEnvironmentExtra "PYTHONPATH=$AppPath" "PYTHONIOENCODING=utf-8"
& $nssmExe set $svcName AppStdout         "$logDir\service.log"
& $nssmExe set $svcName AppStderr         "$logDir\service_err.log"
& $nssmExe set $svcName AppRotateFiles    1
& $nssmExe set $svcName AppRotateBytes    10485760
& $nssmExe set $svcName AppRotateOnline   1
& $nssmExe set $svcName Start             SERVICE_AUTO_START
& $nssmExe set $svcName DisplayName       "DHA Intelligence v1"
& $nssmExe set $svcName Description       "DHA Intelligence v1 - Biometric OS Backend"
& $nssmExe set $svcName ObjectName        LocalService

# Recovery automatico (riavvio dopo crash)
sc.exe failure $svcName reset= 3600 actions= restart/5000/restart/10000/restart/30000

Write-OK "Servizio '$svcName' registrato"

# =============================================================================
Write-Step "STEP 9 - Avvio servizio"
Start-Service $svcName
Start-Sleep -Seconds 3
$svc = Get-Service $svcName
if ($svc.Status -eq "Running") {
    Write-OK "Servizio avviato: $($svc.Status)"
} else {
    Write-Warn "Servizio in stato: $($svc.Status) - controlla i log in $logDir"
}

# =============================================================================
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  SETUP COMPLETATO!" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  App disponibile su:   http://NOME_SERVER:$Port" -ForegroundColor White
Write-Host "  Dashboard:            http://NOME_SERVER:$Port/index.html" -ForegroundColor White
Write-Host "  API status:           http://NOME_SERVER:$Port/api/status" -ForegroundColor White
Write-Host ""
Write-Host "  Gestione servizio:" -ForegroundColor Yellow
Write-Host "    Start:   Start-Service DHA-Intelligence" -ForegroundColor Gray
Write-Host "    Stop:    Stop-Service DHA-Intelligence" -ForegroundColor Gray
Write-Host "    Restart: Restart-Service DHA-Intelligence" -ForegroundColor Gray
Write-Host "    Log:     Get-Content C:\Program Files (x86)\DHA\app\logs\service.log -Tail 50" -ForegroundColor Gray
Write-Host ""
Write-Host "  PASSO SUCCESSIVO: esegui 2_schedule_training.ps1" -ForegroundColor Cyan
Write-Host ""


