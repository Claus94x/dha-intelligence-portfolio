﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Install a daily Windows Scheduled Task for automatic AI training.
.PARAMETER Time
    Daily execution time, default 02:00.
.PARAMETER AppDir
    Project root directory.
#>

param(
    [string]$Time = "02:00",
    [string]$AppDir = (Split-Path $PSScriptRoot -Parent),
    [string]$TaskName = "DHA-Training-Notturno"
)

$ErrorActionPreference = "Stop"

function Write-Step { param($m) Write-Host "`n>>> $m" -ForegroundColor Cyan }
function Write-OK { param($m) Write-Host "    [OK] $m" -ForegroundColor Green }
function Write-Warn { param($m) Write-Host "    [!!] $m" -ForegroundColor Yellow }

Write-Host ""
Write-Host "  DHA Intelligence v1 - Training Automatico" -ForegroundColor Blue
Write-Host "  Orario: ogni giorno alle $Time" -ForegroundColor Blue
Write-Host ""

Write-Step "Verifica script di training"

$trainScript = Join-Path $AppDir "train_all.py"
if (-not (Test-Path $trainScript)) {
    Write-Warn "train_all.py non trovato in $AppDir"
    Write-Host "    Il task verra comunque creato. Copia train_all.py prima dell'esecuzione." -ForegroundColor Yellow
} else {
    Write-OK "train_all.py trovato."
}

$pythonExe = Join-Path $AppDir ".venv\Scripts\python.exe"
if (-not (Test-Path $pythonExe)) {
    Write-Host "    ERRORE: virtual environment non trovato. Esegui prima setup_windows_server.ps1" -ForegroundColor Red
    exit 1
}
Write-OK "Python venv: $pythonExe"

Write-Step "Creazione wrapper training"

$wrapperPath = Join-Path $AppDir "deploy\run_training.ps1"
$logFilePath = Join-Path $AppDir "logs\training.log"
$envFilePath = Join-Path $AppDir ".env"

$template = @'
# Auto-generated training wrapper

$AppDir = "__APPDIR__"
$LogFile = "__LOGFILE__"
$PythonExe = "__PYTHON__"
$Script = "__SCRIPT__"
$EnvFile = "__ENVFILE__"

if (Test-Path $EnvFile) {
    Get-Content $EnvFile | Where-Object { $_ -match "^[^#].+=." } | ForEach-Object {
        $k, $v = $_ -split "=", 2
        [System.Environment]::SetEnvironmentVariable($k.Trim(), $v.Trim(), "Process")
    }
}

New-Item -ItemType Directory -Force -Path (Join-Path $AppDir "logs") | Out-Null

$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
"" | Add-Content $LogFile
"=== TRAINING STARTED $timestamp ===" | Add-Content $LogFile

try {
    $output = & $PythonExe $Script 2>&1
    $output | Add-Content $LogFile
    $exitCode = $LASTEXITCODE
    if ($exitCode -eq 0) {
        "=== TRAINING COMPLETED OK $(Get-Date -Format 'HH:mm:ss') ===" | Add-Content $LogFile
    } else {
        "=== TRAINING FAILED (exit $exitCode) $(Get-Date -Format 'HH:mm:ss') ===" | Add-Content $LogFile
    }
} catch {
    "=== ERROR: $($_.Exception.Message) ===" | Add-Content $LogFile
}
'@

$wrapperScript = $template.
    Replace("__APPDIR__", $AppDir).
    Replace("__LOGFILE__", $logFilePath).
    Replace("__PYTHON__", $pythonExe).
    Replace("__SCRIPT__", $trainScript).
    Replace("__ENVFILE__", $envFilePath)

Set-Content -Path $wrapperPath -Value $wrapperScript -Encoding UTF8
Write-OK "Wrapper creato: $wrapperPath"

Write-Step "Registrazione Scheduled Task '$TaskName'"

$existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existing) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Warn "Task precedente rimosso."
}

$trigger = New-ScheduledTaskTrigger -Daily -At $Time
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NonInteractive -ExecutionPolicy Bypass -File `"$wrapperPath`"" -WorkingDirectory $AppDir
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 4) -RestartCount 2 -RestartInterval (New-TimeSpan -Minutes 10) -StartWhenAvailable -RunOnlyIfNetworkAvailable:$false -WakeToRun:$false -MultipleInstances IgnoreNew
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

Register-ScheduledTask `
    -TaskName $TaskName `
    -Trigger $trigger `
    -Action $action `
    -Settings $settings `
    -Principal $principal `
    -Description "DHA Intelligence v1 - Training automatico notturno" `
    -Force | Out-Null

Write-OK "Task '$TaskName' registrato."

$task = Get-ScheduledTask -TaskName $TaskName

Write-Host ""
Write-Host "  Training automatico configurato" -ForegroundColor Green
Write-Host ""
Write-Host "  Task:       $TaskName" -ForegroundColor White
Write-Host "  Esecuzione: ogni giorno alle $Time" -ForegroundColor White
Write-Host "  Stato:      $($task.State)" -ForegroundColor White
Write-Host "  Log:        $logFilePath" -ForegroundColor White
Write-Host ""
Write-Host "  Comandi utili:" -ForegroundColor Cyan
Write-Host "  Start:      Start-ScheduledTask -TaskName '$TaskName'" -ForegroundColor Gray
Write-Host "  Status:     Get-ScheduledTask -TaskName '$TaskName'" -ForegroundColor Gray
Write-Host "  Log tail:   Get-Content `"$logFilePath`" -Tail 50" -ForegroundColor Gray
Write-Host "  Remove:     Unregister-ScheduledTask -TaskName '$TaskName' -Confirm:`$false" -ForegroundColor Gray
Write-Host ""


