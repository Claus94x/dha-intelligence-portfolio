﻿# =============================================================================
# DHA Intelligence v1 - Watchdog (riavvio automatico se l'app cade)
# Esegui con privilegi elevati dopo 1_setup_server.ps1
# =============================================================================

param(
    [string]$AppPath     = "C:\Program Files (x86)\DHA\app",
    [string]$TaskName    = "DHA-Watchdog",
    [int]   $Port        = 8000,
    [int]   $IntervalMin = 5        # controlla ogni N minuti
)

$logDir = "$AppPath\logs"

Write-Host ""
Write-Host "  DHA - Installazione Watchdog" -ForegroundColor Cyan
Write-Host "  Controllo ogni $IntervalMin minuti" -ForegroundColor Cyan
Write-Host ""

# Script watchdog
$wdPath = "$AppPath\deploy\run_watchdog.ps1"
$wdContent = @"
# Watchdog DHA Intelligence - eseguito da Task Scheduler
`$serviceName = "DHA-Intelligence"
`$url         = "http://localhost:$Port/api/status"
`$logFile     = "$logDir\watchdog.log"
`$timestamp   = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

try {
    `$response = Invoke-WebRequest -Uri `$url -TimeoutSec 10 -UseBasicParsing
    if (`$response.StatusCode -eq 200) {
        # App OK - nessuna azione
        exit 0
    }
} catch {
    # App non risponde - riavvia il servizio
    Add-Content `$logFile "`$timestamp - App non risponde. Riavvio servizio..."
    try {
        Restart-Service `$serviceName -Force
        Start-Sleep -Seconds 5
        `$svc = Get-Service `$serviceName
        Add-Content `$logFile "`$timestamp - Servizio riavviato. Stato: `$(`$svc.Status)"
        Write-EventLog -LogName Application -Source "DHA-Intelligence" -EventId 1001 ``
            -EntryType Warning -Message "Watchdog: app non rispondeva, servizio riavviato." ``
            -ErrorAction SilentlyContinue
    } catch {
        Add-Content `$logFile "`$timestamp - ERRORE riavvio: `$_"
        Write-EventLog -LogName Application -Source "DHA-Intelligence" -EventId 1003 ``
            -EntryType Error -Message "Watchdog: impossibile riavviare il servizio. Errore: `$_" ``
            -ErrorAction SilentlyContinue
    }
}
"@

Set-Content $wdPath $wdContent -Encoding UTF8
Write-Host "  [OK]  Watchdog script creato: $wdPath" -ForegroundColor Green

# Event Log source
New-EventLog -LogName Application -Source "DHA-Intelligence" -ErrorAction SilentlyContinue

# Rimuovi task esistente
Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue

# Task ogni N minuti
$action  = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument "-NonInteractive -ExecutionPolicy Bypass -File `"$wdPath`""

# Trigger ripetuto ogni IntervalMin minuti, per sempre
$trigger = New-ScheduledTaskTrigger -RepetitionInterval (New-TimeSpan -Minutes $IntervalMin) `
    -Once -At (Get-Date)

$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 2) `
    -StartWhenAvailable `
    -MultipleInstances IgnoreNew

$principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest

Register-ScheduledTask `
    -TaskName    $TaskName `
    -Action      $action `
    -Trigger     $trigger `
    -Settings    $settings `
    -Principal   $principal `
    -Description "DHA Intelligence - Watchdog servizio (ogni $IntervalMin min)" | Out-Null

Write-Host "  [OK]  Watchdog '$TaskName' attivo (ogni $IntervalMin minuti)" -ForegroundColor Green
Write-Host ""
Write-Host "  Log watchdog: $logDir\watchdog.log" -ForegroundColor Gray
Write-Host ""
Write-Host "  SETUP COMPLETO! L'app e' pronta per la produzione." -ForegroundColor Green
Write-Host ""


