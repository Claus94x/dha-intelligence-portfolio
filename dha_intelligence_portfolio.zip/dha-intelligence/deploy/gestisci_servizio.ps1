﻿# =============================================================================
# DHA Intelligence v1 - Gestione rapida servizio
# Uso: powershell -File gestisci_servizio.ps1 [start|stop|restart|status|log|update]
# =============================================================================

param([string]$Action = "status")

$SvcName = "DHA-Intelligence"
$AppPath = "C:\Program Files (x86)\DHA\app"
$LogFile = "$AppPath\logs\service.log"

switch ($Action.ToLower()) {

    "start" {
        Start-Service $SvcName
        Write-Host "[OK] Servizio avviato" -ForegroundColor Green
    }

    "stop" {
        Stop-Service $SvcName -Force
        Write-Host "[OK] Servizio fermato" -ForegroundColor Yellow
    }

    "restart" {
        Restart-Service $SvcName -Force
        Start-Sleep -Seconds 3
        $s = Get-Service $SvcName
        Write-Host "[OK] Servizio riavviato. Stato: $($s.Status)" -ForegroundColor Green
    }

    "status" {
        $s = Get-Service $SvcName -ErrorAction SilentlyContinue
        if ($s) {
            $color = if ($s.Status -eq "Running") { "Green" } else { "Red" }
            Write-Host "Servizio: $($s.DisplayName)" -ForegroundColor White
            Write-Host "Stato:    $($s.Status)" -ForegroundColor $color
            Write-Host "Avvio:    $($s.StartType)" -ForegroundColor White
            # Testa l'API
            try {
                $r = Invoke-WebRequest "http://localhost:8000/api/status" -TimeoutSec 5 -UseBasicParsing
                Write-Host "API:      OK (HTTP $($r.StatusCode))" -ForegroundColor Green
            } catch {
                Write-Host "API:      NON RAGGIUNGIBILE" -ForegroundColor Red
            }
        } else {
            Write-Host "Servizio $SvcName non trovato." -ForegroundColor Red
        }
    }

    "log" {
        if (Test-Path $LogFile) {
            Write-Host "--- Ultime 50 righe di $LogFile ---" -ForegroundColor Cyan
            Get-Content $LogFile -Tail 50
        } else {
            Write-Host "Log non trovato: $LogFile" -ForegroundColor Yellow
        }
    }

    "update" {
        Write-Host "Aggiornamento dipendenze e riavvio..." -ForegroundColor Cyan
        Stop-Service $SvcName -Force
        Set-Location $AppPath
        & ".venv\Scripts\pip.exe" install -r backend\requirements.txt -q
        Start-Service $SvcName
        Start-Sleep -Seconds 3
        Write-Host "[OK] Aggiornato e riavviato" -ForegroundColor Green
    }

    default {
        Write-Host "Uso: gestisci_servizio.ps1 [start|stop|restart|status|log|update]"
    }
}


