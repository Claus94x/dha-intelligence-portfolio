﻿# DHA Intelligence v1 â€” Deploy Windows Server

## Struttura file deploy

```
deploy\
â”œâ”€â”€ setup_windows_server.ps1   â† SETUP PRINCIPALE (esegui questo)
â”œâ”€â”€ manage_service.ps1         â† Gestione servizio (start/stop/log/update)
â”œâ”€â”€ setup_iis_proxy.ps1        â† OPZIONALE: IIS reverse proxy (porta 80)
â”œâ”€â”€ nssm\
â”‚   â””â”€â”€ nssm.exe               â† Scaricato automaticamente dallo script
â””â”€â”€ README_WINDOWS_SERVER.md   â† Questa guida
```

---

## PREREQUISITI SERVER

| Componente | Versione minima | Note |
|-----------|----------------|------|
| Windows Server | 2019 / 2022 | Anche 2016 |
| Python | 3.11+ | Scaricato automaticamente se mancante |
| ODBC Driver | 18 for SQL Server | Installato automaticamente |
| RAM | 4 GB | 8 GB consigliati |
| Disco | 2 GB liberi | Per app + modelli ML |

---

## INSTALLAZIONE (5 minuti)

### 1. Copia il progetto sul server

Copia tutta la cartella `nuovo sito\` sul server, ad esempio in:
```
C:\DHA\nuovo sito\
```

### 2. Apri PowerShell con privilegi elevati

```
Tasto Start â†’ digita "PowerShell" â†’ click destro â†’ "Esegui con privilegi elevati"
```

### 3. Esegui il setup

```powershell
Set-Location "C:\DHA\nuovo sito"

# Abilita esecuzione script (solo prima volta)
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force

# Avvia setup completo
.\deploy\setup_windows_server.ps1
```

Lo script fa **tutto automaticamente**:
- âœ… Verifica/installa Python 3.11
- âœ… Crea virtual environment
- âœ… Installa tutte le dipendenze (`requirements.txt`)
- âœ… Installa ODBC Driver 18 for SQL Server
- âœ… Crea il file `.env` da template
- âœ… Scarica NSSM
- âœ… Registra `DHA-Intelligence` come Servizio Windows (auto-start)
- âœ… Fa ascoltare il backend solo su `127.0.0.1:8000`
- âœ… Usa un account di servizio a privilegi minimi (`LocalService`)
- âœ… Avvia il servizio

### 4. Configura la connection string

```powershell
notepad "C:\DHA\nuovo sito\.env"
```

Modifica la riga:
```
DHA_DB_CONNECTION_STRING=DRIVER={ODBC Driver 18 for SQL Server};SERVER=TUO_SERVER;DATABASE=DHA_WEBAPP;UID=sa;PWD=password;Encrypt=yes;TrustServerCertificate=yes;
```

Poi riavvia il servizio:
```powershell
.\deploy\manage_service.ps1 -Action restart
```

Per l'autenticazione enterprise, genera i segreti con:
```powershell
.\deploy\generate_auth_config.ps1
```
Poi imposta `SECRET_KEY` e `DHA_AUTH_USERS_JSON` come variabili d'ambiente del servizio.

### 5. Verifica

Apri il browser sul server:
```
http://localhost:8000
```

Oppure da un altro PC nella rete:
```
http://IP_DEL_SERVER/
```

Se vuoi esporre la porta 80 con IIS:
```powershell
.\deploy\setup_iis_proxy.ps1 -HostHeader localhost
```

---

## GESTIONE SERVIZIO

```powershell
cd "C:\DHA\nuovo sito"

# Stato + test API
.\deploy\manage_service.ps1 -Action status

# Avvia
.\deploy\manage_service.ps1 -Action start

# Ferma
.\deploy\manage_service.ps1 -Action stop

# Riavvia
.\deploy\manage_service.ps1 -Action restart

# Visualizza log in tempo reale
.\deploy\manage_service.ps1 -Action logs

# Aggiorna (ferma â†’ aggiorna pip â†’ riavvia)
.\deploy\manage_service.ps1 -Action update

# Rimuovi il servizio
.\deploy\manage_service.ps1 -Action uninstall
```

Oppure da **Gestione Servizi Windows** (`services.msc`):
- Cerca **"DHA Intelligence v1"**
- Start / Stop / ProprietÃ  â†’ Avvio Automatico

---

## OPZIONALE: Porta 80 con IIS

Se vuoi accedere via `http://server/` invece di `http://server:8000/`:

```powershell
.\deploy\setup_iis_proxy.ps1
```

Installa IIS + ARR + URL Rewrite e configura il reverse proxy automaticamente.

---

## LOG E TROUBLESHOOTING

| File | Contenuto |
|------|-----------|
| `logs\service.log` | Output normale applicazione |
| `logs\service_error.log` | Errori del processo |

```powershell
# Leggi log errori
Get-Content "C:\DHA\nuovo sito\logs\service_error.log" -Tail 30

# Log in tempo reale
Get-Content "C:\DHA\nuovo sito\logs\service.log" -Wait -Tail 20
```

### Problemi comuni

| Problema | Causa | Soluzione |
|---------|-------|-----------|
| Servizio si avvia ma si ferma subito | Errore Python / .env mancante | Leggi `service_error.log` |
| Porta 8000 non raggiungibile | Firewall bloccato | Verifica regola firewall `DHA Intelligence v1` |
| DB non raggiungibile | Connection string errata | Controlla `.env`, testa VPN |
| `ModuleNotFoundError` | Venv non attivo nel servizio | Riesegui `setup_windows_server.ps1` |

---

## AGGIORNAMENTO APPLICAZIONE

Quando aggiorni il codice sorgente:

```powershell
cd "C:\DHA\nuovo sito"

# Se aggiorni solo i file HTML/JS (nessun restart necessario):
# â†’ Basta copiare i file nuovi, il browser vede subito le modifiche

# Se aggiorni backend\main.py o requirements.txt:
.\deploy\manage_service.ps1 -Action update
```

---

## STRUTTURA PRODUZIONE CONSIGLIATA

```
C:\DHA\
â””â”€â”€ nuovo sito\          â† Cartella applicazione
    â”œâ”€â”€ backend\
    â”‚   â”œâ”€â”€ main.py
    â”‚   â””â”€â”€ db.py
    â”œâ”€â”€ models\           â† Modelli ML (persistenti)
    â”œâ”€â”€ logs\             â† Log servizio (rotazione automatica)
    â”œâ”€â”€ .venv\            â† Virtual environment Python
    â”œâ”€â”€ .env              â† âš ï¸ Credenziali (non su Git!)
    â””â”€â”€ deploy\
        â””â”€â”€ nssm\
            â””â”€â”€ nssm.exe
```

