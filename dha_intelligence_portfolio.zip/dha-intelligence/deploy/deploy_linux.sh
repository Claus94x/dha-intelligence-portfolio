#!/bin/bash
# ─── DHA Intelligence v3 — Deploy su server Linux (no Docker) ────────────────
# Testato su Ubuntu 22.04 / Debian 11
# Esegui come root oppure con sudo

set -e

APP_DIR="/opt/dha-intelligence"
APP_USER="dha"
PYTHON="python3"
PORT=8000

echo "=== DHA Intelligence v3 — Deploy Linux ==="

# 1. Crea utente dedicato
if ! id "$APP_USER" &>/dev/null; then
    useradd -r -s /bin/false -d "$APP_DIR" "$APP_USER"
    echo "Utente '$APP_USER' creato."
fi

# 2. Copia files
mkdir -p "$APP_DIR"
cp -r . "$APP_DIR/"
chown -R "$APP_USER:$APP_USER" "$APP_DIR"

# 3. Installa dipendenze Python
cd "$APP_DIR"
$PYTHON -m venv .venv
source .venv/bin/activate
pip install --upgrade pip -q
pip install -r backend/requirements.txt -q
pip install gunicorn -q

# 4. Copia .env
if [ ! -f "$APP_DIR/.env" ]; then
    cp "$APP_DIR/.env.example" "$APP_DIR/.env"
    echo ""
    echo "⚠️  Modifica $APP_DIR/.env con i tuoi valori reali!"
    echo ""
fi

# 5. Installa ODBC Driver 18 (SQL Server)
if ! odbcinst -q -d -n "ODBC Driver 18 for SQL Server" 2>/dev/null | grep -q "Driver"; then
    . /etc/os-release
    case "$ID:$VERSION_ID" in
        ubuntu:22.04)
            MS_REPO_URL="https://packages.microsoft.com/config/ubuntu/22.04/prod.list"
            ;;
        debian:11)
            MS_REPO_URL="https://packages.microsoft.com/config/debian/11/prod.list"
            ;;
        *)
            echo "Distribuzione non supportata per il setup ODBC: $ID $VERSION_ID"
            exit 1
            ;;
    esac
    curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
    curl "$MS_REPO_URL" > /etc/apt/sources.list.d/mssql-release.list
    apt-get update
    ACCEPT_EULA=Y apt-get install -y msodbcsql18
    echo "ODBC Driver 18 installato."
fi

# 6. Crea servizio systemd
cat > /etc/systemd/system/dha-intelligence.service << EOF
[Unit]
Description=DHA Intelligence v3
After=network.target

[Service]
Type=exec
User=$APP_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/.venv/bin/gunicorn backend.main:app \
    --worker-class uvicorn.workers.UvicornWorker \
    --workers 1 \
    --bind 0.0.0.0:$PORT \
    --timeout 120 \
    --access-logfile $APP_DIR/logs/access.log \
    --error-logfile $APP_DIR/logs/error.log
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

mkdir -p "$APP_DIR/logs"
chown -R "$APP_USER:$APP_USER" "$APP_DIR/logs"

# 7. Abilita e avvia il servizio
systemctl daemon-reload
systemctl enable dha-intelligence
systemctl restart dha-intelligence

echo ""
echo "=== Deploy completato! ==="
echo "Stato servizio:"
systemctl status dha-intelligence --no-pager
echo ""
echo "App disponibile su: http://$(hostname -I | awk '{print $1}'):$PORT"
echo "Log: journalctl -u dha-intelligence -f"
