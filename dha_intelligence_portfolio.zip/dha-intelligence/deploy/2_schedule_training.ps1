﻿# =============================================================================
# DHA Intelligence v1 - Pianifica training automatico notturno
# Esegui con privilegi elevati dopo 1_setup_server.ps1
# =============================================================================

param(
    [string]$AppPath     = "C:\Program Files (x86)\DHA\app",
    [string]$TrainTime   = "02:00",   # orario training giornaliero (HH:MM)
    [string]$TaskName    = "DHA-Training-Notturno"
)

$ErrorActionPreference = "Stop"
$pythonExe = "$AppPath\.venv\Scripts\python.exe"
$logDir    = "$AppPath\logs"

Write-Host ""
Write-Host "  DHA - Pianificazione Training Automatico" -ForegroundColor Cyan
Write-Host "  Orario: ogni notte alle $TrainTime" -ForegroundColor Cyan
Write-Host ""

# Crea script wrapper PowerShell per il training
$wrapperPath = "$AppPath\deploy\run_training.ps1"
$wrapperContent = @"
# Wrapper automatico - eseguito da Task Scheduler ogni notte
Set-Location "$AppPath"

# Carica variabili d'ambiente da .env
if (Test-Path "$AppPath\.env") {
    Get-Content "$AppPath\.env" | ForEach-Object {
        if (`$_ -match '^\s*([^#][^=]+)=(.+)') {
            [System.Environment]::SetEnvironmentVariable(`$Matches[1].Trim(), `$Matches[2].Trim(), 'Process')
        }
    }
}

`$logFile = "$logDir\training_auto_`$(Get-Date -Format 'yyyyMMdd_HHmm').log"
`$timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

Add-Content `$logFile "========================================"
Add-Content `$logFile "Training avviato: `$timestamp"
Add-Content `$logFile "========================================"

& "$pythonExe" "$AppPath\train_all.py" 2>&1 | Tee-Object -FilePath `$logFile -Append

`$exit = `$LASTEXITCODE
`$endTs = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
Add-Content `$logFile "Training terminato: `$endTs (exit code: `$exit)"

if (`$exit -ne 0) {
    Write-EventLog -LogName Application -Source "DHA-Intelligence" -EventId 1002 `
        -EntryType Error -Message "Training fallito con exit code `$exit. Log: `$logFile" `
        -ErrorAction SilentlyContinue
}
"@

Set-Content $wrapperPath $wrapperContent -Encoding UTF8
Write-Host "  [OK]  Wrapper training creato: $wrapperPath" -ForegroundColor Green

# Registra Windows Event Log source
New-EventLog -LogName Application -Source "DHA-Intelligence" -ErrorAction SilentlyContinue

# Rimuovi task esistente se presente
Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue

# Crea Task Scheduler
$action  = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument "-NonInteractive -ExecutionPolicy Bypass -File `"$wrapperPath`"" `
    -WorkingDirectory $AppPath

$trigger = New-ScheduledTaskTrigger -Daily -At $TrainTime

$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Hours 4) `
    -StartWhenAvailable `
    -RunOnlyIfNetworkAvailable:$false `
    -MultipleInstances IgnoreNew

$principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest

Register-ScheduledTask `
    -TaskName    $TaskName `
    -Action      $action `
    -Trigger     $trigger `
    -Settings    $settings `
    -Principal   $principal `
    -Description "DHA Intelligence - Training ML automatico notturno" | Out-Null

Write-Host "  [OK]  Task '$TaskName' registrato (ogni notte alle $TrainTime)" -ForegroundColor Green
Write-Host ""
Write-Host "  Per eseguire il training subito (test):" -ForegroundColor Yellow
Write-Host "    Start-ScheduledTask -TaskName '$TaskName'" -ForegroundColor Gray
Write-Host ""
Write-Host "  PASSO SUCCESSIVO: esegui 3_install_watchdog.ps1" -ForegroundColor Cyan
Write-Host ""


