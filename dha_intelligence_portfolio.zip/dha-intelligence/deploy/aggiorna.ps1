﻿# =============================================================================
# DHA Intelligence v1 - Aggiornamento rapido da PC locale al server
# Esegui con privilegi elevati sul SERVER:
#   powershell -ExecutionPolicy Bypass -File "C:\Program Files (x86)\DHA\app\deploy\aggiorna.ps1"
#
# Parametri opzionali:
#   -SorgentePc  "\\192.168.1.x\C$\Users\c.daloiso\Desktop\nuovo sito"
#   -SoloRiavvio  (se i file sono gia' stati copiati, riavvia solo il servizio)
#   -AggiornaDeps (reinstalla anche le dipendenze pip)
# =============================================================================

param(
    [string]$AppPath     = "C:\Program Files (x86)\DHA\app",
    [string]$SorgentePc  = "",          # percorso UNC o locale dei file sorgente
    [switch]$SoloRiavvio = $false,      # riavvia solo, senza copiare file
    [switch]$AggiornaDeps = $false      # reinstalla anche pip dependencies
)

$TaskName = "DHA-Intelligence"

function Write-OK([string]$m)   { Write-Host "  [OK]  $m" -ForegroundColor Green }
function Write-Info([string]$m) { Write-Host "  >>   $m" -ForegroundColor White }
function Write-Warn([string]$m) { Write-Host "  [!]  $m" -ForegroundColor Yellow }
function Write-Err([string]$m)  { Write-Host "  [X]  $m" -ForegroundColor Red }

Write-Host ""
Write-Host "  DHA Intelligence v1 - Aggiornamento" -ForegroundColor Magenta
Write-Host "  $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Gray
Write-Host ""

# =============================================================================
# STEP 1 - Copia file (se richiesto)
# =============================================================================
if (-not $SoloRiavvio -and $SorgentePc -ne "") {
    Write-Info "Copia file da: $SorgentePc"
    Write-Info "          a:  $AppPath"

    if (-not (Test-Path $SorgentePc)) {
        Write-Err "Sorgente non trovata: $SorgentePc"
        Write-Err "Verifica che il PC sia acceso e la cartella condivisa."
        exit 1
    }

    # File/cartelle da copiare (escludi .venv, logs, models, .env)
    $escludi = @(".venv", "logs", "models", ".env")

    Get-ChildItem $SorgentePc | Where-Object { $escludi -notcontains $_.Name } | ForEach-Object {
        $dest = Join-Path $AppPath $_.Name
        if ($_.PSIsContainer) {
            Write-Info "Cartella: $($_.Name)"
            Copy-Item $_.FullName $dest -Recurse -Force
        } else {
            Write-Info "File: $($_.Name)"
            Copy-Item $_.FullName $dest -Force
        }
    }
    Write-OK "File copiati"
}

# =============================================================================
# STEP 2 - Aggiorna dipendenze pip (opzionale)
# =============================================================================
if ($AggiornaDeps) {
    Write-Info "Aggiornamento dipendenze pip..."
    $pip = "$AppPath\.venv\Scripts\pip.exe"
    if (Test-Path $pip) {
        & $pip install -r "$AppPath\backend\requirements.txt" --prefer-binary -q
        Write-OK "Dipendenze aggiornate"
    } else {
        Write-Warn "pip non trovato in .venv - salto aggiornamento deps"
    }
}

# =============================================================================
# STEP 3 - Riavvia il servizio (Task Scheduler)
# =============================================================================
Write-Info "Arresto task '$TaskName'..."
Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3

Write-Info "Avvio task '$TaskName'..."
Start-ScheduledTask -TaskName $TaskName
Start-Sleep -Seconds 4

# =============================================================================
# STEP 4 - Verifica
# =============================================================================
Write-Info "Verifica API..."
$ok = $false
for ($i = 0; $i -lt 5; $i++) {
    Start-Sleep -Seconds 2
    try {
        $r = Invoke-WebRequest "http://localhost:8080/api/status" -TimeoutSec 5 -UseBasicParsing
        if ($r.StatusCode -eq 200) { $ok = $true; break }
    } catch {}
}

if ($ok) {
    Write-OK "App risponde su http://localhost:8080/api/status"
} else {
    Write-Warn "App non risponde ancora - controlla i log:"
    Write-Warn "  Get-Content '$AppPath\logs\uvicorn.log' -Tail 30"
}

Write-Host ""
Write-Host "  Aggiornamento completato!" -ForegroundColor Green
Write-Host "  App: http://37.59.136.95:8080" -ForegroundColor Cyan
Write-Host ""

