#!/bin/bash
# ─── DHA Intelligence v3 — Deploy con Docker Compose ────────────────────────
# Prerequisito: Docker + Docker Compose installati sul server

set -e

echo "=== DHA Intelligence v3 — Deploy Docker ==="

# 1. Copia .env se non esiste
if [ ! -f .env ]; then
    cp .env.example .env
    echo "⚠️  Modifica .env con i tuoi valori prima di continuare!"
    echo "    nano .env"
    exit 1
fi

# 2. Crea cartelle persistenti
mkdir -p models logs nginx/certs

# 3. Build e avvio
docker compose pull nginx  2>/dev/null || true
docker compose build --no-cache dha-app
docker compose up -d

echo ""
echo "=== Deploy completato! ==="
docker compose ps
echo ""
echo "App disponibile su: http://$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')"
echo "Log: docker compose logs -f dha-app"
echo "Stop: docker compose down"
