﻿# DHA Intelligence v1 â€” Guida Produzione Windows Server

## INDICE
1. [Installazione base](#1-installazione-base)
2. [App sempre attiva](#2-app-sempre-attiva)
3. [Training automatico](#3-training-automatico)
4. [Monitoraggio e alerting](#4-monitoraggio-e-alerting)
5. [Manutenzione](#5-manutenzione)

---

## 1. INSTALLAZIONE BASE

### Prerequisiti server
- Windows Server 2019 / 2022
- Minimo 4 GB RAM (8 GB consigliati se training ML attivo)
- 10 GB disco libero
- Accesso a SQL Server (rete/VPN configurata)
- PowerShell 5.1+ (giÃ  incluso in Windows Server)

### Installa tutto in un colpo

```powershell
# Apri PowerShell con privilegi elevati
Set-Location "C:\DHA\nuovo sito"
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
.\deploy\setup_windows_server.ps1
```

### Configura la connessione al DB e l'autenticazione

```powershell
notepad "C:\DHA\nuovo sito\.env"
```

Modifica questa riga con i tuoi dati reali:
```
DHA_DB_CONNECTION_STRING=DRIVER={ODBC Driver 18 for SQL Server};SERVER=TUO_SERVER;DATABASE=DHA_WEBAPP;UID=sa;PWD=TUA_PASSWORD;Encrypt=yes;TrustServerCertificate=yes;Connection Timeout=15;
```

Genera l'autenticazione enterprise con:
```powershell
.\deploy\generate_auth_config.ps1
```
Poi copia `SECRET_KEY` e `DHA_AUTH_USERS_JSON` nelle variabili d'ambiente del servizio.

Poi riavvia:
```powershell
Restart-Service DHA-Intelligence
```

---

## 2. APP SEMPRE ATTIVA

### Come funziona
Lo script di setup registra `DHA-Intelligence` come **Servizio Windows** tramite NSSM.
Questo garantisce:
- âœ… **Parte automaticamente** al boot del server
- âœ… **Si riavvia da solo** se crasha (Recovery automatico)
- âœ… **Gira in background** anche senza utenti connessi
- âœ… Appare in `services.msc` come qualsiasi altro servizio Windows

### Configurare il Recovery automatico (riavvio automatico dopo crash)

```powershell
# Esegui con privilegi elevati
sc.exe failure DHA-Intelligence reset= 86400 actions= restart/5000/restart/10000/restart/30000
```

Questo configura:
- **1Â° crash** â†’ riavvio dopo 5 secondi
- **2Â° crash** â†’ riavvio dopo 10 secondi
- **3Â° crash** â†’ riavvio dopo 30 secondi
- Reset contatore dopo 24 ore

### Verificare che il servizio sia configurato correttamente

```powershell
# Controlla stato
Get-Service DHA-Intelligence

# Verifica avvio automatico
Get-Service DHA-Intelligence | Select-Object Name, Status, StartType

# Testa l'API
Invoke-RestMethod http://localhost:8000/api/status
```

Output atteso:
```
Status  : Running
StartType : Automatic
---
ok      : True
message : Database raggiungibile
```

### Gestione rapida da riga di comando

```powershell
cd "C:\DHA\nuovo sito"

.\deploy\manage_service.ps1 -Action status    # Stato + test API
.\deploy\manage_service.ps1 -Action restart   # Riavvia
.\deploy\manage_service.ps1 -Action logs      # Ultimi log
.\deploy\manage_service.ps1 -Action update    # Aggiorna e riavvia
```

### Accesso dalla rete locale

Di default l'app risponde su **porta 8000**.
Il backend resta legato al loopback (`127.0.0.1:8000`); chiunque nella stessa rete accede via proxy IIS/Nginx sulla porta pubblica 80:
```
http://IP_DEL_SERVER/
```

Trova l'IP del server:
```powershell
(Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.PrefixOrigin -ne "WellKnown"} | Select-Object -First 1).IPAddress
```

### Accesso via porta 80 (opzionale, piÃ¹ comodo)

Se vuoi accedere via `http://IP_SERVER/` senza digitare `:8000`:

```powershell
.\deploy\setup_iis_proxy.ps1
```

---

## 3. TRAINING AUTOMATICO

### Opzione A â€” Via interfaccia web (manuale)
Vai su: **Sistema â†’ Training AI â†’ "Avvia Training Completo"**
Il log appare in tempo reale nel terminale a schermo.

### Opzione B â€” Scheduled Task Windows (automatico)

Questo lancia `train_all.py` ogni notte alle 02:00 automaticamente.

```powershell
# Esegui con privilegi elevati
.\deploy\schedule_training.ps1 -Time "02:00"
```

Oppure manualmente:

```powershell
# Crea il task schedulato
$trigger = New-ScheduledTaskTrigger -Daily -At "02:00"

$action = New-ScheduledTaskAction `
    -Execute "C:\DHA\nuovo sito\.venv\Scripts\python.exe" `
    -Argument "train_all.py" `
    -WorkingDirectory "C:\DHA\nuovo sito"

$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Hours 4) `
    -RestartCount 1 `
    -RestartInterval (New-TimeSpan -Minutes 10) `
    -StartWhenAvailable

Register-ScheduledTask `
    -TaskName "DHA-Training-Notturno" `
    -Trigger $trigger `
    -Action $action `
    -Settings $settings `
    -RunLevel Highest `
    -Force

Write-Host "Task schedulato creato. Training ogni notte alle 02:00"
```

### Verificare il task schedulato

```powershell
# Vedi stato
Get-ScheduledTask -TaskName "DHA-Training-Notturno" | Select-Object TaskName, State, LastRunTime, LastTaskResult

# Avvia manualmente per testare
Start-ScheduledTask -TaskName "DHA-Training-Notturno"

# Vedi log ultima esecuzione
Get-ScheduledTaskInfo -TaskName "DHA-Training-Notturno"
```

### Modificare orario training

```powershell
# Cambia da 02:00 a 03:30
$trigger = New-ScheduledTaskTrigger -Daily -At "03:30"
Set-ScheduledTask -TaskName "DHA-Training-Notturno" -Trigger $trigger
```

### Rimuovere il task

```powershell
Unregister-ScheduledTask -TaskName "DHA-Training-Notturno" -Confirm:$false
```

---

## 4. MONITORAGGIO E ALERTING

### Script watchdog â€” controlla che l'app sia viva

Crea un secondo task schedulato che controlla l'app ogni 5 minuti e la riavvia se non risponde:

```powershell
# Installa il watchdog
.\deploy\install_watchdog.ps1
```

### Log applicazione

```powershell
# Log servizio in tempo reale
Get-Content "C:\DHA\nuovo sito\logs\service.log" -Wait -Tail 30

# Ultimi 50 errori
Get-Content "C:\DHA\nuovo sito\logs\service_error.log" -Tail 50

# Log del training (se usi Scheduled Task)
Get-Content "C:\DHA\nuovo sito\logs\training.log" -Tail 50
```

---

## 5. MANUTENZIONE

### Aggiornare il codice

```powershell
cd "C:\DHA\nuovo sito"

# 1. Copia i nuovi file sul server (sovrascrivendo i vecchi)
# 2. Se cambia solo HTML/JS: nessun restart necessario
# 3. Se cambia backend\main.py o requirements.txt:
.\deploy\manage_service.ps1 -Action update
```

### Backup modelli ML

```powershell
# Backup cartella models
$date = Get-Date -Format "yyyyMMdd"
Copy-Item "C:\DHA\nuovo sito\models" "C:\DHA\backup\models_$date" -Recurse
```

### Rotazione log automatica
NSSM gestisce la rotazione automatica (configurata a 10 MB / 1 giorno dallo script di setup).

### Riavvio pianificato (opzionale)

```powershell
# Riavvia il servizio ogni domenica alle 04:00 (manutenzione)
$trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At "04:00"
$action  = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-Command `"Restart-Service DHA-Intelligence`""
Register-ScheduledTask -TaskName "DHA-Restart-Settimanale" `
    -Trigger $trigger -Action $action -RunLevel Highest -Force
```

