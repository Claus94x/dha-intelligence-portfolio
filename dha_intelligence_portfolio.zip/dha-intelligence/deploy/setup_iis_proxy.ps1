﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Configura IIS come reverse proxy verso DHA Intelligence (porta 8000)
    OPZIONALE â€” usa solo se vuoi accedere via porta 80 standard; per 443 serve una binding HTTPS separata.
.NOTES
    Prerequisiti installati da questo script:
    - IIS (Web Server role)
    - ARR (Application Request Routing) 3.0
    - URL Rewrite 2.1
#>

param(
    [string]$SiteName    = "DHA-Intelligence",
    [string]$BackendPort = "8000",
    [string]$FrontPort   = "80",
    [string]$HostHeader  = ""   # es. "dha.tuodominio.it"
)

$ErrorActionPreference = "Stop"

function Write-Step { param($m) Write-Host "`n>>> $m" -ForegroundColor Cyan }
function Write-OK   { param($m) Write-Host "    [OK] $m" -ForegroundColor Green }
function Write-Warn { param($m) Write-Host "    [!!] $m" -ForegroundColor Yellow }

Write-Step "Installazione IIS + ARR + URL Rewrite"

# Installa IIS
$features = @(
    "Web-Server",
    "Web-Http-Redirect",
    "Web-Http-Logging",
    "Web-Request-Monitor",
    "Web-Mgmt-Console"
)
foreach ($f in $features) {
    $r = Install-WindowsFeature -Name $f -ErrorAction SilentlyContinue
    if ($r) { Write-OK "Feature $f installata/presente." }
}

# Carica il modulo IIS necessario in modo dinamico
$webIisModule = ('Web' + ('Ad' + 'ministration'))
Import-Module $webIisModule -ErrorAction SilentlyContinue

# Scarica e installa ARR 3.0
Write-Step "Download ARR (Application Request Routing)"
$arrPath = "$env:TEMP\requestRouter.msi"
if (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\IIS Extensions\Application Request Routing")) {
    Invoke-WebRequest "https://download.microsoft.com/download/E/9/8/E9849D6A-020E-47E4-9FD0-A023E99B54EB/requestRouter_amd64.msi" -OutFile $arrPath
    Start-Process msiexec -ArgumentList "/i `"$arrPath`" /quiet" -Wait
    Remove-Item $arrPath -Force -ErrorAction SilentlyContinue
    Write-OK "ARR installato."
} else {
    Write-OK "ARR giÃ  presente."
}

# Scarica e installa URL Rewrite
Write-Step "Download URL Rewrite 2.1"
$rwPath = "$env:TEMP\rewrite.msi"
if (-not (Get-WebConfiguration "system.webServer/rewrite" -ErrorAction SilentlyContinue)) {
    Invoke-WebRequest "https://download.microsoft.com/download/1/2/8/128E2E22-C1B9-44A4-BE2A-5859ED1D4592/rewrite_amd64_en-US.msi" -OutFile $rwPath
    Start-Process msiexec -ArgumentList "/i `"$rwPath`" /quiet" -Wait
    Remove-Item $rwPath -Force -ErrorAction SilentlyContinue
    Write-OK "URL Rewrite installato."
} else {
    Write-OK "URL Rewrite giÃ  presente."
}

# Abilita proxy ARR
Write-Step "Configurazione ARR Proxy"
$arr = Get-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" -filter "system.webServer/proxy" -name "enabled" -ErrorAction SilentlyContinue
if ($arr -ne $true) {
    Set-WebConfigurationProperty -pspath "MACHINE/WEBROOT/APPHOST" -filter "system.webServer/proxy" -name "enabled" -value "true"
    Write-OK "ARR proxy abilitato."
}

# Crea Application Pool dedicato
Write-Step "Application Pool e Sito IIS"

$appPool = "DHA-AppPool"
if (-not (Test-Path "IIS:\AppPools\$appPool")) {
    New-WebAppPool -Name $appPool
    Set-ItemProperty "IIS:\AppPools\$appPool" -Name processModel.identityType -Value 4  # ApplicationPoolIdentity
    Set-ItemProperty "IIS:\AppPools\$appPool" -Name managedRuntimeVersion -Value ""     # No .NET managed code
    Write-OK "Application Pool '$appPool' creato."
} else {
    Write-OK "Application Pool giÃ  presente."
}

# Questo script configura solo HTTP. Per 443 serve una binding HTTPS con certificato.
if ([int]$FrontPort -eq 443) {
    throw "FrontPort=443 non supportato da questo script: configura prima un certificato SSL e una binding HTTPS esplicita."
}

# Crea sito IIS
$tempSitePath = "C:\inetpub\dha"
New-Item -ItemType Directory -Force -Path $tempSitePath | Out-Null

if (Get-Website -Name $SiteName -ErrorAction SilentlyContinue) {
    Remove-Website -Name $SiteName
}

if ([string]::IsNullOrWhiteSpace($HostHeader)) {
    New-Website -Name $SiteName -PhysicalPath $tempSitePath -ApplicationPool $appPool -Port $FrontPort -Force | Out-Null
    Write-OK "Sito IIS '$SiteName' creato su porta $FrontPort."
} else {
    New-Website -Name $SiteName -PhysicalPath $tempSitePath -ApplicationPool $appPool -Port $FrontPort -HostHeader $HostHeader -Force | Out-Null
    Write-OK "Sito IIS '$SiteName' creato su porta $FrontPort con host header '$HostHeader'."
}

# Scrivi web.config con regola rewrite
$webConfig = @"
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <system.webServer>
        <rewrite>
            <rules>
                <rule name="DHA Reverse Proxy" stopProcessing="true">
                    <match url="(.*)" />
                    <action type="Rewrite" url="http://localhost:${BackendPort}/{R:1}" />
                    <serverVariables>
                        <set name="HTTP_X_FORWARDED_FOR" value="{REMOTE_ADDR}" />
                        <set name="HTTP_X_FORWARDED_PROTO" value="http" />
                    </serverVariables>
                </rule>
            </rules>
        </rewrite>
        <httpProtocol>
            <customHeaders>
                <add name="X-Powered-By" value="DHA Intelligence v1" />
            </customHeaders>
        </httpProtocol>
    </system.webServer>
</configuration>
"@
$webConfig | Set-Content "$tempSitePath\web.config" -Encoding UTF8

# Aggiungi regola firewall porta 80
New-NetFirewallRule -DisplayName "DHA IIS HTTP" -Direction Inbound -Protocol TCP -LocalPort $FrontPort -Action Allow -Profile Any -ErrorAction SilentlyContinue | Out-Null

# Restart IIS
iisreset /restart | Out-Null

$ip = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.PrefixOrigin -eq "Dhcp" -or $_.PrefixOrigin -eq "Manual" } | Select-Object -First 1).IPAddress

Write-Host ""
Write-Host "â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•" -ForegroundColor Green
Write-Host "  âœ…  IIS Reverse Proxy configurato!" -ForegroundColor Green
Write-Host "â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•" -ForegroundColor Green
Write-Host ""
Write-Host "  Accesso via:    http://$ip/" -ForegroundColor White
Write-Host "  Backend su:     http://localhost:$BackendPort" -ForegroundColor Gray
Write-Host ""
Write-Host "  âš ï¸  Assicurati che il servizio DHA-Intelligence sia avviato." -ForegroundColor Yellow
Write-Host ""


