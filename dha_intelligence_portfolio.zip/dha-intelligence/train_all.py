﻿"""
train_all.py â€” Pipeline di training DHA Intelligence v1
=======================================================
Uso:
    python train_all.py            # training completo (ultimi 365 gg)
    python train_all.py --smoke    # smoke test rapido (ultimi 30 gg, subset)

Output:
    models/risk_predictor_<timestamp>.joblib
    models/production_model.json

Tutti i print() vanno su stdout e vengono catturati in tempo reale
dal subprocess del backend FastAPI â†’ visualizzati nella UI Sistema â†’ Training AI.
"""
from __future__ import annotations

import argparse
import datetime
import json
import math
import os
import pathlib
import random
import sys
import time
import traceback
import warnings

warnings.filterwarnings("ignore")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")

# â”€â”€â”€ Encoding Windows â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
def _configure_console_encoding() -> None:
    """Force UTF-8 on Windows so Unicode progress output does not crash."""
    if os.name != "nt":
        return

    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass

    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")


_configure_console_encoding()

# â”€â”€â”€ Percorsi â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
_ROOT = pathlib.Path(__file__).parent
_MODELS_DIR = _ROOT / "models"
_MODELS_DIR.mkdir(exist_ok=True)

# â”€â”€â”€ Timestamp run â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
_TS = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

# â”€â”€â”€ Argomenti â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
parser = argparse.ArgumentParser(description="DHA Intelligence â€” Training Pipeline")
parser.add_argument("--smoke", action="store_true", help="Smoke test rapido")
args = parser.parse_args()
SMOKE = args.smoke

# â”€â”€â”€ Configurazione â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
DAYS_HISTORY  = 30  if SMOKE else 365
MAX_ROWS      = 1000 if SMOKE else 200_000
N_ESTIMATORS  = 50  if SMOKE else 400
CRITICAL_THR  = 0.75   # soglia per etichetta critica
FORECAST_HORIZON_MIN = 30
LSTM_SEQ_LEN  = 30
ENABLE_LSTM = os.environ.get("DHA_ENABLE_LSTM", "0").strip().lower() in {"1", "true", "yes", "on"}
ROBUST_VALIDATION_RUNS = 3 if SMOKE else 5
ROBUST_VALIDATION_HOLDOUT = 0.20
ROBUST_VALIDATION_SPLIT = 0.30
ROBUST_VALIDATION_SEEDS = [11, 23, 37, 53, 71][:ROBUST_VALIDATION_RUNS]
MIN_AUC_GAIN  = 0.03
MIN_BALANCED_ACCURACY_GAIN = 0.02
MIN_RECALL_GAIN = 0.0
MAX_LATENCY_RATIO = 1.75

# â”€â”€â”€ Utility stampa â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

def log(msg: str):
    """Stampa su stdout con flush immediato (richiesto da subprocess line-buffered)."""
    print(msg, flush=True)


def step(n: int, total: int, title: str):
    log("")
    log("=" * 60)
    log(f"[STEP {n}/{total}] {title}")
    log("=" * 60)


def ok(msg: str):
    log(f"  [OK]  {msg}")


def info(msg: str):
    log(f"  >>  {msg}")


def warn(msg: str):
    log(f"  [!]  {msg}")


def err(msg: str):
    log(f"  [ERR]  {msg}")


def fmt_metric(value, decimals: int = 4) -> str:
    """Format a numeric metric or return N/A when unavailable."""
    try:
        if value is None:
            return "N/A"
        numeric = float(value)
        if not math.isfinite(numeric):
            return "N/A"
        return f"{numeric:.{decimals}f}"
    except Exception:
        return "N/A"


def _set_global_seed(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import tensorflow as _tf

        _tf.keras.utils.set_random_seed(seed)
    except Exception:
        pass


def _build_lstm_sequences(frame: pd.DataFrame, feature_names: list[str], seq_len: int, target_col: str = "target_cls"):
    sequences: list[np.ndarray] = []
    labels: list[int] = []

    ordered = frame.sort_values(["id_conducente", "data_ora"]).copy()
    for _, grp in ordered.groupby("id_conducente", sort=False):
        grp = grp.sort_values("data_ora").reset_index(drop=True)
        if len(grp) < seq_len:
            continue

        values = grp[feature_names].to_numpy(dtype=np.float32)
        targets = grp[target_col].to_numpy(dtype=np.float32)

        for end_idx in range(seq_len - 1, len(grp)):
            label = targets[end_idx]
            if np.isnan(label):
                continue
            sequences.append(values[end_idx - seq_len + 1 : end_idx + 1])
            labels.append(int(label))

    if not sequences:
        return None, None

    return np.asarray(sequences, dtype=np.float32), np.asarray(labels, dtype=np.int32)


def _count_lstm_sequences(frame: pd.DataFrame, seq_len: int) -> int:
    total = 0
    ordered = frame.sort_values(["id_conducente", "data_ora"]).copy()
    for _, grp in ordered.groupby("id_conducente", sort=False):
        if len(grp) >= seq_len:
            total += len(grp) - seq_len + 1
    return total


def _temporal_driver_holdout(
    frame: pd.DataFrame,
    validation_fraction: float,
    seq_len: int,
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    train_parts: list[pd.DataFrame] = []
    val_parts: list[pd.DataFrame] = []
    stats = {
        "drivers_total": 0,
        "drivers_split": 0,
        "drivers_train_only": 0,
        "train_only_drivers": [],
        "train_rows": 0,
        "valid_rows": 0,
        "train_sequences": 0,
        "valid_sequences": 0,
    }

    ordered = frame.sort_values(["id_conducente", "data_ora"]).copy()
    for driver_id, grp in ordered.groupby("id_conducente", sort=False):
        grp = grp.sort_values("data_ora").reset_index(drop=True)
        n_rows = len(grp)
        stats["drivers_total"] += 1

        if n_rows < seq_len * 2:
            train_parts.append(grp)
            stats["drivers_train_only"] += 1
            stats["train_only_drivers"].append(str(driver_id))
            stats["train_rows"] += n_rows
            stats["train_sequences"] += max(0, n_rows - seq_len + 1)
            continue

        cut_idx = int(round(n_rows * (1.0 - validation_fraction)))
        cut_idx = max(seq_len, min(cut_idx, n_rows - seq_len))

        train_grp = grp.iloc[:cut_idx].copy()
        val_grp = grp.iloc[cut_idx:].copy()
        train_parts.append(train_grp)
        val_parts.append(val_grp)
        stats["drivers_split"] += 1
        stats["train_rows"] += len(train_grp)
        stats["valid_rows"] += len(val_grp)
        stats["train_sequences"] += max(0, len(train_grp) - seq_len + 1)
        stats["valid_sequences"] += max(0, len(val_grp) - seq_len + 1)

    train_frame = pd.concat(train_parts, ignore_index=True) if train_parts else ordered.iloc[0:0].copy()
    val_frame = pd.concat(val_parts, ignore_index=True) if val_parts else ordered.iloc[0:0].copy()
    return train_frame, val_frame, stats


def _driver_holdout_split(
    frame: pd.DataFrame,
    holdout_fraction: float,
    seq_len: int,
    seed: int = 42,
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    ordered = frame.sort_values(["id_conducente", "data_ora"]).copy()
    grouped_frames: list[tuple[object, pd.DataFrame]] = []
    eligible_drivers: list[object] = []

    for driver_id, grp in ordered.groupby("id_conducente", sort=False):
        grp = grp.sort_values("data_ora").reset_index(drop=True)
        grouped_frames.append((driver_id, grp))
        if len(grp) >= seq_len:
            eligible_drivers.append(driver_id)

    meta = {
        "enabled": False,
        "reason": None,
        "requested_fraction": float(holdout_fraction),
        "effective_fraction": 0.0,
        "drivers_total": len(grouped_frames),
        "drivers_eligible": len(eligible_drivers),
        "drivers_holdout": 0,
        "drivers_development": len(grouped_frames),
        "holdout_drivers": [],
        "holdout_rows": 0,
        "development_rows": int(len(ordered)),
        "holdout_sequences": 0,
        "development_sequences": _count_lstm_sequences(ordered, seq_len),
    }

    if holdout_fraction <= 0 or not eligible_drivers:
        meta["reason"] = "Holdout driver non abilitato."
        return ordered.copy(), ordered.iloc[0:0].copy(), meta

    rng = random.Random(seed)
    eligible_drivers = list(eligible_drivers)
    rng.shuffle(eligible_drivers)

    holdout_target = int(round(len(eligible_drivers) * holdout_fraction))
    if holdout_target <= 0:
        holdout_target = 1
    if holdout_target >= len(eligible_drivers):
        holdout_target = max(0, len(eligible_drivers) - 1)

    if holdout_target <= 0:
        meta["reason"] = "Driver holdout insufficiente: troppo pochi driver eleggibili."
        return ordered.copy(), ordered.iloc[0:0].copy(), meta

    holdout_driver_ids = set(eligible_drivers[:holdout_target])
    holdout_drivers = [str(driver_id) for driver_id in eligible_drivers[:holdout_target]]
    development_parts: list[pd.DataFrame] = []
    holdout_parts: list[pd.DataFrame] = []

    for driver_id, grp in grouped_frames:
        if driver_id in holdout_driver_ids:
            holdout_parts.append(grp)
        else:
            development_parts.append(grp)

    development_df = pd.concat(development_parts, ignore_index=True) if development_parts else ordered.iloc[0:0].copy()
    holdout_df = pd.concat(holdout_parts, ignore_index=True) if holdout_parts else ordered.iloc[0:0].copy()

    meta.update({
        "enabled": True,
        "reason": "Driver holdout attivo.",
        "effective_fraction": round(len(holdout_driver_ids) / max(len(eligible_drivers), 1), 6),
        "drivers_holdout": len(holdout_driver_ids),
        "drivers_development": len(grouped_frames) - len(holdout_driver_ids),
        "holdout_drivers": holdout_drivers,
        "holdout_rows": int(len(holdout_df)),
        "development_rows": int(len(development_df)),
        "holdout_sequences": _count_lstm_sequences(holdout_df, seq_len),
        "development_sequences": _count_lstm_sequences(development_df, seq_len),
    })
    return development_df, holdout_df, meta


def _build_lstm_sequence_dataset(
    frame: pd.DataFrame,
    feature_names: list[str],
    seq_len: int,
    target_col: str = "target_cls",
) -> tuple[np.ndarray | None, np.ndarray | None, list[str]]:
    sequences: list[np.ndarray] = []
    labels: list[int] = []
    driver_ids: list[str] = []

    ordered = frame.sort_values(["id_conducente", "data_ora"]).copy()
    for driver_id, grp in ordered.groupby("id_conducente", sort=False):
        if len(grp) < seq_len:
            continue

        values = grp[feature_names].to_numpy(dtype=np.float32)
        targets = grp[target_col].to_numpy(dtype=np.float32)

        for end_idx in range(seq_len - 1, len(grp)):
            label = targets[end_idx]
            if np.isnan(label):
                continue
            sequences.append(values[end_idx - seq_len + 1 : end_idx + 1])
            labels.append(int(label))
            driver_ids.append(str(driver_id))

    if not sequences:
        return None, None, []

    return np.asarray(sequences, dtype=np.float32), np.asarray(labels, dtype=np.int32), driver_ids


def _attach_future_horizon_targets(frame: pd.DataFrame, horizon_minutes: int) -> pd.DataFrame:
    """Build operational targets using the worst risk observed in the next horizon window."""
    ordered = frame.sort_values(["id_conducente", "data_ora"]).copy()
    horizon_ns = int(pd.Timedelta(minutes=horizon_minutes).value)
    parts: list[pd.DataFrame] = []

    for _, grp in ordered.groupby("id_conducente", sort=False):
        driver_rows = grp.sort_values("data_ora").copy()
        size = len(driver_rows)
        target_reg = np.full(size, np.nan, dtype=np.float32)
        target_rows = np.zeros(size, dtype=np.int32)

        if size >= 2:
            times_ns = driver_rows["data_ora"].astype("datetime64[ns]").astype(np.int64).to_numpy()
            risks = driver_rows["rischio"].to_numpy(dtype=np.float32)

            for idx in range(size - 1):
                start_idx = idx + 1
                end_time = times_ns[idx] + horizon_ns
                end_idx = np.searchsorted(times_ns, end_time, side="right")
                if end_idx <= start_idx:
                    continue

                future_window = risks[start_idx:end_idx]
                if future_window.size == 0:
                    continue

                finite_window = future_window[np.isfinite(future_window)]
                if finite_window.size == 0:
                    continue

                target_reg[idx] = float(np.max(finite_window))
                target_rows[idx] = int(finite_window.size)

        driver_rows["target_reg"] = target_reg
        driver_rows["target_cls"] = (driver_rows["target_reg"] >= CRITICAL_THR).astype(float)
        driver_rows["target_rows_horizon"] = target_rows
        parts.append(driver_rows)

    return pd.concat(parts, ignore_index=True) if parts else ordered


def _binary_prediction_summary(y_true, y_score, threshold: float) -> dict:
    y_true_arr = np.asarray(y_true, dtype=np.int32).reshape(-1)
    y_score_arr = np.asarray(y_score, dtype=np.float32).reshape(-1)

    if y_true_arr.size == 0:
        return {
            "rows": 0,
            "threshold": _safe(threshold),
            "positive_rate": None,
            "predicted_positive_rate": None,
            "confusion_matrix": [[0, 0], [0, 0]],
            "tn": 0,
            "fp": 0,
            "fn": 0,
            "tp": 0,
            "accuracy": None,
            "balanced_accuracy": None,
            "precision": None,
            "recall": None,
            "auc": None,
            "pr_auc": None,
        }

    y_pred_arr = (y_score_arr >= threshold).astype(np.int32)
    cm = confusion_matrix(y_true_arr, y_pred_arr, labels=[0, 1]).tolist()
    tn, fp = cm[0]
    fn, tp = cm[1]

    auc = None
    pr_auc = None
    if np.unique(y_true_arr).size > 1:
        try:
            auc = float(roc_auc_score(y_true_arr, y_score_arr))
            pr_auc = float(average_precision_score(y_true_arr, y_score_arr))
        except Exception:
            pass

    try:
        acc = float((y_pred_arr == y_true_arr).mean())
    except Exception:
        acc = None

    try:
        ba = float(balanced_accuracy_score(y_true_arr, y_pred_arr))
    except Exception:
        ba = None

    try:
        prec = float(precision_score(y_true_arr, y_pred_arr, zero_division=0))
    except Exception:
        prec = None

    try:
        rec = float(recall_score(y_true_arr, y_pred_arr, zero_division=0))
    except Exception:
        rec = None

    return {
        "rows": int(y_true_arr.size),
        "threshold": _safe(threshold),
        "positive_rate": _safe(float(y_true_arr.mean())),
        "predicted_positive_rate": _safe(float(y_pred_arr.mean())),
        "confusion_matrix": cm,
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
        "accuracy": _safe(acc),
        "balanced_accuracy": _safe(ba),
        "precision": _safe(prec),
        "recall": _safe(rec),
        "auc": _safe(auc),
        "pr_auc": _safe(pr_auc),
    }


def _driver_prediction_summary(records: list[dict], threshold: float) -> list[dict]:
    grouped: dict[str, dict[str, list[float]]] = {}
    for record in records:
        driver_key = str(record["driver_id"])
        bucket = grouped.setdefault(driver_key, {"y_true": [], "y_score": []})
        bucket["y_true"].append(int(record["y_true"]))
        bucket["y_score"].append(float(record["y_score"]))

    summary: list[dict] = []
    for driver_id in sorted(grouped.keys()):
        metrics = _binary_prediction_summary(
            grouped[driver_id]["y_true"],
            grouped[driver_id]["y_score"],
            threshold,
        )
        metrics["driver_id"] = driver_id
        summary.append(metrics)
    return summary


def _metric_spread(values: list[float | None]) -> dict:
    clean = [float(v) for v in values if v is not None and np.isfinite(float(v))]
    if not clean:
        return {"count": 0, "mean": None, "std": None, "min": None, "max": None}
    arr = np.asarray(clean, dtype=float)
    return {
        "count": int(arr.size),
        "mean": _safe(float(np.mean(arr))),
        "std": _safe(float(np.std(arr))) if arr.size > 1 else 0.0,
        "min": _safe(float(np.min(arr))),
        "max": _safe(float(np.max(arr))),
    }


def _build_forecast_policy(regression_r2: float | None, classification_threshold: float | None) -> dict:
    value_mode = "probability_first" if regression_r2 is not None and regression_r2 < 0 else "risk_first"
    reliability = "unknown"
    if regression_r2 is not None:
        reliability = "low" if regression_r2 < 0 else "ok"
    return {
        "value_mode": value_mode,
        "preferred_signal": "critical_probability" if value_mode == "probability_first" else "predicted_risk",
        "secondary_signal": "predicted_risk" if value_mode == "probability_first" else "critical_probability",
        "regression_r2": _safe(regression_r2),
        "regression_reliability": reliability,
        "classification_threshold": _safe(classification_threshold),
    }


def _robust_validation_summary(
    frame,
    regressor,
    classifier,
    feature_names: list[str],
    classification_threshold: float,
    runs: int,
    holdout_fraction: float,
    validation_fraction: float,
    seq_len: int,
    seeds: list[int],
) -> dict:
    """Replica il modello di produzione su split ripetuti driver/tempo senza cambiare i pesi."""
    run_details: list[dict] = []

    for seed in seeds[:max(1, runs)]:
        try:
            dev_df, holdout_df, holdout_meta = _driver_holdout_split(frame, holdout_fraction, seq_len, seed=seed)
            if dev_df is None or len(dev_df) == 0:
                continue

            train_split, val_split, split_stats = _temporal_driver_holdout(dev_df, validation_fraction, seq_len)
            if train_split is None or val_split is None or len(train_split) == 0 or len(val_split) == 0:
                continue

            medians = train_split.loc[:, feature_names].median(numeric_only=True)
            X_val = val_split.loc[:, feature_names].copy().fillna(medians)

            yr_true = val_split["target_reg"].astype(float)
            yc_true = val_split["target_cls"].astype(int)

            reg_pred = regressor.predict(X_val)
            cls_proba = classifier.predict_proba(X_val)[:, 1]

            reg_metrics = {
                "mae": _safe(mean_absolute_error(yr_true, reg_pred)),
                "rmse": _safe(mean_squared_error(yr_true, reg_pred) ** 0.5),
                "r2": _safe(r2_score(yr_true, reg_pred)),
            }
            cls_metrics = _binary_prediction_summary(yc_true, cls_proba, classification_threshold)

            run_details.append({
                "seed": seed,
                "holdout_rows": int(len(holdout_df)),
                "holdout_drivers": int(holdout_meta.get("drivers_holdout", 0)),
                "validation_rows": int(len(val_split)),
                "validation_drivers": int(split_stats.get("drivers_split", 0)),
                "regression": reg_metrics,
                "classification": cls_metrics,
            })
        except Exception as exc:
            run_details.append({"seed": seed, "error": str(exc)})

    successful_runs = [run for run in run_details if not run.get("error")]

    summary = {
        "enabled": True,
        "requested_runs": int(runs),
        "completed_runs": int(len(successful_runs)),
        "holdout_fraction": _safe(holdout_fraction),
        "validation_fraction": _safe(validation_fraction),
        "seeds": [int(seed) for seed in seeds[:max(1, runs)]],
        "regression": {
            "mae": _metric_spread([run.get("regression", {}).get("mae") for run in successful_runs]),
            "rmse": _metric_spread([run.get("regression", {}).get("rmse") for run in successful_runs]),
            "r2": _metric_spread([run.get("regression", {}).get("r2") for run in successful_runs]),
        },
        "classification": {
            "auc": _metric_spread([run.get("classification", {}).get("auc") for run in successful_runs]),
            "pr_auc": _metric_spread([run.get("classification", {}).get("pr_auc") for run in successful_runs]),
            "balanced_accuracy": _metric_spread([run.get("classification", {}).get("balanced_accuracy") for run in successful_runs]),
            "precision": _metric_spread([run.get("classification", {}).get("precision") for run in successful_runs]),
            "recall": _metric_spread([run.get("classification", {}).get("recall") for run in successful_runs]),
        },
        "coverage": {
            "holdout_rows": _metric_spread([run.get("holdout_rows") for run in successful_runs]),
            "holdout_drivers": _metric_spread([run.get("holdout_drivers") for run in successful_runs]),
            "validation_rows": _metric_spread([run.get("validation_rows") for run in successful_runs]),
            "validation_drivers": _metric_spread([run.get("validation_drivers") for run in successful_runs]),
        },
    }
    if successful_runs:
        summary["note"] = "Same production XGBoost scored across repeated driver/time splits."
    else:
        summary["note"] = "Nessuno split robusto completato."

    return {
        "enabled": True,
        "requested_runs": int(runs),
        "completed_runs": int(len(successful_runs)),
        "holdout_fraction": _safe(holdout_fraction),
        "validation_fraction": _safe(validation_fraction),
        "seeds": [int(seed) for seed in seeds[:max(1, runs)]],
        "summary": summary,
        "runs": run_details,
    }

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 0 â€” Avvio
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
TOTAL_STEPS = 6
log(f"")
log(f"+----------------------------------------------------------+")
log(f"|      DHA Intelligence v1 -- Training Pipeline            |")
log(f"|      Avvio: {_TS}                            |")
log(f"|      Modalita: {'SMOKE TEST' if SMOKE else 'COMPLETO   '}                           |")
log(f"+----------------------------------------------------------+")
log(f"")
info(f"Giorni storico:    {DAYS_HISTORY}")
info(f"Max righe:         {MAX_ROWS}")
info(f"N. alberi XGB:     {N_ESTIMATORS}")
info(f"Soglia critica:    {CRITICAL_THR}")

_t0 = time.time()

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 1 â€” Dipendenze Python
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
step(1, TOTAL_STEPS, "Verifica dipendenze Python")

missing = []
required_libs = ["pandas", "numpy", "sklearn", "xgboost", "joblib", "pyodbc"]
optional_libs = ["tensorflow"] if ENABLE_LSTM else []
for lib in required_libs + optional_libs:
    try:
        __import__(lib if lib != "sklearn" else "sklearn")
        ok(f"{lib} disponibile")
    except ImportError:
        err(f"{lib} NON installato")
        missing.append(lib)

if missing:
    err(f"Librerie mancanti: {', '.join(missing)}")
    err("Esegui: pip install " + " ".join(missing))
    sys.exit(1)

import numpy as np
import pandas as pd
from sklearn.metrics import (
    roc_auc_score, balanced_accuracy_score,
    precision_score, recall_score, average_precision_score,
    confusion_matrix,
    mean_absolute_error, mean_squared_error, r2_score,
)
from sklearn.utils.class_weight import compute_class_weight
from sklearn.preprocessing import RobustScaler
import xgboost as xgb
import joblib
if ENABLE_LSTM:
    import tensorflow as tf
    from tensorflow import keras
else:
    tf = None
    keras = None
    info("TensorFlow non richiesto: LSTM disattivata")

ok("Tutte le dipendenze importate correttamente")

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 2 â€” Estrazione dati dal database
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
step(2, TOTAL_STEPS, f"Estrazione dati SQL Server (ultimi {DAYS_HISTORY} giorni)")

# Importa la connessione DB del progetto
sys.path.insert(0, str(_ROOT))
try:
    from backend.db import safe_query, test_connection
    ok("Modulo backend.db importato")
except ImportError:
    try:
        from dotenv import load_dotenv
        load_dotenv(str(_ROOT / ".env"))
        from backend.db import safe_query, test_connection
        ok("Modulo backend.db importato (con .env)")
    except Exception as exc:
        err(f"Impossibile importare backend.db: {exc}")
        sys.exit(1)

# Test connessione
info("Test connessione database...")
conn_ok, conn_msg = test_connection()
if not conn_ok:
    err(f"Database non raggiungibile: {conn_msg}")
    sys.exit(1)
ok(f"Database: {conn_msg}")

# Query estrazione dati
info(f"Fetch dati da V_DHA_DASHBOARD (TOP {MAX_ROWS}, ultimi {DAYS_HISTORY} giorni)...")

sql_fetch = f"""
    SELECT TOP {MAX_ROWS}
        id_conducente,
        data_ora,
        rischio,
        s_sonno,
        s_ppg,
        s_thermal,
        lvl,
        ear,
        perclos,
        mar,
        head_pitch,
        blink_freq,
        eye_stability,
        conf,
        hr_val,
        spo2_val,
        temp_val,
        rr_val,
        data_quality
    FROM V_DHA_DASHBOARD
    WHERE data_ora >= DATEADD(day, -{DAYS_HISTORY}, GETDATE())
      AND lvl >= 0
      AND rischio IS NOT NULL
    ORDER BY id_conducente, data_ora ASC
"""

raw_rows = safe_query(sql_fetch)
if not raw_rows:
    err("Nessun dato restituito dalla query. Verificare la view V_DHA_DASHBOARD.")
    sys.exit(1)

df_raw = pd.DataFrame(raw_rows)
ok(f"Estratte {len(df_raw):,} righe da {df_raw['id_conducente'].nunique()} conducenti")

# Info distribuzione
for col in ["rischio", "s_sonno", "s_ppg", "s_thermal"]:
    if col in df_raw.columns:
        valid = df_raw[col].dropna()
        if len(valid):
            info(f"{col}: min={valid.min():.3f}, mean={valid.mean():.3f}, max={valid.max():.3f}, null={df_raw[col].isna().sum()}")

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 3 â€” Feature Engineering
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
step(3, TOTAL_STEPS, "Feature Engineering")

def safe_float_series(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce")

# Conversione tipi
df_raw["data_ora"] = pd.to_datetime(df_raw["data_ora"], errors="coerce")
for col in ["rischio","s_sonno","s_ppg","s_thermal","lvl","ear","perclos",
            "mar","head_pitch","blink_freq","eye_stability","conf",
            "hr_val","spo2_val","temp_val","rr_val"]:
    if col in df_raw.columns:
        df_raw[col] = safe_float_series(df_raw[col])

df_raw = df_raw.dropna(subset=["data_ora", "rischio"]).copy()
df_raw = df_raw.sort_values(["id_conducente", "data_ora"])

info(f"Righe dopo pulizia timestamp/rischio: {len(df_raw):,}")

# Feature temporali
info("Calcolo feature temporali (sin/cos ora del giorno)...")
minute_of_day = df_raw["data_ora"].dt.hour * 60 + df_raw["data_ora"].dt.minute
angle = 2.0 * math.pi * (minute_of_day / 1440.0)
df_raw["ora_sin"] = np.sin(angle)
df_raw["ora_cos"] = np.cos(angle)

# Finestre mobili per conducente
info("Calcolo rolling windows (5m, 15m, 30m) per conducente...")

def rolling_stats(group: pd.DataFrame) -> pd.DataFrame:
    g = group.set_index("data_ora").sort_index()
    r = g["rischio"]
    # Rolling su finestre temporali (minuti)
    for window_min, suffix in [(5, "5m"), (15, "15m"), (30, "30m")]:
        roll = r.rolling(f"{window_min}min", min_periods=1)
        g[f"risk_rmean_{suffix}"] = roll.mean()
        g[f"risk_rstd_{suffix}"]  = roll.std().fillna(0.0)
    # Lag (valore N minuti fa)
    for lag_min, suffix in [(5, "5m"), (10, "10m")]:
        g[f"risk_diff_{suffix}"] = r - r.shift(freq=f"{lag_min}min").reindex(r.index).ffill()
    return g.reset_index()

info("  Applicazione rolling per ogni conducente...")
groups = []
for driver_id, grp in df_raw.groupby("id_conducente"):
    try:
        groups.append(rolling_stats(grp))
    except Exception:
        groups.append(grp)

df = pd.concat(groups, ignore_index=True)
ok(f"Rolling completato: {len(df):,} righe")

# Interazioni
info("Calcolo feature di interazione...")
df["int_sonno_ppg"]      = df["s_sonno"] * df["s_ppg"]
df["int_thermal_sonno"]  = df["s_thermal"] * df["s_sonno"]
df["int_sonno_thermal"]  = df["s_sonno"] * df["s_thermal"]

# Z-score rispetto a finestra 30m
info("Calcolo z-score...")
mean30 = df["risk_rmean_30m"] if "risk_rmean_30m" in df.columns else df["rischio"]
std30  = df["risk_rstd_30m"]  if "risk_rstd_30m"  in df.columns else pd.Series(1.0, index=df.index)
df["z_score"] = np.where(
    std30.fillna(0) > 0,
    (df["rischio"] - mean30) / std30.replace(0, np.nan),
    0.0
)

# Flag anomalia
df["is_anomaly"] = (df["rischio"] >= CRITICAL_THR).astype(float)

# Target operativo: massimo rischio osservato nella finestra futura entro 30 minuti
info(f"Calcolo target operativo (massimo rischio entro {FORECAST_HORIZON_MIN} minuti)...")
df = _attach_future_horizon_targets(df, FORECAST_HORIZON_MIN)
valid_targets = int(df["target_rows_horizon"].gt(0).sum()) if "target_rows_horizon" in df.columns else 0
info(f"Target validi costruiti: {valid_targets:,} righe con almeno un record futuro entro {FORECAST_HORIZON_MIN} minuti.")

# Rimuovi le righe senza osservazioni future nella finestra di forecast
df = df.dropna(subset=["target_reg"]).copy()
ok(
    f"Dataset finale: {len(df):,} righe, {df['target_cls'].sum():.0f} positivi "
    f"({df['target_cls'].mean()*100:.1f}%) sul target entro {FORECAST_HORIZON_MIN} minuti"
)

# Feature set
FEATURES = [
    "rischio", "s_sonno", "s_ppg", "s_thermal", "lvl",
    "risk_rmean_5m", "risk_rstd_5m",
    "risk_rmean_15m", "risk_rstd_15m",
    "risk_rmean_30m", "risk_rstd_30m",
    "risk_diff_5m", "risk_diff_10m",
    "int_sonno_ppg", "int_thermal_sonno", "int_sonno_thermal",
    "ora_sin", "ora_cos",
    "z_score", "is_anomaly",
]

# Filtra solo feature disponibili nel dataframe
FEATURES = [f for f in FEATURES if f in df.columns]
info(f"Feature selezionate ({len(FEATURES)}): {', '.join(FEATURES)}")

# Feature LSTM più pulite: meno ridondanza e niente duplicati commutativi
LSTM_FEATURES = [
    "rischio", "s_sonno", "s_ppg", "s_thermal", "lvl",
    "risk_rmean_5m", "risk_rstd_5m",
    "risk_rmean_15m", "risk_rstd_15m",
    "risk_rmean_30m", "risk_rstd_30m",
    "risk_diff_5m", "risk_diff_10m",
    "int_sonno_ppg", "int_thermal_sonno",
    "ora_sin", "ora_cos",
    "z_score", "is_anomaly",
]
LSTM_FEATURES = [f for f in LSTM_FEATURES if f in df.columns]
info(f"Feature LSTM selezionate ({len(LSTM_FEATURES)}): {', '.join(LSTM_FEATURES)}")

info("Split holdout per driver (20% dei driver, solo valutazione finale)...")
development_df, holdout_df, holdout_meta = _driver_holdout_split(
    df,
    holdout_fraction=0.20,
    seq_len=LSTM_SEQ_LEN,
    seed=42,
)
if holdout_meta.get("enabled"):
    info(
        f"Holdout driver: {len(holdout_meta.get('holdout_drivers', []))} driver | "
        f"righe holdout={len(holdout_df):,} | righe sviluppo={len(development_df):,}"
    )
else:
    info("Holdout per driver non disponibile: uso tutti i driver per lo sviluppo.")
    development_df = df.copy()
    holdout_df = df.iloc[0:0].copy()

X = development_df[FEATURES].copy()
y_reg = development_df["target_reg"].copy()
y_cls = development_df["target_cls"].copy()

# Imputazione NaN con mediana
info("Imputazione NaN con mediana...")
medians = X.median()
X = X.fillna(medians)

ok(f"Feature matrix: {X.shape[0]:,} righe Ã— {X.shape[1]} colonne")
info(f"Classe positiva (critico): {y_cls.sum():.0f}/{len(y_cls)} ({y_cls.mean()*100:.1f}%)")

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 4 â€” Training XGBoost
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
step(4, TOTAL_STEPS, "Training modello XGBoost")

# Split temporale per conducente (holdout finale per validazione)
info("Split temporale per conducente (70% / 30%)...")
train_frame, val_frame, split_stats = _temporal_driver_holdout(development_df, validation_fraction=0.30, seq_len=LSTM_SEQ_LEN)
if train_frame.empty or val_frame.empty:
    raise RuntimeError("Split temporale insufficiente per training/validation.")

info(
    f"Train: {len(train_frame):,} righe | Validation: {len(val_frame):,} righe | "
    f"Driver splitati: {split_stats['drivers_split']} | train-only: {split_stats['drivers_train_only']}"
)
info(
    f"Sequenze LSTM stimate nel split: train={split_stats['train_sequences']:,} | "
    f"validation={split_stats['valid_sequences']:,}"
)

X_train = train_frame[FEATURES].copy()
X_val = val_frame[FEATURES].copy()
train_medians = X_train.median().fillna(0.0)
medians = train_medians
lstm_medians = train_medians.reindex(LSTM_FEATURES).fillna(0.0)
info("Imputazione NaN con mediana del train temporale...")
X_train = X_train.fillna(train_medians)
X_val = X_val.fillna(train_medians)
yr_train = train_frame["target_reg"].copy()
yr_val = val_frame["target_reg"].copy()
yc_train = train_frame["target_cls"].copy()
yc_val = val_frame["target_cls"].copy()
info(f"Positivi train: {yc_train.sum():.0f} | Positivi val: {yc_val.sum():.0f}")

# â”€â”€ 4a. XGBoost Regressor â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
info(f"\nTraining XGBoost Regressor ({N_ESTIMATORS} alberi)...")
t_reg_start = time.time()

scale_pos = max(1.0, (len(yc_train) - yc_train.sum()) / max(yc_train.sum(), 1))

xgb_reg = xgb.XGBRegressor(
    n_estimators    = N_ESTIMATORS,
    max_depth       = 6,
    learning_rate   = 0.05,
    subsample       = 0.8,
    colsample_bytree= 0.8,
    reg_alpha       = 0.1,
    reg_lambda      = 1.0,
    n_jobs          = -1,
    random_state    = 42,
    verbosity       = 0,
    eval_metric     = "rmse",
)
xgb_reg.fit(
    X_train, yr_train,
    eval_set        = [(X_val, yr_val)],
    verbose         = False,
)
t_reg = time.time() - t_reg_start
ok(f"Regressor addestrato in {t_reg:.1f}s")

# Metriche regression
yr_pred = xgb_reg.predict(X_val)
mae  = mean_absolute_error(yr_val, yr_pred)
rmse = mean_squared_error(yr_val, yr_pred) ** 0.5
r2   = r2_score(yr_val, yr_pred)
info(f"  MAE={mae:.4f} | RMSE={rmse:.4f} | RÂ²={r2:.4f}")

# â”€â”€ 4b. XGBoost Classifier â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
info(f"\nTraining XGBoost Classifier ({N_ESTIMATORS} alberi, scale_pos_weight={scale_pos:.1f})...")
t_cls_start = time.time()

xgb_cls = xgb.XGBClassifier(
    n_estimators     = N_ESTIMATORS,
    max_depth        = 5,
    learning_rate    = 0.05,
    subsample        = 0.8,
    colsample_bytree = 0.8,
    scale_pos_weight = scale_pos,
    n_jobs           = -1,
    random_state     = 42,
    verbosity        = 0,
    eval_metric      = "logloss",
    use_label_encoder= False,
)
xgb_cls.fit(
    X_train, yc_train,
    eval_set         = [(X_val, yc_val)],
    verbose          = False,
)
t_cls = time.time() - t_cls_start
ok(f"Classifier addestrato in {t_cls:.1f}s")

# â”€â”€ 4c. Metriche Classification â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
info("\nCalculating Classification metrics...")
yc_proba = xgb_cls.predict_proba(X_val)[:, 1]

# Soglia ottimale (massimizza balanced accuracy)
thresholds  = np.linspace(0.01, 0.99, 200)
best_thr    = 0.5
best_ba     = 0.0
for thr in thresholds:
    preds = (yc_proba >= thr).astype(int)
    if preds.sum() == 0 or preds.sum() == len(preds):
        continue
    try:
        ba = balanced_accuracy_score(yc_val, preds)
        if ba > best_ba:
            best_ba  = ba
            best_thr = thr
    except Exception:
        pass

yc_pred = (yc_proba >= best_thr).astype(int)

auc = None
pr_auc = None
prec = None
rec = None
ba = None
acc = None

try:
    if yc_val.nunique() > 1:
        auc   = float(roc_auc_score(yc_val, yc_proba))
        pr_auc= float(average_precision_score(yc_val, yc_proba))
    else:
        warn("Validation set ha solo una classe â€” AUC non calcolabile")
except Exception as exc:
    warn(f"AUC: {exc}")

try:
    ba  = float(balanced_accuracy_score(yc_val, yc_pred))
    acc = float((yc_pred == yc_val).mean())
except Exception:
    pass

try:
    prec = float(precision_score(yc_val, yc_pred, zero_division=0))
    rec  = float(recall_score(yc_val, yc_pred, zero_division=0))
except Exception:
    pass

ok(f"AUC={fmt_metric(auc)} | PR-AUC={fmt_metric(pr_auc)}")
ok(f"Balanced Acc={fmt_metric(ba)} | Precision={fmt_metric(prec)} | Recall={fmt_metric(rec)}")
ok(f"Soglia ottimale: {best_thr:.4f}")

# Feature importances top 10
info("\nTop 10 feature importances (Classifier):")
fi = xgb_cls.feature_importances_
fi_dict = dict(sorted(zip(FEATURES, fi), key=lambda x: x[1], reverse=True))
for i, (feat, imp) in enumerate(list(fi_dict.items())[:10]):
    bar = "â–ˆ" * int(imp * 60)
    info(f"  {i+1:2d}. {feat:<22s} {imp:.4f}  {bar}")


def _safe(v):
    """Converte NaN/inf in None per JSON."""
    if v is None:
        return None
    try:
        f = float(v)
        return None if (math.isnan(f) or math.isinf(f)) else round(f, 6)
    except Exception:
        return v

# Benchmark latenza inferenza XGBoost per confronto con LSTM
info("Benchmark latenza inferenza XGBoost...")
N_WARMUP = 5
N_BENCH  = 25
X_bench  = X_val.head(1)

for _ in range(N_WARMUP):
    xgb_cls.predict_proba(X_bench)

lat_times = []
for _ in range(N_BENCH):
    t1 = time.perf_counter()
    xgb_cls.predict_proba(X_bench)
    lat_times.append((time.perf_counter() - t1) * 1000)

avg_lat = float(np.mean(lat_times))
peak_mb = 0.0
try:
    import tracemalloc
    tracemalloc.start()
    xgb_cls.predict_proba(X_bench)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    peak_mb = peak / (1024 * 1024)
except Exception:
    pass

ok(f"Latenza media: {avg_lat:.2f}ms | Peak memory: {peak_mb:.2f}MB")
forecast_policy = _build_forecast_policy(r2, best_thr)
info(
    "Politica forecast: "
    f"{forecast_policy['value_mode']} | "
    f"R2={fmt_metric(forecast_policy['regression_r2'])} | "
    f"affidabilita={forecast_policy['regression_reliability']}"
)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 5 â€” Valutazione LSTM (opzionale)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
step(5, TOTAL_STEPS, "Valutazione idoneitÃ  LSTM")

LSTM_MIN_SEQUENCES   = 120
LSTM_MIN_TRAIN_SEQUENCES = 60
LSTM_MIN_VALID_SEQUENCES = 24
LSTM_MIN_POS_TRAIN   = 8
LSTM_MIN_POS_VALID   = 4

# Calcola sequenze disponibili sullo split temporale per conducente
train_sequences_lstm = _count_lstm_sequences(train_frame, LSTM_SEQ_LEN)
valid_sequences_lstm = _count_lstm_sequences(val_frame, LSTM_SEQ_LEN)
n_sequences = train_sequences_lstm + valid_sequences_lstm
n_train_rows_lstm = int(len(train_frame))
n_valid_rows_lstm = int(len(val_frame))
n_pos_train = int(yc_train.sum())
n_pos_valid = int(yc_val.sum())

info(f"Sequenze LSTM disponibili: train={train_sequences_lstm} | validation={valid_sequences_lstm} | totali={n_sequences} (min {LSTM_MIN_SEQUENCES})")
info(f"Righe train: {n_train_rows_lstm} | Righe val: {n_valid_rows_lstm}")
info(f"Positivi train: {n_pos_train} (min {LSTM_MIN_POS_TRAIN})")
info(f"Positivi val: {n_pos_valid} (min {LSTM_MIN_POS_VALID})")

lstm_failures = []
if not ENABLE_LSTM:
    lstm_failures.append("LSTM disattivata per configurazione (DHA_ENABLE_LSTM=0)")
if n_sequences    < LSTM_MIN_SEQUENCES:   lstm_failures.append(f"sequenze {n_sequences} < {LSTM_MIN_SEQUENCES}")
if train_sequences_lstm < LSTM_MIN_TRAIN_SEQUENCES: lstm_failures.append(f"train_sequences {train_sequences_lstm} < {LSTM_MIN_TRAIN_SEQUENCES}")
if valid_sequences_lstm < LSTM_MIN_VALID_SEQUENCES: lstm_failures.append(f"valid_sequences {valid_sequences_lstm} < {LSTM_MIN_VALID_SEQUENCES}")
if n_pos_train    < LSTM_MIN_POS_TRAIN:   lstm_failures.append(f"positivi_train {n_pos_train} < {LSTM_MIN_POS_TRAIN}")
if n_pos_valid    < LSTM_MIN_POS_VALID:   lstm_failures.append(f"positivi_val {n_pos_valid} < {LSTM_MIN_POS_VALID}")
if yc_train.nunique() < 2:                lstm_failures.append("train split senza entrambe le classi")
if yc_val.nunique() < 2:                  lstm_failures.append("validation split senza entrambe le classi")

lstm_disabled = not ENABLE_LSTM
lstm_evaluable = ENABLE_LSTM and len(lstm_failures) == 0
lstm_status = {
    "evaluable": lstm_evaluable,
    "candidate_only": not lstm_evaluable,
    "disabled": lstm_disabled,
    "policy": {
        "enabled": bool(ENABLE_LSTM),
        "default_enabled": False,
        "mode": "disabled_by_default" if not ENABLE_LSTM else "enabled",
        "forecast_policy": forecast_policy,
    },
    "reason": (
        "LSTM disattivata per configurazione."
        if lstm_disabled
        else ("LSTM pronto per training." if lstm_evaluable
              else "LSTM non valutabile sui dati attuali: " + "; ".join(lstm_failures))
    ),
    "thresholds": {
        "min_total_sequences": LSTM_MIN_SEQUENCES,
        "min_train_sequences": LSTM_MIN_TRAIN_SEQUENCES,
        "min_valid_sequences": LSTM_MIN_VALID_SEQUENCES,
        "min_train_positives": LSTM_MIN_POS_TRAIN,
        "min_valid_positives": LSTM_MIN_POS_VALID,
        "require_both_classes": True,
    },
    "observed": {
        "total_sequences": n_sequences,
        "train_sequences": train_sequences_lstm,
        "valid_sequences": valid_sequences_lstm,
        "train_rows": n_train_rows_lstm,
        "valid_rows": n_valid_rows_lstm,
        "train_positives": n_pos_train,
        "valid_positives": n_pos_valid,
        "train_classes": int(yc_train.nunique()),
        "valid_classes": int(yc_val.nunique()),
        "drivers_total": split_stats["drivers_total"],
        "drivers_split": split_stats["drivers_split"],
        "drivers_train_only": split_stats["drivers_train_only"],
    },
    "failures": lstm_failures,
}

if lstm_evaluable:
    ok("LSTM valutabile: avvio training reale.")
else:
    warn(f"LSTM non addestrabile: {'; '.join(lstm_failures)}")
    info("Produzione: XGBoost selezionato come modello finale.")

# Confronto modelli
selected_reason = (
    "XGBoost selezionato come modello di produzione: LSTM disattivata per configurazione."
    if lstm_disabled
    else (
        "XGBoost selezionato come modello di produzione."
        if not lstm_evaluable
        else "XGBoost confermato: criteri minimi soddisfatti ma LSTM non ancora trainato."
    )
)
lstm_registry = {
    "mode": "classifier",
    "artifact_path": None,
    "scaler_path": None,
    "artifact_size_mb": 0.0,
    "evaluable": False,
    "candidate_only": True,
    "disabled": lstm_disabled,
    "policy": lstm_status["policy"],
    "readiness": lstm_status,
    "skip_reason": lstm_status["reason"],
    "seq_length": LSTM_SEQ_LEN,
    "target_shift": FORECAST_HORIZON_MIN,
    "target_shift_unit": "minutes",
    "forecast_horizon_min": FORECAST_HORIZON_MIN,
    "forecast_target": "max_risk_within_horizon",
    "features": LSTM_FEATURES,
    "medians": medians.to_dict(),
    "threshold": 0.5,
    "accuracy": None,
    "balanced_accuracy": None,
    "precision": None,
    "recall": None,
    "auc": None,
    "pr_auc": None,
    "positive_rate": 0.0,
    "predicted_positive_rate": None,
    "latency_ms": None,
    "peak_alloc_mb": None,
    "benchmark": {},
    "classifier_benchmark": {},
    "n_features": len(LSTM_FEATURES),
}

lstm_trained = False
lstm_artifact_path = None
lstm_scaler_path = None
lstm_artifact_size_mb = 0.0
lstm_latency_ms = None
lstm_latency_ratio = None
lstm_benchmark = {}
lstm_metrics = {
    "threshold": 0.5,
    "accuracy": None,
    "balanced_accuracy": None,
    "precision": None,
    "recall": None,
    "auc": None,
    "pr_auc": None,
    "positive_rate": 0.0,
    "predicted_positive_rate": None,
}
lstm_train_sequences = 0
lstm_valid_sequences = 0

selected_model = "xgboost"
selected_reason = (
    "XGBoost selezionato come modello di produzione: LSTM disattivata per configurazione."
    if lstm_disabled
    else (
        "XGBoost selezionato come modello di produzione."
        if not lstm_evaluable
        else "XGBoost confermato: criteri minimi soddisfatti ma LSTM non ancora trainato."
    )
)

if lstm_evaluable:
    try:
        info("Preparazione sequenze LSTM...")
        lstm_train_frame = train_frame.copy()
        lstm_val_frame = val_frame.copy()
        lstm_train_frame.loc[:, LSTM_FEATURES] = lstm_train_frame.loc[:, LSTM_FEATURES].fillna(lstm_medians)
        lstm_val_frame.loc[:, LSTM_FEATURES] = lstm_val_frame.loc[:, LSTM_FEATURES].fillna(lstm_medians)

        seq_train_X, seq_train_y = _build_lstm_sequences(lstm_train_frame, LSTM_FEATURES, LSTM_SEQ_LEN, target_col="target_cls")
        seq_val_X, seq_val_y = _build_lstm_sequences(lstm_val_frame, LSTM_FEATURES, LSTM_SEQ_LEN, target_col="target_cls")
        if seq_train_X is None or seq_train_y is None or len(seq_train_X) == 0 or len(seq_train_y) == 0:
            raise RuntimeError("Nessuna sequenza LSTM valida costruita sul train temporale.")
        if seq_val_X is None or seq_val_y is None or len(seq_val_X) == 0 or len(seq_val_y) == 0:
            raise RuntimeError("Nessuna sequenza LSTM valida costruita sulla validation temporale.")
        if np.unique(seq_train_y).size < 2:
            raise RuntimeError("Sequenze LSTM train con una sola classe: training non significativo.")
        if np.unique(seq_val_y).size < 2:
            warn("Validation LSTM con una sola classe: AUC non calcolabile")

        seq_features = int(seq_train_X.shape[-1])
        seq_len = int(seq_train_X.shape[1])
        lstm_train_sequences = int(len(seq_train_y))
        lstm_valid_sequences = int(len(seq_val_y))
        info(f"Sequenze LSTM totali: train={lstm_train_sequences:,} | validation={lstm_valid_sequences:,}")
        info(f"Positivi LSTM train: {int(np.sum(seq_train_y)):,} | validation: {int(np.sum(seq_val_y)):,}")

        scaler = RobustScaler()
        seq_train_flat = seq_train_X.reshape(-1, seq_features)
        seq_val_flat = seq_val_X.reshape(-1, seq_features)
        scaler.fit(seq_train_flat)
        seq_train_X = scaler.transform(seq_train_flat).reshape(seq_train_X.shape)
        seq_val_X = scaler.transform(seq_val_flat).reshape(seq_val_X.shape)

        seq_train_classes = np.asarray(sorted(np.unique(seq_train_y)))
        class_weight_values = compute_class_weight(
            class_weight="balanced",
            classes=seq_train_classes,
            y=seq_train_y,
        )
        class_weight_map = {int(cls): float(weight) for cls, weight in zip(seq_train_classes, class_weight_values)}
        ok(f"Class weights LSTM: {class_weight_map}")

        tf.keras.backend.clear_session()
        _set_global_seed(42)

        lstm_model = keras.Sequential([
            keras.layers.Input(shape=(seq_len, seq_features)),
            keras.layers.LSTM(48, return_sequences=True),
            keras.layers.Dropout(0.20),
            keras.layers.LSTM(24),
            keras.layers.Dropout(0.10),
            keras.layers.Dense(16, activation="relu"),
            keras.layers.Dense(1, activation="sigmoid"),
        ])
        lstm_model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=1e-3),
            loss="binary_crossentropy",
            metrics=[
                keras.metrics.AUC(name="auc"),
                keras.metrics.BinaryAccuracy(name="accuracy"),
                keras.metrics.Precision(name="precision"),
                keras.metrics.Recall(name="recall"),
            ],
        )

        callbacks = [
            keras.callbacks.EarlyStopping(monitor="val_loss", patience=5, restore_best_weights=True),
            keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=3, min_lr=1e-5, verbose=0),
        ]

        info(f"\nTraining LSTM (epoche {'15' if SMOKE else '30'})...")
        t_lstm_start = time.time()
        lstm_model.fit(
            seq_train_X,
            seq_train_y,
            validation_data=(seq_val_X, seq_val_y),
            epochs=15 if SMOKE else 30,
            batch_size=32,
            callbacks=callbacks,
            class_weight=class_weight_map,
            verbose=0,
            shuffle=True,
        )
        t_lstm = time.time() - t_lstm_start
        ok(f"LSTM addestrato in {t_lstm:.1f}s")

        info("Calcolo metriche LSTM...")
        lstm_val_proba = lstm_model.predict(seq_val_X, verbose=0).reshape(-1)
        thresholds = np.linspace(0.01, 0.99, 200)
        best_lstm_thr = 0.5
        best_lstm_ba = 0.0
        for thr in thresholds:
            preds = (lstm_val_proba >= thr).astype(int)
            if preds.sum() == 0 or preds.sum() == len(preds):
                continue
            try:
                ba_thr = balanced_accuracy_score(seq_val_y, preds)
                if ba_thr > best_lstm_ba:
                    best_lstm_ba = ba_thr
                    best_lstm_thr = thr
            except Exception:
                pass

        lstm_val_pred = (lstm_val_proba >= best_lstm_thr).astype(int)
        lstm_auc = None
        lstm_pr_auc = None
        lstm_acc = None
        lstm_ba = None
        lstm_prec = None
        lstm_rec = None

        try:
            if np.unique(seq_val_y).size > 1:
                lstm_auc = float(roc_auc_score(seq_val_y, lstm_val_proba))
                lstm_pr_auc = float(average_precision_score(seq_val_y, lstm_val_proba))
            else:
                warn("Validation LSTM con una sola classe: AUC non calcolabile")
        except Exception as exc:
            warn(f"AUC LSTM: {exc}")

        try:
            lstm_ba = float(balanced_accuracy_score(seq_val_y, lstm_val_pred))
            lstm_acc = float((lstm_val_pred == seq_val_y).mean())
        except Exception:
            pass

        try:
            lstm_prec = float(precision_score(seq_val_y, lstm_val_pred, zero_division=0))
            lstm_rec = float(recall_score(seq_val_y, lstm_val_pred, zero_division=0))
        except Exception:
            pass

        ok(f"LSTM AUC={fmt_metric(lstm_auc)} | PR-AUC={fmt_metric(lstm_pr_auc)}")
        ok(f"LSTM Balanced Acc={fmt_metric(lstm_ba)} | Precision={fmt_metric(lstm_prec)} | Recall={fmt_metric(lstm_rec)}")
        ok(f"LSTM soglia ottimale: {best_lstm_thr:.4f}")

        info("Benchmark latenza inferenza LSTM...")
        N_WARMUP_LSTM = 3 if SMOKE else 5
        N_BENCH_LSTM = 10 if SMOKE else 20
        lstm_bench_input = seq_val_X[:1]
        for _ in range(N_WARMUP_LSTM):
            lstm_model.predict(lstm_bench_input, verbose=0)

        lstm_lat_times = []
        for _ in range(N_BENCH_LSTM):
            t1 = time.perf_counter()
            lstm_model.predict(lstm_bench_input, verbose=0)
            lstm_lat_times.append((time.perf_counter() - t1) * 1000)

        lstm_latency_ms = float(np.mean(lstm_lat_times))
        lstm_peak_mb = 0.0
        try:
            import tracemalloc

            tracemalloc.start()
            lstm_model.predict(lstm_bench_input, verbose=0)
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            lstm_peak_mb = peak / (1024 * 1024)
        except Exception:
            pass

        ok(f"LSTM latenza media: {lstm_latency_ms:.2f}ms | Peak memory: {lstm_peak_mb:.2f}MB")

        lstm_artifact_path = _MODELS_DIR / f"lstm_predictor_{_TS}.keras"
        lstm_scaler_path = _MODELS_DIR / f"lstm_scaler_{_TS}.joblib"
        info(f"Salvataggio modello LSTM: {lstm_artifact_path.name}")
        lstm_model.save(str(lstm_artifact_path))
        joblib.dump(scaler, str(lstm_scaler_path), compress=3)
        lstm_artifact_size_mb = lstm_artifact_path.stat().st_size / (1024 * 1024)
        ok(f"Artefatto LSTM salvato: {lstm_artifact_size_mb:.2f}MB")
        ok(f"Scaler LSTM salvato: {lstm_scaler_path.name}")

        lstm_latency_ratio = (lstm_latency_ms / avg_lat) if avg_lat and avg_lat > 0 else None
        auc_delta = (lstm_auc - auc) if (lstm_auc is not None and auc is not None) else None
        ba_delta = (lstm_ba - ba) if (lstm_ba is not None and ba is not None) else None
        rec_delta = (lstm_rec - rec) if (lstm_rec is not None and rec is not None) else None
        latency_ok = lstm_latency_ratio is None or lstm_latency_ratio <= MAX_LATENCY_RATIO
        lstm_meets_criteria = bool(
            auc_delta is not None and auc_delta >= MIN_AUC_GAIN
            and ba_delta is not None and ba_delta >= MIN_BALANCED_ACCURACY_GAIN
            and rec_delta is not None and rec_delta >= MIN_RECALL_GAIN
            and latency_ok
        )

        def _delta_text(value):
            return "N/A" if value is None else f"{value:+.4f}"

        if lstm_meets_criteria:
            selected_model = "lstm"
            selected_reason = (
                "LSTM selezionato per produzione: "
                f"AUC {fmt_metric(lstm_auc)} (delta {_delta_text(auc_delta)}), "
                f"Balanced Acc {fmt_metric(lstm_ba)} (delta {_delta_text(ba_delta)}), "
                f"Recall {fmt_metric(lstm_rec)} (delta {_delta_text(rec_delta)}), "
                f"latenza {fmt_metric(lstm_latency_ratio, 2)}x."
            )
        else:
            selected_model = "xgboost"
            selected_reason = (
                "XGBoost resta il modello di produzione: "
                f"LSTM non supera i criteri (AUC delta {_delta_text(auc_delta)}, "
                f"Balanced Acc delta {_delta_text(ba_delta)}, "
                f"Recall delta {_delta_text(rec_delta)}, "
                f"latenza {fmt_metric(lstm_latency_ratio, 2)}x)."
            )

        lstm_metrics = {
            "threshold": float(best_lstm_thr),
            "accuracy": _safe(lstm_acc),
            "balanced_accuracy": _safe(lstm_ba),
            "precision": _safe(lstm_prec),
            "recall": _safe(lstm_rec),
            "auc": _safe(lstm_auc),
            "pr_auc": _safe(lstm_pr_auc),
            "positive_rate": _safe(float(seq_val_y.mean())),
            "predicted_positive_rate": _safe(float(lstm_val_pred.mean())),
        }
        lstm_benchmark = {
            "warmup_runs": float(N_WARMUP_LSTM),
            "runs": float(N_BENCH_LSTM),
            "total_latency_ms": _safe(float(np.sum(lstm_lat_times))),
            "avg_latency_ms": _safe(lstm_latency_ms),
            "peak_alloc_mb": _safe(lstm_peak_mb),
            "current_alloc_mb": _safe(lstm_peak_mb),
        }
        lstm_registry.update({
            "artifact_path": str(lstm_artifact_path.relative_to(_ROOT)),
            "scaler_path": str(lstm_scaler_path.relative_to(_ROOT)),
            "artifact_size_mb": _safe(lstm_artifact_size_mb),
            "evaluable": True,
            "candidate_only": False,
            "skip_reason": None,
            "target_shift": FORECAST_HORIZON_MIN,
            "target_shift_unit": "minutes",
            "forecast_horizon_min": FORECAST_HORIZON_MIN,
            "forecast_target": "max_risk_within_horizon",
            "threshold": float(best_lstm_thr),
            "accuracy": _safe(lstm_acc),
            "balanced_accuracy": _safe(lstm_ba),
            "precision": _safe(lstm_prec),
            "recall": _safe(lstm_rec),
            "auc": _safe(lstm_auc),
            "pr_auc": _safe(lstm_pr_auc),
            "positive_rate": _safe(float(seq_val_y.mean())),
            "predicted_positive_rate": _safe(float(lstm_val_pred.mean())),
            "latency_ms": _safe(lstm_latency_ms),
            "peak_alloc_mb": _safe(lstm_peak_mb),
            "benchmark": lstm_benchmark,
            "classifier_benchmark": lstm_benchmark,
            "trained_at": _TS,
            "version": _TS,
            "n_features": len(LSTM_FEATURES),
            "feature_count": len(LSTM_FEATURES),
            "features": LSTM_FEATURES,
            "medians": lstm_medians.to_dict(),
            "decision": selected_model,
            "decision_reason": selected_reason,
            "readiness": lstm_status,
            "reason": "LSTM addestrato e salvato correttamente.",
            "failures": [],
        })
        lstm_status.update({
            "evaluable": True,
            "candidate_only": False,
            "reason": "LSTM addestrato e salvato correttamente.",
            "failures": [],
            "trained": True,
            "selected_model": selected_model,
            "selected_reason": selected_reason,
            "train_sequences": lstm_train_sequences,
            "valid_sequences": lstm_valid_sequences,
            "latency_ms": _safe(lstm_latency_ms),
            "latency_ratio": _safe(lstm_latency_ratio),
        })
        lstm_trained = True
        ok("LSTM addestrato e salvato correttamente.")
    except Exception as exc:
        warn(f"Training LSTM non riuscito: {exc}")
        lstm_registry.update({
            "reason": "LSTM non addestrato: " + str(exc),
            "skip_reason": "LSTM non addestrato: " + str(exc),
            "failures": lstm_failures + [str(exc)],
            "readiness": lstm_status,
        })
        lstm_status.update({
            "candidate_only": True,
            "evaluable": False,
            "reason": "LSTM non addestrato: " + str(exc),
            "failures": lstm_failures + [str(exc)],
        })
        selected_model = "xgboost"
        selected_reason = "XGBoost selezionato come fallback: LSTM non completato."

if lstm_evaluable and not lstm_trained:
    warn("LSTM valutabile ma non addestrato: resta candidata.")

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STEP 6 â€” Salvataggio artefatti
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
holdout_report = {
    "enabled": bool(holdout_meta.get("enabled") and len(holdout_df) > 0),
    "holdout_meta": holdout_meta,
    "selected_model": selected_model,
    "selected_reason": selected_reason,
    "xgboost": None,
    "lstm": None,
    "comparison": None,
}

if holdout_report["enabled"]:
    info("Valutazione holdout finale per driver...")

    holdout_xgb_frame = holdout_df.copy()
    holdout_xgb_X = holdout_xgb_frame[FEATURES].copy().fillna(train_medians)
    holdout_xgb_y = holdout_xgb_frame["target_cls"].astype(int).to_numpy()
    holdout_xgb_proba = xgb_cls.predict_proba(holdout_xgb_X)[:, 1]
    holdout_xgb_summary = _binary_prediction_summary(holdout_xgb_y, holdout_xgb_proba, best_thr)
    holdout_xgb_summary["drivers"] = int(holdout_xgb_frame["id_conducente"].nunique())
    holdout_xgb_summary["records"] = int(len(holdout_xgb_frame))
    holdout_xgb_summary["per_driver"] = _driver_prediction_summary(
        [
            {
                "driver_id": driver_id,
                "y_true": int(y_true),
                "y_score": float(y_score),
            }
            for driver_id, y_true, y_score in zip(
                holdout_xgb_frame["id_conducente"].tolist(),
                holdout_xgb_y.tolist(),
                holdout_xgb_proba.tolist(),
            )
        ],
        best_thr,
    )
    holdout_report["xgboost"] = holdout_xgb_summary

    if lstm_trained:
        holdout_lstm_frame = holdout_df.copy()
        holdout_lstm_frame.loc[:, LSTM_FEATURES] = holdout_lstm_frame.loc[:, LSTM_FEATURES].fillna(lstm_medians)
        seq_holdout_X, seq_holdout_y, seq_holdout_drivers = _build_lstm_sequence_dataset(
            holdout_lstm_frame,
            LSTM_FEATURES,
            LSTM_SEQ_LEN,
            target_col="target_cls",
        )
        if seq_holdout_X is not None and seq_holdout_y is not None and len(seq_holdout_y) > 0:
            lstm_holdout_proba = lstm_model.predict(seq_holdout_X, verbose=0).reshape(-1)
            lstm_holdout_summary = _binary_prediction_summary(seq_holdout_y, lstm_holdout_proba, best_lstm_thr)
            lstm_holdout_summary["sequence_rows"] = int(len(seq_holdout_y))
            lstm_holdout_summary["drivers"] = int(len(set(seq_holdout_drivers)))
            lstm_holdout_summary["per_driver"] = _driver_prediction_summary(
                [
                    {
                        "driver_id": driver_id,
                        "y_true": int(y_true),
                        "y_score": float(y_score),
                    }
                    for driver_id, y_true, y_score in zip(
                        seq_holdout_drivers,
                        seq_holdout_y.tolist(),
                        lstm_holdout_proba.tolist(),
                    )
                ],
                best_lstm_thr,
            )
            holdout_report["lstm"] = lstm_holdout_summary
        else:
            holdout_report["lstm"] = {
                "enabled": False,
                "reason": "Nessuna sequenza holdout LSTM costruita.",
            }
    else:
        holdout_report["lstm"] = {
            "enabled": False,
            "reason": "LSTM disattivata per configurazione." if lstm_disabled else "LSTM non addestrato.",
        }

    if isinstance(holdout_report.get("xgboost"), dict) and isinstance(holdout_report.get("lstm"), dict):
        xgb_holdout_auc = holdout_report["xgboost"].get("auc")
        lstm_holdout_auc = holdout_report["lstm"].get("auc")
        xgb_holdout_ba = holdout_report["xgboost"].get("balanced_accuracy")
        lstm_holdout_ba = holdout_report["lstm"].get("balanced_accuracy")
        xgb_holdout_rec = holdout_report["xgboost"].get("recall")
        lstm_holdout_rec = holdout_report["lstm"].get("recall")
        holdout_report["comparison"] = {
            "auc_delta": _safe((lstm_holdout_auc - xgb_holdout_auc) if None not in (lstm_holdout_auc, xgb_holdout_auc) else None),
            "balanced_accuracy_delta": _safe((lstm_holdout_ba - xgb_holdout_ba) if None not in (lstm_holdout_ba, xgb_holdout_ba) else None),
            "recall_delta": _safe((lstm_holdout_rec - xgb_holdout_rec) if None not in (lstm_holdout_rec, xgb_holdout_rec) else None),
            "latency_ratio": _safe(lstm_latency_ratio),
        }
else:
    holdout_report["reason"] = "Holdout driver non disponibile o vuoto."
    warn("Holdout driver non disponibile: report finale limitato allo split temporale.")

holdout_summary = {
    "enabled": bool(holdout_report.get("enabled")),
    "reason": holdout_report.get("reason"),
    "holdout_rows": int(holdout_meta.get("holdout_rows", 0)),
    "holdout_drivers": int(holdout_meta.get("drivers_holdout", 0)),
    "comparison": holdout_report.get("comparison"),
}
if isinstance(holdout_report.get("xgboost"), dict):
    holdout_summary["xgboost"] = {
        "rows": holdout_report["xgboost"].get("rows"),
        "auc": holdout_report["xgboost"].get("auc"),
        "balanced_accuracy": holdout_report["xgboost"].get("balanced_accuracy"),
        "recall": holdout_report["xgboost"].get("recall"),
    }
if isinstance(holdout_report.get("lstm"), dict):
    holdout_summary["lstm"] = {
        "rows": holdout_report["lstm"].get("rows"),
        "auc": holdout_report["lstm"].get("auc"),
        "balanced_accuracy": holdout_report["lstm"].get("balanced_accuracy"),
        "recall": holdout_report["lstm"].get("recall"),
        "sequence_rows": holdout_report["lstm"].get("sequence_rows"),
    }

robust_validation = {
    "enabled": False,
    "requested_runs": 0,
    "completed_runs": 0,
    "summary": {},
    "runs": [],
}
try:
    robust_validation = _robust_validation_summary(
        df,
        xgb_reg,
        xgb_cls,
        FEATURES,
        float(best_thr),
        ROBUST_VALIDATION_RUNS,
        ROBUST_VALIDATION_HOLDOUT,
        ROBUST_VALIDATION_SPLIT,
        LSTM_SEQ_LEN,
        ROBUST_VALIDATION_SEEDS,
    )
    rv_summary = robust_validation.get("summary") or {}
    rv_cls_stats = (rv_summary.get("classification") or {}).get("auc") or {}
    rv_reg_stats = (rv_summary.get("regression") or {}).get("r2") or {}
    if robust_validation.get("completed_runs", 0) > 0:
        ok(
            "Robust validation: "
            f"{robust_validation['completed_runs']} run | "
            f"AUC {fmt_metric(rv_cls_stats.get('mean') if isinstance(rv_cls_stats, dict) else None)} ± {fmt_metric(rv_cls_stats.get('std') if isinstance(rv_cls_stats, dict) else None)} | "
            f"R2 {fmt_metric(rv_reg_stats.get('mean') if isinstance(rv_reg_stats, dict) else None)}"
        )
    else:
        warn("Robust validation: nessuno split valido completato.")
except Exception as exc:
    robust_validation = {
        "enabled": False,
        "requested_runs": ROBUST_VALIDATION_RUNS,
        "completed_runs": 0,
        "summary": {},
        "runs": [],
        "error": str(exc),
    }
    warn(f"Robust validation non disponibile: {exc}")

step(6, TOTAL_STEPS, "Salvataggio artefatti e registro produzione")

# â”€â”€ 6a. Benchmark latenza â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
info("Benchmark latenza inferenza XGBoost...")
N_WARMUP = 5
N_BENCH  = 25
X_bench  = X_val.head(1)

for _ in range(N_WARMUP):
    xgb_cls.predict_proba(X_bench)

lat_times = []
for _ in range(N_BENCH):
    t1 = time.perf_counter()
    xgb_cls.predict_proba(X_bench)
    lat_times.append((time.perf_counter() - t1) * 1000)

avg_lat = float(np.mean(lat_times))
peak_mb = 0.0
try:
    import tracemalloc
    tracemalloc.start()
    xgb_cls.predict_proba(X_bench)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    peak_mb = peak / (1024 * 1024)
except Exception:
    pass

ok(f"Latenza media: {avg_lat:.2f}ms | Peak memory: {peak_mb:.2f}MB")

# â”€â”€ 6b. Payload joblib â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
artifact_path = _MODELS_DIR / f"risk_predictor_{_TS}.joblib"
report_path = _MODELS_DIR / f"training_report_{_TS}.json"
info(f"Salvataggio modello: {artifact_path.name}")

payload = {
    "features": FEATURES,
    "regressor": xgb_reg,
    "classifier": xgb_cls,
    "threshold": float(best_thr),
    "forecast_horizon_min": FORECAST_HORIZON_MIN,
    "forecast_target": "max_risk_within_horizon",
    "forecast_policy": forecast_policy,
    "regression_metrics": {
        "mae": _safe(mae),
        "rmse": _safe(rmse),
        "r2": _safe(r2),
    },
    "classifier_metrics": {
        "critical_threshold": _safe(best_thr),
        "critical_accuracy": _safe(acc),
        "critical_balanced_accuracy": _safe(ba),
        "critical_precision": _safe(prec),
        "critical_recall": _safe(rec),
        "critical_auc": _safe(auc),
        "critical_pr_auc": _safe(pr_auc),
        "critical_positive_rate": _safe(float(yc_val.mean())),
        "critical_predicted_positive_rate": _safe(float(yc_pred.mean())) if hasattr(yc_pred, "mean") else None,
    },
    "medians": medians.to_dict(),
    "classifier_meta": {
        "features": FEATURES,
        "threshold": float(best_thr),
        "forecast_horizon_min": FORECAST_HORIZON_MIN,
        "forecast_target": "max_risk_within_horizon",
        "scale_pos_weight": float(scale_pos),
        "metrics": {
            "critical_threshold": float(best_thr),
            "critical_accuracy": float(acc) if acc is not None else None,
            "critical_balanced_accuracy": float(ba) if ba is not None else None,
            "critical_precision": float(prec) if prec is not None else None,
            "critical_recall": float(rec) if rec is not None else None,
            "critical_auc": float(auc) if auc is not None else None,
            "critical_pr_auc": float(pr_auc) if pr_auc is not None else None,
            "critical_positive_rate": float(yc_val.mean()),
            "critical_predicted_positive_rate": float(yc_pred.mean()) if hasattr(yc_pred, "mean") else None,
        },
    },
    "training_mode": "smoke" if SMOKE else "real",
    "trained_at": _TS,
    "days_history": DAYS_HISTORY,
    "history_rows": len(df),
    "output_dir": str(_MODELS_DIR.relative_to(_ROOT)),
    "robust_validation": robust_validation,
}

joblib.dump(payload, str(artifact_path), compress=3)
artifact_size_mb = artifact_path.stat().st_size / (1024 * 1024)
ok(f"Joblib salvato: {artifact_size_mb:.2f}MB")

# â”€â”€ 6c. Registro produzione â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
registry_path = _MODELS_DIR / "production_model.json"
info(f"Aggiornamento registro produzione: {registry_path.name}")

def _safe(v):
    """Converte NaN/inf in None per JSON."""
    if v is None:
        return None
    try:
        f = float(v)
        return None if (math.isnan(f) or math.isinf(f)) else round(f, 6)
    except Exception:
        return v

registry = {
    "schema_version": 1,
    "baseline_model": "xgboost",
    "production_model": selected_model,
    "selected_reason": selected_reason,
    "forecast_horizon_min": FORECAST_HORIZON_MIN,
    "forecast_target": "max_risk_within_horizon",
    "forecast_policy": forecast_policy,
    "criteria": {
        "min_auc_gain": 0.03,
        "min_balanced_accuracy_gain": 0.02,
        "min_recall_gain": 0.0,
        "max_latency_ratio": 1.75,
    },
    "comparisons": {
        "xgboost": {
            "critical_auc": _safe(auc),
            "critical_balanced_accuracy": _safe(ba),
            "critical_recall": _safe(rec),
            "avg_latency_ms": _safe(avg_lat),
            "peak_alloc_mb": _safe(peak_mb),
        },
        "lstm": {
            "critical_auc": _safe(lstm_registry.get("auc")),
            "critical_balanced_accuracy": _safe(lstm_registry.get("balanced_accuracy")),
            "critical_recall": _safe(lstm_registry.get("recall")),
            "avg_latency_ms": _safe(lstm_registry.get("latency_ms")),
            "peak_alloc_mb": _safe(lstm_registry.get("peak_alloc_mb")),
        },
    },
    "latency_ratio": _safe(lstm_latency_ratio),
    "lstm_status": lstm_status,
    "created_at": _TS,
    "training_mode": "smoke" if SMOKE else "real",
    "history_rows": len(df),
    "output_dir": str(_MODELS_DIR.relative_to(_ROOT)),
    "training_report_path": str(report_path.relative_to(_ROOT)),
    "holdout_split": holdout_meta,
    "holdout_summary": holdout_summary,
    "robust_validation": robust_validation,
    "xgboost": {
        "mode": "classifier",
        "artifact_path": str(artifact_path.relative_to(_ROOT)),
        "artifact_size_mb": _safe(artifact_size_mb),
        "forecast_horizon_min": FORECAST_HORIZON_MIN,
        "forecast_target": "max_risk_within_horizon",
        "forecast_policy": forecast_policy,
        "regression_metrics": {
            "mae": _safe(mae),
            "rmse": _safe(rmse),
            "r2": _safe(r2),
            "critical_threshold": _safe(best_thr),
            "critical_accuracy": _safe(acc),
            "critical_balanced_accuracy": _safe(ba),
            "critical_precision": _safe(prec),
            "critical_recall": _safe(rec),
            "critical_pr_auc": _safe(pr_auc),
            "critical_positive_rate": _safe(float(yc_val.mean())),
            "critical_predicted_positive_rate": _safe(float(yc_pred.mean())) if hasattr(yc_pred, "mean") else None,
            "critical_auc": _safe(auc),
        },
        "classifier_metrics": {
            "critical_threshold": _safe(best_thr),
            "critical_accuracy": _safe(acc),
            "critical_balanced_accuracy": _safe(ba),
            "critical_precision": _safe(prec),
            "critical_recall": _safe(rec),
            "critical_auc": _safe(auc),
            "critical_pr_auc": _safe(pr_auc),
            "critical_positive_rate": _safe(float(yc_val.mean())),
            "critical_predicted_positive_rate": _safe(float(yc_pred.mean())) if hasattr(yc_pred, "mean") else None,
        },
        "classifier_benchmark": {
            "warmup_runs": float(N_WARMUP),
            "runs": float(N_BENCH),
            "total_latency_ms": _safe(float(np.sum(lat_times))),
            "avg_latency_ms": _safe(avg_lat),
            "peak_alloc_mb": _safe(peak_mb),
            "current_alloc_mb": _safe(peak_mb),
        },
    },
    "lstm": lstm_registry,
}

registry_path.write_text(json.dumps(registry, indent=2, ensure_ascii=False), encoding="utf-8")
training_report = {
    "schema_version": 1,
    "created_at": _TS,
    "training_mode": "smoke" if SMOKE else "real",
    "forecast": {
        "horizon_minutes": FORECAST_HORIZON_MIN,
        "target": "max_risk_within_horizon",
        "policy": forecast_policy,
    },
    "dataset": {
        "history_rows": int(len(df)),
        "development_rows": int(len(development_df)),
        "holdout_rows": int(len(holdout_df)),
        "holdout_drivers": int(holdout_meta.get("drivers_holdout", 0)),
    },
    "split": {
        "driver_holdout": holdout_meta,
        "temporal_validation": split_stats,
    },
    "validation": {
        "xgboost": {
            "regression": {
                "mae": _safe(mae),
                "rmse": _safe(rmse),
                "r2": _safe(r2),
            },
            "classification": {
                "threshold": _safe(best_thr),
                "accuracy": _safe(acc),
                "balanced_accuracy": _safe(ba),
                "precision": _safe(prec),
                "recall": _safe(rec),
                "auc": _safe(auc),
                "pr_auc": _safe(pr_auc),
                "positive_rate": _safe(float(yc_val.mean())),
                "predicted_positive_rate": _safe(float(yc_pred.mean())) if hasattr(yc_pred, "mean") else None,
            },
            "benchmark": {
                "warmup_runs": float(N_WARMUP),
                "runs": float(N_BENCH),
                "avg_latency_ms": _safe(avg_lat),
                "peak_alloc_mb": _safe(peak_mb),
            },
            "feature_importance_top10": [
                {"feature": feat, "importance": _safe(imp)}
                for feat, imp in list(fi_dict.items())[:10]
            ],
        },
        "lstm": {
            "evaluable": lstm_evaluable,
            "trained": lstm_trained,
            "readiness": lstm_status,
            "metrics": lstm_metrics,
            "benchmark": lstm_benchmark,
            "feature_count": len(LSTM_FEATURES),
            "features": LSTM_FEATURES,
            "artifact": None if lstm_artifact_path is None else str(lstm_artifact_path.relative_to(_ROOT)),
            "scaler": None if lstm_scaler_path is None else str(lstm_scaler_path.relative_to(_ROOT)),
        },
    },
    "holdout": holdout_report,
    "holdout_summary": holdout_summary,
    "robust_validation": robust_validation,
    "selection": {
        "production_model": selected_model,
        "selected_reason": selected_reason,
        "criteria": {
            "min_auc_gain": MIN_AUC_GAIN,
            "min_balanced_accuracy_gain": MIN_BALANCED_ACCURACY_GAIN,
            "min_recall_gain": MIN_RECALL_GAIN,
            "max_latency_ratio": MAX_LATENCY_RATIO,
        },
    },
    "artifacts": {
        "xgboost": str(artifact_path.relative_to(_ROOT)),
        "lstm": None if lstm_artifact_path is None else str(lstm_artifact_path.relative_to(_ROOT)),
        "lstm_scaler": None if lstm_scaler_path is None else str(lstm_scaler_path.relative_to(_ROOT)),
    },
}
report_path.write_text(json.dumps(training_report, indent=2, ensure_ascii=False), encoding="utf-8")
ok(f"Report training scritto: {report_path}")
ok(f"Registro produzione aggiornato: {registry_path}")

# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# Riepilogo finale
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
elapsed = time.time() - _t0
log("")
log("=" * 60)
log(f"  TRAINING COMPLETATO IN {elapsed:.1f}s")
log("=" * 60)
log(f"  Modello prod.: {selected_model}")
log(f"  Artefatto XGB: {artifact_path.name}")
if lstm_artifact_path is not None:
    log(f"  Artefatto LSTM: {lstm_artifact_path.name}")
log(f"  Registro:   production_model.json")
log(f"  Report:     {report_path.name}")
log(f"  Forecast:   max rischio entro {FORECAST_HORIZON_MIN} minuti")
log(f"  Policy:     {forecast_policy['value_mode']} | R2={fmt_metric(forecast_policy['regression_r2'])}")
log(f"  Robustezza: {robust_validation.get('completed_runs', 0)} run")
log(f"  Holdout:    {holdout_meta.get('drivers_holdout', 0)} driver | righe {holdout_meta.get('holdout_rows', 0)}")
log(f"  Righe:      {len(df):,}")
log(f"  AUC:        {fmt_metric(auc)}")
log(f"  Recall:     {fmt_metric(rec)}")
log(f"  Latenza:    {avg_lat:.2f}ms")
log("=" * 60)
log("  [OK]  Produzione aggiornata. Il nuovo modello e' attivo.")
log("=" * 60)
log("")

sys.exit(0)

