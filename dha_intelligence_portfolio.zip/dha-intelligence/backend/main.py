﻿"""
main.py â€” Backend FastAPI per DHA Intelligence v1.
Espone endpoint REST che il frontend chiama via fetch().
Avvio: uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import os
import pathlib
import secrets
import sys
import threading
import time as _time
import subprocess
import datetime as _dt2
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy as _deepcopy
from typing import Optional

from fastapi import FastAPI, Query, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse

from backend.db import safe_query, test_connection

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s  %(message)s")

app = FastAPI(title="DHA Intelligence API v1", version="1.0.0")

# â”€â”€â”€ CORS (permissivo in dev, restringere in prod) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
def _parse_csv_env(name: str) -> list[str]:
    raw = os.environ.get(name, "")
    return [item for item in (part.strip() for part in raw.split(",")) if item]


# CORS is optional: same-origin pages work without it.
_cors_origins = _parse_csv_env("DHA_CORS_ORIGINS")
if _cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["*"],
    )

_LEGACY_PRIVATE_TOKEN = os.environ.get("DHA_PRIVATE_TOKEN", "").strip()
_AUTH_COOKIE_NAME = os.environ.get("DHA_SESSION_COOKIE_NAME", "dha_session").strip() or "dha_session"
_AUTH_COOKIE_SECURE = os.environ.get("DHA_AUTH_COOKIE_SECURE", "").strip().lower() in {"1", "true", "yes", "on"}
_SESSION_TTL_SECONDS = int(os.environ.get("DHA_SESSION_TTL_SECONDS", "28800"))
_AUTH_SECRET = (os.environ.get("SECRET_KEY") or os.environ.get("DHA_AUTH_SECRET") or "").strip()


def _bool_env(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    if not raw:
        return default
    return raw in {"1", "true", "yes", "on"}


def _normalize_username(username: str) -> str:
    return username.strip().casefold()


def _pbkdf2_hash_password(password: str, salt: bytes | None = None, iterations: int = 210000) -> str:
    salt = salt or secrets.token_bytes(16)
    derived = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    salt_b64 = base64.urlsafe_b64encode(salt).decode("ascii").rstrip("=")
    hash_b64 = base64.urlsafe_b64encode(derived).decode("ascii").rstrip("=")
    return f"pbkdf2_sha256${iterations}${salt_b64}${hash_b64}"


def _verify_pbkdf2_password(password: str, stored: str) -> bool:
    try:
        scheme, iterations_str, salt_b64, hash_b64 = stored.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        iterations = int(iterations_str)
        salt = base64.urlsafe_b64decode(salt_b64 + "=" * (-len(salt_b64) % 4))
        expected = base64.urlsafe_b64decode(hash_b64 + "=" * (-len(hash_b64) % 4))
        candidate = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
        return hmac.compare_digest(candidate, expected)
    except Exception:
        return False


def _load_auth_users() -> dict[str, dict[str, str]]:
    users: dict[str, dict[str, str]] = {}

    raw_users = os.environ.get("DHA_AUTH_USERS_JSON", "").strip()
    if raw_users:
        try:
            parsed = json.loads(raw_users)
        except json.JSONDecodeError as exc:
            raise RuntimeError("DHA_AUTH_USERS_JSON non valido: deve contenere JSON.") from exc

        entries: list[dict] = []
        if isinstance(parsed, dict):
            for username, data in parsed.items():
                if isinstance(data, dict):
                    entry = {"username": username, **data}
                else:
                    entry = {"username": username, "password_hash": str(data)}
                entries.append(entry)
        elif isinstance(parsed, list):
            entries = [item for item in parsed if isinstance(item, dict)]
        else:
            raise RuntimeError("DHA_AUTH_USERS_JSON deve essere un oggetto o una lista JSON.")

        for entry in entries:
            username = str(entry.get("username", "")).strip()
            password_hash = str(entry.get("password_hash", "")).strip()
            if not username or not password_hash:
                continue
            users[_normalize_username(username)] = {
                "username": username,
                "display_name": str(entry.get("display_name") or entry.get("name") or username).strip() or username,
                "password_hash": password_hash,
                "role": str(entry.get("role") or "viewer").strip().lower() or "viewer",
            }

    single_user = os.environ.get("DHA_AUTH_USER", "").strip()
    single_hash = os.environ.get("DHA_AUTH_PASSWORD_HASH", "").strip()
    if single_user and single_hash:
        users[_normalize_username(single_user)] = {
            "username": single_user,
            "display_name": os.environ.get("DHA_AUTH_DISPLAY_NAME", single_user).strip() or single_user,
            "password_hash": single_hash,
            "role": os.environ.get("DHA_AUTH_ROLE", "admin").strip().lower() or "admin",
        }

    return users


# Link-only mode: the app is intentionally public and does not enforce
# application-level authorization. Network access is handled by the reverse
# proxy / firewall / VPN layer.
_AUTH_USERS: dict[str, dict[str, str]] = {}
_AUTH_MODE = "off"
_AUTH_ROUTES_PUBLIC = {
    "/api/auth/config",
    "/api/status",
    "/api/auth/login",
    "/api/auth/logout",
    "/api/auth/me",
}
_AUTH_HTML_PUBLIC = {"/login.html"}
_PUBLIC_OPERATION_ROUTES = {
    "/api/system/models-disk",
    "/api/training/start",
    "/api/training/stop",
    "/api/training/status",
    "/api/training/log",
}

_ROLE_RANK = {"viewer": 10, "operator": 20, "admin": 30}


def _sign_session(payload: dict) -> str:
    if not _AUTH_SECRET:
        raise RuntimeError("Segreto sessione mancante.")
    data = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    encoded = base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")
    signature = hmac.new(_AUTH_SECRET.encode("utf-8"), encoded.encode("ascii"), hashlib.sha256).hexdigest()
    return f"{encoded}.{signature}"


def _decode_session(token: str) -> dict | None:
    if not token or not _AUTH_SECRET:
        return None
    try:
        encoded, signature = token.rsplit(".", 1)
        expected = hmac.new(_AUTH_SECRET.encode("utf-8"), encoded.encode("ascii"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected):
            return None
        payload_raw = base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4))
        payload = json.loads(payload_raw.decode("utf-8"))
        if int(payload.get("exp", 0)) < int(_time.time()):
            return None
        username = _normalize_username(str(payload.get("sub", "")))
        user = _AUTH_USERS.get(username)
        if not user:
            return None
        if str(payload.get("role", "")).strip().lower() != user["role"]:
            return None
        return user
    except Exception:
        return None


def _issue_session_cookie(user: dict) -> str:
    payload = {
        "sub": user["username"],
        "role": user["role"],
        "display_name": user["display_name"],
        "iat": int(_time.time()),
        "exp": int(_time.time()) + _SESSION_TTL_SECONDS,
    }
    return _sign_session(payload)


def _session_user(request: Request | None) -> dict | None:
    if request is None:
        return None
    token = request.cookies.get(_AUTH_COOKIE_NAME, "").strip()
    if token:
        return _decode_session(token)
    return None


def _request_token(request: Request | None) -> str:
    if request is None:
        return ""
    auth = (request.headers.get("authorization") or "").strip()
    if auth.lower().startswith("bearer "):
        return auth.split(None, 1)[1].strip()
    return (request.headers.get("x-dha-private-token") or "").strip()


def _current_user(request: Request | None = None) -> dict | None:
    user = _session_user(request)
    if user is not None:
        return user
    if _AUTH_MODE == "legacy" and _LEGACY_PRIVATE_TOKEN and _request_token(request) and hmac.compare_digest(_request_token(request), _LEGACY_PRIVATE_TOKEN):
        return {
            "username": "legacy-token",
            "display_name": "Legacy Token",
            "role": "admin",
            "password_hash": "",
        }
    return None


def _is_authenticated(request: Request | None = None) -> bool:
    return _current_user(request) is not None


def _is_admin(request: Request | None = None) -> bool:
    user = _current_user(request)
    if not user:
        return False
    return _ROLE_RANK.get(user.get("role", "viewer"), 0) >= _ROLE_RANK["admin"]


def _require_auth(request: Request | None = None) -> dict:
    if _AUTH_MODE == "off":
        return {}
    user = _current_user(request)
    if user is not None:
        return user
    raise HTTPException(status_code=401, detail="Unauthorized")


def _require_admin(request: Request | None = None) -> dict:
    if _AUTH_MODE == "off":
        return {}
    user = _require_auth(request)
    if _ROLE_RANK.get(user.get("role", "viewer"), 0) >= _ROLE_RANK["admin"]:
        return user
    raise HTTPException(status_code=403, detail="Forbidden")


def _require_private_if_configured(request: Request | None = None) -> None:
    """Compat layer per le route gia' esistenti.

    In modalita' sessione richiede un utente autenticato.
    In modalita' legacy mantiene la protezione via token.
    In modalita' disattivata non impone nulla.
    """
    if _AUTH_MODE == "off":
        return
    if _current_user(request) is not None:
        return
    if _AUTH_MODE == "legacy":
        raise HTTPException(status_code=404, detail="Not found")
    raise HTTPException(status_code=401, detail="Unauthorized")

@app.middleware("http")
async def _private_route_guard(request: Request, call_next):
    path = request.url.path
    method = request.method.upper()
    protected = False

    if _AUTH_MODE == "session":
        if method != "OPTIONS":
            if path.startswith("/api/") and path not in _AUTH_ROUTES_PUBLIC and path not in _PUBLIC_OPERATION_ROUTES:
                user = _current_user(request)
                if user is None:
                    return JSONResponse(status_code=401, content={"detail": "Unauthorized"})
                if path in {
                    "/api/system/models-disk",
                    "/api/training/start",
                    "/api/training/stop",
                    "/api/training/status",
                    "/api/training/log",
                } and _ROLE_RANK.get(user.get("role", "viewer"), 0) < _ROLE_RANK["admin"]:
                    return JSONResponse(status_code=403, content={"detail": "Forbidden"})
            if (path == "/" or path.endswith(".html")) and path not in _AUTH_HTML_PUBLIC:
                if _current_user(request) is None:
                    return RedirectResponse(url=f"/login.html?next={path}", status_code=302)
    elif _AUTH_MODE == "legacy":
        protected = (
            path in {
                "/api/drivers",
                "/api/kpi",
                "/api/trend",
                "/api/alerts",
                "/api/alerts/ai-pending",
                "/api/dashboard/summary",
                "/api/drivers/historical",
                "/api/alerts/analysis",
                "/api/ml/predictions",
            }
            or path.startswith("/api/driver/")
            or path.startswith("/api/archivio/")
        )

    if _AUTH_MODE == "legacy" and method != "OPTIONS" and protected:
        if not _current_user(request):
            return JSONResponse(status_code=404, content={"detail": "Not found"})
    return await call_next(request)

# â”€â”€â”€ Serve frontend statico â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
_ROOT = pathlib.Path(__file__).parent.parent   # nuovo sito/


@app.get("/", include_in_schema=False)
async def root():
    return FileResponse(str(_ROOT / "index.html"))


@app.get("/{page}.html", include_in_schema=False)
async def serve_page(page: str):
    """Serve qualsiasi pagina HTML nella cartella root (es. /realtime.html)."""
    target = _ROOT / f"{page}.html"
    if not target.exists():
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"Pagina {page}.html non trovata")
    return FileResponse(str(target))


@app.get("/api/auth/config")
def api_auth_config():
    """Config pubblica per la pagina di login."""
    return {
        "ok": True,
        "mode": _AUTH_MODE,
        "enabled": _AUTH_MODE == "session",
        "cookie_name": _AUTH_COOKIE_NAME,
        "session_ttl_seconds": _SESSION_TTL_SECONDS,
    }


@app.get("/api/auth/me")
def api_auth_me(request: Request):
    """Restituisce l'utente corrente se autenticato."""
    user = _current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return {
        "ok": True,
        "user": {
            "username": user["username"],
            "display_name": user.get("display_name") or user["username"],
            "role": user.get("role", "viewer"),
        },
        "mode": _AUTH_MODE,
    }


@app.post("/api/auth/login")
async def api_auth_login(request: Request):
    """Login enterprise con sessione firmata e cookie HttpOnly."""
    if _AUTH_MODE != "session":
        raise HTTPException(status_code=400, detail="Authentication is not enabled.")

    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail="JSON body richiesto.") from exc

    username = str((payload or {}).get("username", "")).strip()
    password = str((payload or {}).get("password", ""))
    next_path = str((payload or {}).get("next", "/")).strip() or "/"

    user = _AUTH_USERS.get(_normalize_username(username))
    if not user or not _verify_pbkdf2_password(password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Credenziali non valide.")

    session_value = _issue_session_cookie(user)
    response = JSONResponse(
        {
            "ok": True,
            "user": {
                "username": user["username"],
                "display_name": user.get("display_name") or user["username"],
                "role": user.get("role", "viewer"),
            },
            "next": next_path,
        }
    )
    response.set_cookie(
        key=_AUTH_COOKIE_NAME,
        value=session_value,
        max_age=_SESSION_TTL_SECONDS,
        path="/",
        secure=_AUTH_COOKIE_SECURE,
        httponly=True,
        samesite="lax",
    )
    return response


@app.post("/api/auth/logout")
def api_auth_logout(request: Request):
    """Logout: elimina il cookie di sessione."""
    response = JSONResponse({"ok": True})
    response.delete_cookie(key=_AUTH_COOKIE_NAME, path="/")
    return response


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/status
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/status")
def api_status():
    """Stato connessione database."""
    ok, msg = test_connection()
    return {"ok": ok, "message": msg}


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/drivers  â€” lista conducenti con ultimo record real-time
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/drivers")
def api_drivers(hours: int = Query(2, ge=1, le=720)):
    """
    Ultimo stato di ogni conducente (ordinato per rischio desc).
    hours: finestra temporale (default 2h = live).
    """
    minutes = max(hours * 60, 60)
    sql = f"""
        WITH base AS (
            SELECT
                id_conducente,
                rischio, lvl, conf, categoria, scenario, data_quality,
                s_sonno, ai_level,
                ear, ear_status, perclos, perclos_status, mar,
                head_pitch, head_pitch_status, blink_freq, eye_stability,
                s_ppg, ppg_severity, hr_val, hr_status,
                spo2_val, spo2_status, temp_val, temp_status,
                rr_val, rr_status,
                s_thermal, thermal_severity, thermal_cal, fusion_type,
                data_ora,
                ROW_NUMBER() OVER (PARTITION BY id_conducente ORDER BY data_ora DESC) AS rn_latest,
                ROW_NUMBER() OVER (
                    PARTITION BY id_conducente
                    ORDER BY
                        CASE
                            WHEN hr_val IS NOT NULL
                              OR spo2_val IS NOT NULL
                              OR temp_val IS NOT NULL
                              OR rr_val IS NOT NULL
                            THEN 0 ELSE 1
                        END,
                        data_ora DESC
                ) AS rn_vitals
            FROM V_DHA_DASHBOARD
            WHERE data_ora >= DATEADD(minute, -{minutes}, GETDATE())
              AND lvl >= 0
        ),
        latest AS (
            SELECT * FROM base WHERE rn_latest = 1
        ),
        vitals AS (
            SELECT
                id_conducente,
                s_ppg, ppg_severity,
                hr_val, hr_status,
                spo2_val, spo2_status,
                temp_val, temp_status,
                rr_val, rr_status,
                data_ora AS vitals_data_ora
            FROM base
            WHERE rn_vitals = 1
        )
        SELECT
            l.id_conducente,
            a.DHA01_NOME    AS nome,
            a.DHA01_COGNOME AS cognome,
            l.rischio, l.lvl, l.conf, l.categoria, l.scenario, l.data_quality,
            l.s_sonno, l.ai_level,
            l.ear, l.ear_status, l.perclos, l.perclos_status, l.mar,
            l.head_pitch, l.head_pitch_status, l.blink_freq, l.eye_stability,
            COALESCE(l.s_ppg, v.s_ppg) AS s_ppg,
            COALESCE(l.ppg_severity, v.ppg_severity) AS ppg_severity,
            COALESCE(l.hr_val, v.hr_val) AS hr_val,
            COALESCE(l.hr_status, v.hr_status) AS hr_status,
            COALESCE(l.spo2_val, v.spo2_val) AS spo2_val,
            COALESCE(l.spo2_status, v.spo2_status) AS spo2_status,
            COALESCE(l.temp_val, v.temp_val) AS temp_val,
            COALESCE(l.temp_status, v.temp_status) AS temp_status,
            COALESCE(l.rr_val, v.rr_val) AS rr_val,
            COALESCE(l.rr_status, v.rr_status) AS rr_status,
            l.s_thermal, l.thermal_severity, l.thermal_cal, l.fusion_type,
            l.data_ora,
            v.vitals_data_ora,
            CASE
                WHEN DATEDIFF(second, l.data_ora, GETDATE()) <= 300 THEN 1
                ELSE 0
            END AS online
        FROM latest l
        LEFT JOIN vitals v ON v.id_conducente = l.id_conducente
        LEFT JOIN DHA05_USRFRAGILE u ON u.DHA05_CODICE = l.id_conducente
        LEFT JOIN DHA01_ANAGGEN    a ON a.DHA01_CODICE  = u.DHA05_CODICE_DHA01
        ORDER BY l.rischio DESC
    """
    return _cache_compute("api.drivers", 15, lambda: safe_query(sql), hours)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/kpi  â€” KPI aggregati flotta
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/kpi")
def api_kpi(hours: int = Query(24, ge=1, le=720)):
    """KPI flotta: conteggi per livello, rischio medio, n. conducenti online."""
    minutes = max(hours * 60, 60)
    sql = f"""
        WITH latest AS (
            SELECT
                id_conducente,
                rischio, lvl, data_ora,
                ROW_NUMBER() OVER (PARTITION BY id_conducente ORDER BY data_ora DESC) AS rn
            FROM V_DHA_DASHBOARD
            WHERE data_ora >= DATEADD(minute, -{minutes}, GETDATE())
              AND lvl >= 0
        ),
        base AS (
            SELECT
                id_conducente, rischio, lvl,
                CASE WHEN DATEDIFF(second, data_ora, GETDATE()) <= 300 THEN 1 ELSE 0 END AS online
            FROM latest WHERE rn = 1
        )
        SELECT
            COUNT(*)                                                      AS tot_conducenti,
            SUM(online)                                                   AS online_cnt,
            COUNT(*) - SUM(online)                                        AS offline_cnt,
            SUM(CASE WHEN rischio < 0.35 THEN 1 ELSE 0 END)              AS cnt_normale,
            SUM(CASE WHEN rischio >= 0.35 AND rischio < 0.55 THEN 1 ELSE 0 END) AS cnt_attenzione,
            SUM(CASE WHEN rischio >= 0.55 AND rischio < 0.75 THEN 1 ELSE 0 END) AS cnt_allerta,
            SUM(CASE WHEN rischio >= 0.75 THEN 1 ELSE 0 END)             AS cnt_critico,
            AVG(rischio)                                                  AS rischio_medio,
            MAX(rischio)                                                  AS rischio_max
        FROM base
    """
    def _build():
        rows = safe_query(sql)
        return rows[0] if rows else {}

    return _cache_compute("api.kpi", 15, _build, hours)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/alerts/ai-pending  â€” alert AI non ancora gestiti
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/alerts/ai-pending")
def api_alerts_ai_pending(hours: int = Query(24, ge=1, le=720)):
    """Conteggio alert AI (alert_required=true) senza esito in DHA18_ESITI."""
    sql = f"""
        SELECT
            COUNT(DISTINCT r.DHA17_CODICE) AS alert_ai_totali,
            COUNT(DISTINCT CASE
                WHEN e.DHA18_ESITO IS NULL THEN r.DHA17_CODICE
            END) AS alert_ai_pendenti
        FROM DHA17_RESPONSES r
        LEFT JOIN DHA18_ESITI e
               ON e.DHA18_IDRESPONSE = CAST(r.DHA17_CODICE AS VARCHAR(100))
        WHERE TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,
              '$.ia_response.summary.alert_required') AS BIT) = 1
          AND r.DHA17_DATAEORA >= DATEADD(hour, -{hours}, GETDATE())
    """
    def _build():
        rows = safe_query(sql)
        if not rows:
            return {"alert_ai_totali": 0, "alert_ai_pendenti": 0, "alert_ai_gestiti": 0}

        row = rows[0]
        total = int(row.get("alert_ai_totali") or 0)
        pending = int(row.get("alert_ai_pendenti") or 0)
        handled = max(total - pending, 0)

        return {
            "alert_ai_totali": total,
            "alert_ai_pendenti": pending,
            "alert_ai_gestiti": handled,
        }

    return _cache_compute("api.alerts_ai_pending", 30, _build, hours)


# ═══════════════════════════════════════════════════════════════════════════
# ENDPOINT /api/dashboard/summary  — summary unico dashboard principale
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/api/dashboard/summary")
def api_dashboard_summary(hours: int = Query(24, ge=1, le=720)):
    """Summary unico per la dashboard: KPI, conducenti, trend e alert."""
    def _summary_ttl() -> int:
        if hours >= 24 * 14:
            return 120
        if hours >= 24 * 7:
            return 45
        return 15

    trend_granularity = "day" if hours >= 24 * 14 else "hour"

    def _build():
        with ThreadPoolExecutor(max_workers=5) as pool:
            kpi_f = pool.submit(api_kpi, hours=hours)
            drivers_f = pool.submit(api_drivers, hours=hours)
            trend_f = pool.submit(api_trend, hours=hours)
            alerts_f = pool.submit(api_alerts, hours=hours)
            ai_alerts_f = pool.submit(api_alerts_ai_pending, hours=hours)

            return {
                "kpi": kpi_f.result(),
                "drivers": drivers_f.result(),
                "trend": trend_f.result(),
                "alerts": alerts_f.result(),
                "aiAlerts": ai_alerts_f.result(),
                "trendGranularity": trend_granularity,
            }

    return _cache_compute("api.dashboard.summary", _summary_ttl(), _build, hours)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/trend  â€” andamento rischio medio ora per ora
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/trend")
def api_trend(hours: int = Query(24, ge=1, le=720)):
    """Rischio medio aggregato per ora o per giorno, in base alla finestra."""
    use_daily = hours >= 24 * 14

    if use_daily:
        days_back = max(1, (hours + 23) // 24)
        sql = f"""
            SELECT
                DATEADD(day, DATEDIFF(day, 0, data_ora), 0) AS ora,
                AVG(rischio)   AS avg_rischio,
                MAX(rischio)   AS max_rischio,
                COUNT(DISTINCT id_conducente) AS n_conducenti
            FROM V_DHA_DASHBOARD
            WHERE data_ora >= DATEADD(day, -{days_back}, GETDATE())
              AND lvl >= 0
            GROUP BY DATEADD(day, DATEDIFF(day, 0, data_ora), 0)
            ORDER BY ora ASC
        """
        def _build():
            rows = safe_query(sql)
            for row in rows:
                row["granularity"] = "day"
            return rows

        return _cache_compute("api.trend.day", 120, _build, hours)

    sql = f"""
        SELECT
            DATEADD(hour, DATEDIFF(hour, 0, data_ora), 0) AS ora,
            AVG(rischio)   AS avg_rischio,
            MAX(rischio)   AS max_rischio,
            COUNT(DISTINCT id_conducente) AS n_conducenti
        FROM V_DHA_DASHBOARD
        WHERE data_ora >= DATEADD(hour, -{hours}, GETDATE())
          AND lvl >= 0
        GROUP BY DATEADD(hour, DATEDIFF(hour, 0, data_ora), 0)
        ORDER BY ora ASC
    """
    def _build():
        rows = safe_query(sql)
        for row in rows:
            row["granularity"] = "hour"
        return rows

    return _cache_compute("api.trend.hour", 30, _build, hours)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/alerts  â€” alert pendenti non gestiti
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/alerts")
def api_alerts(hours: int = Query(24, ge=1, le=720)):
    """Feed operativo multi-sorgente (PPG + Thermal + AI visive).

    La query sottostante produce più righe per lo stesso batch/evento.
    Qui le aggrego per batch_id così il frontend mostra un conteggio di
    eventi unici, non di record duplicati.
    """
    from backend.db import safe_query as q

    def _norm(expr: str) -> str:
        return f"NULLIF(LTRIM(RTRIM(CAST({expr} AS NVARCHAR(100)))), '')"

    sql = f"""
        WITH pending AS (
            -- PPG alerts
            SELECT
                'PPG'   AS fonte,
                {_norm("m.DHA11_BATCHID")}  AS batch_id,
                m.DHA11_CODICE_DHA05        AS id_conducente,
                an.DHA01_NOME               AS nome,
                an.DHA01_COGNOME            AS cognome,
                m.DHA11_DATAORARIL          AS dataora,
                p.DHA10_DESCR               AS parametro,
                CAST(NULL AS NVARCHAR(500)) AS descrizione
            FROM DHA13_ALERT al
            INNER JOIN DHA11_MONITOR m ON m.DHA11_CODICE = al.DHA13_CODICE_DHA11
            LEFT  JOIN DHA05_USRFRAGILE u  ON u.DHA05_CODICE = m.DHA11_CODICE_DHA05
            LEFT  JOIN DHA01_ANAGGEN    an ON an.DHA01_CODICE = u.DHA05_CODICE_DHA01
            LEFT  JOIN DHA10_ANAGPARMON p  ON p.DHA10_CODICE  = m.DHA11_CODICE_DHA10
            WHERE NOT EXISTS (
                SELECT 1 FROM DHA18_ESITI e
                WHERE {_norm("e.DHA18_IDRESPONSE")} = {_norm("m.DHA11_BATCHID")}
            )
              AND m.DHA11_DATAORARIL >= DATEADD(hour, -{hours}, GETDATE())

            UNION ALL

            -- Thermal violations
            SELECT
                'THERMAL',
                {_norm("v.DHA16_BATCHID")},
                v.DHA16_CODICE_DHA05,
                an.DHA01_NOME, an.DHA01_COGNOME,
                v.DHA16_DATETIME,
                p.DHA15_PARAMETER,
                v.DHA16_DESCRIZIONE
            FROM DHA16_VIOLTHERMAL v
            LEFT JOIN DHA05_USRFRAGILE u  ON u.DHA05_CODICE = v.DHA16_CODICE_DHA05
            LEFT JOIN DHA01_ANAGGEN    an ON an.DHA01_CODICE = u.DHA05_CODICE_DHA01
            LEFT JOIN DHA15_ANAGPARTHERMAL p ON p.DHA15_CODICE = v.DHA16_CODPARAM_DHA15
            WHERE NOT EXISTS (
                SELECT 1 FROM DHA18_ESITI e
                WHERE {_norm("e.DHA18_IDRESPONSE")} = {_norm("v.DHA16_BATCHID")}
            )
              AND v.DHA16_DATETIME >= DATEADD(hour, -{hours}, GETDATE())

            UNION ALL

            -- AI visive violations
            SELECT
                'AI_VISIVE',
                {_norm("v.DHA19_BATCHID")},
                v.DHA19_CODICE_DHA05,
                an.DHA01_NOME, an.DHA01_COGNOME,
                v.DHA19_DATETIME,
                v.DHA19_PARAM,
                v.DHA19_DESCRIPTION
            FROM DHA19_VIOLAI v
            LEFT JOIN DHA05_USRFRAGILE u  ON u.DHA05_CODICE = v.DHA19_CODICE_DHA05
            LEFT JOIN DHA01_ANAGGEN    an ON an.DHA01_CODICE = u.DHA05_CODICE_DHA01
            WHERE NOT EXISTS (
                SELECT 1 FROM DHA18_ESITI e
                WHERE {_norm("e.DHA18_IDRESPONSE")} = {_norm("v.DHA19_BATCHID")}
            )
              AND v.DHA19_DATETIME >= DATEADD(hour, -{hours}, GETDATE())
        )
        SELECT TOP 50
            fonte, batch_id, id_conducente,
            nome, cognome, dataora, parametro, descrizione
        FROM pending
        ORDER BY dataora DESC
    """
    rows = q(sql)
    if not rows:
        return []

    grouped = {}
    ordered = []

    for row in rows:
        key = str(row.get("batch_id") or f"{row.get('fonte')}|{row.get('id_conducente')}|{row.get('dataora')}")
        item = grouped.get(key)
        if item is None:
            item = dict(row)
            item["_fonti"] = []
            item["_parametri"] = []
            item["_descrizioni"] = []
            item["_count"] = 0
            grouped[key] = item
            ordered.append(item)

        fonte = row.get("fonte")
        if fonte and fonte not in item["_fonti"]:
            item["_fonti"].append(fonte)

        parametro = row.get("parametro")
        if parametro and parametro not in item["_parametri"]:
            item["_parametri"].append(parametro)

        descrizione = row.get("descrizione")
        if descrizione and descrizione not in item["_descrizioni"]:
            item["_descrizioni"].append(descrizione)

        item["_count"] += 1

        # Mantieni i dati anagrafici più recenti se arrivano righe con timestamp equivalente.
        if row.get("dataora") and (not item.get("dataora") or str(row["dataora"]) > str(item["dataora"])):
            item["dataora"] = row["dataora"]
            item["id_conducente"] = row.get("id_conducente")
            item["nome"] = row.get("nome")
            item["cognome"] = row.get("cognome")

    result = []
    for item in ordered:
        fonti = item.pop("_fonti", [])
        parametri = item.pop("_parametri", [])
        descrizioni = item.pop("_descrizioni", [])
        item.pop("_count", None)
        item["fonte"] = " + ".join(fonti) if fonti else item.get("fonte")
        item["parametro"] = " · ".join(parametri[:3]) + (" …" if len(parametri) > 3 else "") if parametri else item.get("parametro")
        item["descrizione"] = " · ".join(descrizioni[:2]) + (" …" if len(descrizioni) > 2 else "") if descrizioni else item.get("descrizione")
        result.append(item)

    result.sort(key=lambda r: (str(r.get("dataora") or ""), str(r.get("batch_id") or "")), reverse=True)
    return result[:50]


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/driver/{id}/timeline  â€” storico segnali per conducente
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/driver/{driver_id}/timeline")
def api_driver_timeline(driver_id: int, limit: int = Query(500, ge=10, le=2000)):
    """Storico segnali completo (bio + vitali + visivi) per un singolo conducente."""
    sql = f"""
        SELECT *
        FROM (
            SELECT TOP {limit}
                data_ora, rischio, s_sonno, s_ppg, s_thermal, lvl,
                hr_val, hr_status, spo2_val, spo2_status, temp_val, temp_status, rr_val,
                ear, ear_status, perclos, perclos_status, mar,
                head_pitch, head_pitch_status, blink_freq, eye_stability,
                conf, categoria, scenario, data_quality, ai_level, fusion_type
            FROM V_DHA_DASHBOARD
            WHERE id_conducente = ? AND lvl >= 0
            ORDER BY data_ora DESC
        ) t
        ORDER BY data_ora ASC
    """
    return _cache_compute("api.driver.timeline", 20, lambda: safe_query(sql, params=[driver_id]), driver_id, limit)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/drivers/historical  â€” lista conducenti per modalitÃ  storica
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/drivers/historical")
def api_drivers_historical(days: int = Query(7, ge=1, le=90)):
    """Lista conducenti con dati negli ultimi N giorni (per analisi storica)."""
    sql = f"""
        SELECT
            v.id_conducente,
            a.DHA01_NOME    AS nome,
            a.DHA01_COGNOME AS cognome,
            MAX(v.rischio)  AS rischio_max,
            AVG(v.rischio)  AS rischio_medio,
            MAX(v.data_ora) AS ultima_lettura,
            COUNT(*)        AS n_records
        FROM V_DHA_DASHBOARD v
        LEFT JOIN DHA05_USRFRAGILE u ON u.DHA05_CODICE = v.id_conducente
        LEFT JOIN DHA01_ANAGGEN    a ON a.DHA01_CODICE  = u.DHA05_CODICE_DHA01
        WHERE v.data_ora >= DATEADD(day, -{days}, GETDATE()) AND v.lvl >= 0
        GROUP BY v.id_conducente, a.DHA01_NOME, a.DHA01_COGNOME
        ORDER BY MAX(v.rischio) DESC
    """
    return _cache_compute("api.drivers.historical", 60, lambda: safe_query(sql), days)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/driver/{id}/therapies
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/driver/{driver_id}/therapies")
def api_driver_therapies(driver_id: int):
    sql = """
        SELECT
            ID_TERAPIA   AS id_terapia,
            ID_CONDUCENTE AS id_conducente,
            NOME_FARMACO AS farmaco,
            MEDICO       AS medico,
            DATA_INIZIO  AS data_inizio
        FROM DHA_TERAPIE_LIVE
        WHERE ID_CONDUCENTE = ?
        ORDER BY DATA_INIZIO DESC
    """
    return _cache_compute("api.driver.therapies", 120, lambda: safe_query(sql, params=[driver_id]), driver_id)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/driver/{id}/ai-violations
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/driver/{driver_id}/ai-violations")
def api_driver_ai_violations(driver_id: int):
    sql = """
        SELECT TOP 200
            DHA19_PARAM        AS param,
            DHA19_VALUE        AS valore,
            DHA19_THRESHOLD    AS soglia,
            DHA19_STATUS       AS status,
            DHA19_DESCRIPTION  AS descrizione,
            DHA19_CONTRIBUTION AS contributo,
            DHA19_DATETIME     AS dt
        FROM DHA19_VIOLAI
        WHERE DHA19_CODICE_DHA05 = ?
          AND DHA19_STATUS NOT IN ('NORMAL','UNAVAILABLE')
        ORDER BY DHA19_DATETIME DESC
    """
    return _cache_compute("api.driver.ai_violations", 45, lambda: safe_query(sql, params=[driver_id]), driver_id)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/driver/{id}/thermal-violations
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/driver/{driver_id}/thermal-violations")
def api_driver_thermal_violations(driver_id: int):
    sql = """
        SELECT TOP 200
            p.DHA15_PARAMETER   AS param,
            v.DHA16_VALORE      AS valore,
            v.DHA16_VALTHRES    AS soglia,
            v.DHA16_TIPOTHRES   AS tipo,
            v.DHA16_SEVERSCORE  AS severity_score,
            v.DHA16_DESCRIZIONE AS descrizione,
            v.DHA16_DATETIME    AS dt
        FROM DHA16_VIOLTHERMAL v
        JOIN DHA15_ANAGPARTHERMAL p ON p.DHA15_CODICE = v.DHA16_CODPARAM_DHA15
        WHERE v.DHA16_CODICE_DHA05 = ?
        ORDER BY v.DHA16_DATETIME DESC
    """
    return _cache_compute("api.driver.thermal_violations", 45, lambda: safe_query(sql, params=[driver_id]), driver_id)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/driver/{id}/diagnoses
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/driver/{driver_id}/diagnoses")
def api_driver_diagnoses(driver_id: int):
    sql = """
        SELECT
            t.DHA06_CODICE       AS anamnesi_id,
            t.DHA06_NOTE         AS note_anamnesi,
            c.DHA07_PROGRIGA     AS progressivo,
            c.DHA07_CODICE_DHA08 AS codice_diagnosi,
            c.DHA07_DESCR        AS descrizione_corpo,
            d.DHA08_DESCR        AS descrizione_diz,
            COALESCE(d.DHA08_DESCR, c.DHA07_DESCR) AS descrizione
        FROM DHA05_USRFRAGILE u
        JOIN DHA06_ANAMNESI_TESTA t
          ON t.DHA06_CODICE_DHA05 = u.DHA05_CODICE
        JOIN DHA07_ANAMNESI_CORPO c
          ON c.DHA07_CODICE_DHA06 = t.DHA06_CODICE
        LEFT JOIN DHA08_DIAGNOSI d
          ON d.DHA08_CODICE = c.DHA07_CODICE_DHA08
        WHERE u.DHA05_CODICE = ?
        ORDER BY t.DHA06_CODICE DESC, c.DHA07_PROGRIGA ASC
    """
    return _cache_compute("api.driver.diagnoses", 120, lambda: safe_query(sql, params=[driver_id]), driver_id)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/driver/{id}/responses  â€” risposte AI (DHA17)
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/ml/*  â€” AI Lab
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

import json as _json
import glob as _glob
import math as _math
import datetime as _dt

# Percorso modelli â€” solo cartella locale del progetto corrente
_ML_MODEL_DIRS = [
    pathlib.Path(__file__).parent.parent / "models",
]

_LSTM_MODEL_CACHE = {
    "signature": None,
    "payload": None,
}

_CACHE_LOCK = threading.Lock()
_CACHE_STORE: dict[tuple, tuple[float, object]] = {}
_CACHE_MAX_ITEMS = 256


def _cache_key(namespace: str, *parts: object) -> tuple:
    return (namespace, *parts)


def _cache_get(key: tuple) -> object | None:
    now = _time.monotonic()
    with _CACHE_LOCK:
        entry = _CACHE_STORE.get(key)
        if entry is None:
            return None
        expires_at, value = entry
        if expires_at <= now:
            _CACHE_STORE.pop(key, None)
            return None
        return _deepcopy(value)


def _cache_set(key: tuple, value: object, ttl_seconds: int) -> None:
    expires_at = _time.monotonic() + max(int(ttl_seconds), 1)
    with _CACHE_LOCK:
        _CACHE_STORE[key] = (expires_at, _deepcopy(value))
        if len(_CACHE_STORE) <= _CACHE_MAX_ITEMS:
            return
        now = _time.monotonic()
        stale = [cache_key for cache_key, (ttl_at, _) in _CACHE_STORE.items() if ttl_at <= now]
        for cache_key in stale:
            _CACHE_STORE.pop(cache_key, None)
        while len(_CACHE_STORE) > _CACHE_MAX_ITEMS:
            _CACHE_STORE.pop(next(iter(_CACHE_STORE)))


def _cache_compute(namespace: str, ttl_seconds: int, factory, *parts: object) -> object:
    key = _cache_key(namespace, *parts)
    cached = _cache_get(key)
    if cached is not None:
        return cached
    value = factory()
    _cache_set(key, value, ttl_seconds)
    return value


def _find_registry() -> dict:
    for base in _ML_MODEL_DIRS:
        p = base / "production_model.json"
        if p.exists():
            try:
                raw = p.read_text(encoding="utf-8")
                # NaN/Infinity non sono JSON validi â†’ normalizza
                raw = raw.replace(": NaN", ": null").replace(": Infinity", ": null").replace(":-Infinity", ": null")
                data = _json.loads(raw)
                data["_registry_path"] = str(p)
                return data
            except Exception:
                pass
    return {}


def _resolve_registry_path(path_value: object) -> pathlib.Path | None:
    if not path_value:
        return None
    candidate = pathlib.Path(str(path_value).strip())
    if not candidate.is_absolute():
        candidate = (_ROOT / candidate).resolve()
    return candidate


def _public_project_path(path_value: object) -> str:
    """Restituisce un path leggibile ma non assoluto per l'UI."""
    if not path_value:
        return "—"
    try:
        candidate = pathlib.Path(str(path_value).strip())
        if not candidate.is_absolute():
            candidate = (_ROOT / candidate).resolve()
        else:
            candidate = candidate.resolve()
        try:
            return candidate.relative_to(_ROOT.resolve()).as_posix()
        except Exception:
            return candidate.name or str(candidate)
    except Exception:
        return "—"


def _redact_report_paths(data: dict, report_path: pathlib.Path | None = None) -> dict:
    """Normalizza i path esposti nei report ML prima di inviarli al browser."""
    redacted = dict(data)
    for key in ("output_dir", "training_report_path", "report_path", "_report_path"):
        if key in redacted:
            redacted[key] = _public_project_path(redacted.get(key))
    if report_path is not None:
        redacted["_report_path"] = _public_project_path(report_path)

    for section_name in ("xgboost", "xgb", "lstm"):
        section = redacted.get(section_name)
        if isinstance(section, dict):
            section = dict(section)
            for key in ("artifact_path", "scaler_path", "model_path"):
                if key in section:
                    section[key] = _public_project_path(section.get(key))
            redacted[section_name] = section
    return redacted


def _find_training_report_path(registry: dict | None = None) -> pathlib.Path | None:
    reg = registry or _find_registry()
    report_path = _resolve_registry_path((reg or {}).get("training_report_path"))
    if report_path and report_path.exists():
        return report_path

    for base in _ML_MODEL_DIRS:
        for f in sorted(_glob.glob(str(base / "training_report_*.json")), reverse=True):
            p = pathlib.Path(f)
            if p.exists():
                return p
    return None


def _as_float(value: object) -> float | None:
    try:
        if value is None or value == "":
            return None
        numeric = float(value)
        if not _math.isfinite(numeric):
            return None
        return numeric
    except Exception:
        return None


def _iso_from_mtime(path: pathlib.Path | None) -> str | None:
    if not path or not path.exists():
        return None
    try:
        stamp = _dt.datetime.fromtimestamp(path.stat().st_mtime, tz=_dt.timezone.utc)
        return stamp.astimezone().isoformat()
    except Exception:
        return None


def _enrich_ml_registry(registry: dict) -> dict:
    """Aggiunge alias compatibili con la UI corrente al registry salvato su disco."""
    if not registry:
        return {}

    enriched = dict(registry)
    xgb = dict(enriched.get("xgboost") or enriched.get("xgb") or {})
    lstm = dict(enriched.get("lstm") or {})
    comparisons = dict(enriched.get("comparisons") or {})

    reg_metrics = dict(xgb.get("regression_metrics") or {})
    clf_metrics = dict(xgb.get("classifier_metrics") or {})
    bench = dict(xgb.get("classifier_benchmark") or {})
    lstm_bench = dict(lstm.get("classifier_benchmark") or {})

    artifact = _resolve_registry_path(xgb.get("artifact_path"))
    payload = _load_xgb_payload()
    features = payload.get("features") if isinstance(payload, dict) else None

    if enriched.get("output_dir"):
        enriched["output_dir"] = _public_project_path(enriched.get("output_dir"))

    if artifact:
        xgb["version"] = xgb.get("version") or artifact.stem.replace("risk_predictor_", "")
        xgb["trained_at"] = xgb.get("trained_at") or _iso_from_mtime(artifact)
    else:
        xgb["version"] = xgb.get("version") or enriched.get("created_at")
    if xgb.get("artifact_path"):
        xgb["artifact_path"] = _public_project_path(xgb.get("artifact_path"))
    elif artifact:
        xgb["artifact_path"] = _public_project_path(artifact)

    if isinstance(features, list) and features and not xgb.get("n_features"):
        xgb["n_features"] = len(features)

    xgb["mae"] = xgb.get("mae") if _as_float(xgb.get("mae")) is not None else reg_metrics.get("mae")
    xgb["rmse"] = xgb.get("rmse") if _as_float(xgb.get("rmse")) is not None else reg_metrics.get("rmse")
    xgb["r2"] = xgb.get("r2") if _as_float(xgb.get("r2")) is not None else reg_metrics.get("r2")
    xgb["auc_critical"] = xgb.get("auc_critical") if _as_float(xgb.get("auc_critical")) is not None else (
        clf_metrics.get("critical_auc") or reg_metrics.get("critical_auc")
    )
    xgb["recall_critical"] = xgb.get("recall_critical") if _as_float(xgb.get("recall_critical")) is not None else (
        clf_metrics.get("critical_recall") or reg_metrics.get("critical_recall")
    )
    xgb["balanced_accuracy"] = xgb.get("balanced_accuracy") if _as_float(xgb.get("balanced_accuracy")) is not None else (
        clf_metrics.get("critical_balanced_accuracy") or reg_metrics.get("critical_balanced_accuracy")
    )
    xgb["alert_threshold"] = xgb.get("alert_threshold") if _as_float(xgb.get("alert_threshold")) is not None else (
        clf_metrics.get("critical_threshold") or reg_metrics.get("critical_threshold")
    )
    xgb["latency_ms"] = xgb.get("latency_ms") if _as_float(xgb.get("latency_ms")) is not None else (
        bench.get("avg_latency_ms") or reg_metrics.get("avg_latency_ms")
    )

    forecast_policy = dict(enriched.get("forecast_policy") or xgb.get("forecast_policy") or {})
    regression_r2 = _as_float(reg_metrics.get("r2") or reg_metrics.get("regression_r2") or xgb.get("r2"))
    if not forecast_policy:
        forecast_policy = {
            "value_mode": "probability_first" if regression_r2 is not None and regression_r2 < 0 else "risk_first",
            "preferred_signal": "critical_probability" if regression_r2 is not None and regression_r2 < 0 else "predicted_risk",
            "secondary_signal": "predicted_risk" if regression_r2 is not None and regression_r2 < 0 else "critical_probability",
        }
    forecast_policy.setdefault("value_mode", "probability_first" if regression_r2 is not None and regression_r2 < 0 else "risk_first")
    forecast_policy.setdefault("preferred_signal", "critical_probability" if forecast_policy["value_mode"] == "probability_first" else "predicted_risk")
    forecast_policy.setdefault("secondary_signal", "predicted_risk" if forecast_policy["value_mode"] == "probability_first" else "critical_probability")
    forecast_policy.setdefault("regression_r2", regression_r2)
    forecast_policy.setdefault("regression_reliability", "low" if regression_r2 is not None and regression_r2 < 0 else ("ok" if regression_r2 is not None else "unknown"))
    forecast_policy.setdefault("classification_threshold", _as_float(clf_metrics.get("critical_threshold") or reg_metrics.get("critical_threshold")))
    xgb["forecast_policy"] = forecast_policy
    enriched["forecast_policy"] = forecast_policy

    enriched["xgboost"] = xgb

    candidate_only = (
        lstm.get("candidate_only") is True
        or (lstm.get("readiness") or {}).get("candidate_only") is True
        or enriched.get("candidate_only") is True
    )
    enriched["candidate_only"] = candidate_only

    baseline_auc = _as_float(enriched.get("baseline_auc"))
    if baseline_auc is None:
        baseline_auc = (
            clf_metrics.get("critical_auc")
            or reg_metrics.get("critical_auc")
            or (comparisons.get("xgboost") or {}).get("critical_auc")
        )
    if baseline_auc is not None:
        enriched["baseline_auc"] = baseline_auc

    lstm_artifact = _resolve_registry_path(lstm.get("artifact_path"))
    lstm_metrics = dict(lstm.get("metrics") or {})
    if lstm.get("artifact_path"):
        lstm["artifact_path"] = _public_project_path(lstm.get("artifact_path"))
    elif lstm_artifact:
        lstm["artifact_path"] = _public_project_path(lstm_artifact)
    if lstm.get("scaler_path"):
        lstm["scaler_path"] = _public_project_path(lstm.get("scaler_path"))
    if lstm_artifact:
        lstm["version"] = lstm.get("version") or lstm_artifact.stem.replace("lstm_predictor_", "")
        lstm["trained_at"] = lstm.get("trained_at") or _iso_from_mtime(lstm_artifact)
    else:
        lstm["version"] = lstm.get("version") or enriched.get("created_at")
    if isinstance(lstm.get("features"), list) and lstm.get("features") and not lstm.get("n_features"):
        lstm["n_features"] = len(lstm.get("features"))
    if _as_float(lstm.get("latency_ms")) is None:
        lstm["latency_ms"] = (
            lstm_bench.get("avg_latency_ms")
            or lstm_metrics.get("avg_latency_ms")
            or lstm_metrics.get("latency_ms")
        )
    if _as_float(lstm.get("auc")) is None:
        lstm["auc"] = lstm_metrics.get("auc") or lstm_metrics.get("critical_auc")
    if _as_float(lstm.get("balanced_accuracy")) is None:
        lstm["balanced_accuracy"] = lstm_metrics.get("balanced_accuracy") or lstm_metrics.get("critical_balanced_accuracy")
    if _as_float(lstm.get("recall")) is None:
        lstm["recall"] = lstm_metrics.get("recall") or lstm_metrics.get("critical_recall")
    if _as_float(lstm.get("threshold")) is None:
        lstm["threshold"] = lstm_metrics.get("threshold") or lstm_metrics.get("critical_threshold")
    if _as_float(lstm.get("peak_alloc_mb")) is None:
        lstm["peak_alloc_mb"] = lstm_bench.get("peak_alloc_mb") or lstm_metrics.get("peak_alloc_mb")
    if _as_float(lstm.get("artifact_size_mb")) is None and lstm_artifact and lstm_artifact.exists():
        try:
            lstm["artifact_size_mb"] = round(lstm_artifact.stat().st_size / (1024 * 1024), 6)
        except Exception:
            pass

    latency_ratio = _as_float(enriched.get("latency_ratio"))
    if latency_ratio is None:
        xgb_latency = _as_float(xgb.get("latency_ms")) or _as_float(bench.get("avg_latency_ms"))
        lstm_latency = _as_float(lstm.get("latency_ms")) or _as_float(lstm_bench.get("avg_latency_ms")) or _as_float((comparisons.get("lstm") or {}).get("avg_latency_ms"))
        if xgb_latency is not None and lstm_latency is not None and xgb_latency > 0:
            latency_ratio = lstm_latency / xgb_latency
        elif xgb_latency is not None and lstm_latency is None:
            latency_ratio = None
    if latency_ratio is not None:
        enriched["latency_ratio"] = latency_ratio

    report_path = _find_training_report_path(enriched)
    if report_path is not None:
        enriched["training_report_path"] = _public_project_path(report_path)
        enriched["training_report_name"] = report_path.name
        enriched["training_report_trained_at"] = _iso_from_mtime(report_path)

    enriched["lstm"] = lstm
    return enriched


def _find_xgb_model() -> dict | None:
    """Tenta di caricare il modello XGBoost e restituisce feature importances."""
    try:
        import joblib
    except ImportError:
        return None

    registry = _find_registry()
    artifact = _resolve_registry_path(registry.get("xgboost", {}).get("artifact_path")) if registry else None

    candidates = []
    if artifact and artifact.exists():
        candidates.append(str(artifact))
    for base in _ML_MODEL_DIRS:
        candidates += sorted(_glob.glob(str(base / "risk_predictor_*.joblib")), reverse=True)

    for path in candidates:
        try:
            payload = joblib.load(path)
            features = payload.get("features", [])
            importances = {}
            if "regressor" in payload and hasattr(payload["regressor"], "feature_importances_"):
                imp = payload["regressor"].feature_importances_
                importances["regressor"] = dict(zip(features, [float(v) for v in imp]))
            if "classifier" in payload and hasattr(payload["classifier"], "feature_importances_"):
                imp = payload["classifier"].feature_importances_
                importances["classifier"] = dict(zip(features, [float(v) for v in imp]))
            return {"filename": os.path.basename(path), "features": features, "importances": importances, "payload_keys": list(payload.keys())}
        except Exception:
            continue
    return None


def _load_xgb_payload() -> dict | None:
    """Carica il payload XGBoost di produzione dal joblib locale."""
    try:
        import joblib
    except ImportError:
        return None

    registry = _find_registry()
    artifact = _resolve_registry_path(registry.get("xgboost", {}).get("artifact_path")) if registry else None

    candidates = []
    if artifact and artifact.exists():
        candidates.append(str(artifact))
    for base in _ML_MODEL_DIRS:
        candidates += sorted(_glob.glob(str(base / "risk_predictor_*.joblib")), reverse=True)

    for path in candidates:
        try:
            payload = joblib.load(path)
            if isinstance(payload, dict) and ("classifier" in payload or "regressor" in payload):
                payload["_loaded_path"] = path
                return payload
        except Exception:
            continue
    return None


def _parse_driver_datetime(value):
    if value is None or value == "":
        return None
    if isinstance(value, _dt.datetime):
        return value
    if isinstance(value, str):
        raw = value.strip().replace("Z", "+00:00")
        for candidate in (raw, raw.replace("T", " ")):
            try:
                return _dt.datetime.fromisoformat(candidate)
            except Exception:
                pass
        for fmt in ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S"):
            try:
                return _dt.datetime.strptime(raw, fmt)
            except Exception:
                continue
    return None


def _safe_float(value):
    try:
        if value is None or value == "":
            return None
        num = float(value)
        return num if _math.isfinite(num) else None
    except Exception:
        return None


def _latest_numeric(rows: list[dict], *keys: str):
    for row in reversed(rows):
        for key in keys:
            num = _safe_float(row.get(key))
            if num is not None:
                return num
    return None


def _risk_window_stats(rows: list[dict], current_ts: _dt.datetime, minutes: int) -> tuple[float | None, float | None, list[float]]:
    start_ts = current_ts - _dt.timedelta(minutes=minutes)
    values = []
    for row in rows:
        ts = _parse_driver_datetime(row.get("data_ora"))
        if ts is None or ts < start_ts or ts > current_ts:
            continue
        num = _safe_float(row.get("rischio"))
        if num is not None:
            values.append(num)
    if not values:
        return None, None, []
    mean = sum(values) / len(values)
    if len(values) < 2:
        return mean, 0.0, values
    variance = sum((v - mean) ** 2 for v in values) / len(values)
    return mean, _math.sqrt(variance), values


def _risk_lag_value(rows: list[dict], current_ts: _dt.datetime, minutes: int) -> float | None:
    cutoff = current_ts - _dt.timedelta(minutes=minutes)
    for row in reversed(rows):
        ts = _parse_driver_datetime(row.get("data_ora"))
        if ts is None or ts > cutoff:
            continue
        num = _safe_float(row.get("rischio"))
        if num is not None:
            return num
    return None


def _build_xgb_feature_vector(rows: list[dict], payload: dict) -> tuple[dict | None, dict]:
    feature_order = (
        (payload.get("classifier_meta") or {}).get("features")
        or payload.get("features")
        or []
    )
    if not rows:
        return None, {"reason": "Nessun record disponibile per il scoring."}

    ordered_rows = sorted(
        rows,
        key=lambda row: _parse_driver_datetime(row.get("data_ora")) or _dt.datetime.min,
    )
    current_row = ordered_rows[-1]
    current_ts = _parse_driver_datetime(current_row.get("data_ora"))
    if current_ts is None:
        return None, {"reason": "Timestamp corrente non valido per il scoring."}

    current_risk = _latest_numeric(ordered_rows, "rischio")
    if current_risk is None:
        return None, {"reason": "Nessun rischio valido disponibile per il scoring."}

    current_s_sonno = _latest_numeric(ordered_rows, "s_sonno")
    current_s_ppg = _latest_numeric(ordered_rows, "s_ppg")
    current_s_thermal = _latest_numeric(ordered_rows, "s_thermal")
    current_lvl = _latest_numeric(ordered_rows, "lvl")

    mean_5m, std_5m, values_5m = _risk_window_stats(ordered_rows, current_ts, 5)
    mean_15m, std_15m, values_15m = _risk_window_stats(ordered_rows, current_ts, 15)
    mean_30m, std_30m, values_30m = _risk_window_stats(ordered_rows, current_ts, 30)

    lag_5m = _risk_lag_value(ordered_rows, current_ts, 5)
    lag_10m = _risk_lag_value(ordered_rows, current_ts, 10)
    threshold = _safe_float((payload.get("classifier_meta") or {}).get("threshold")) or _safe_float(payload.get("threshold")) or 0.75

    minute_of_day = current_ts.hour * 60 + current_ts.minute + (current_ts.second / 60.0)
    angle = 2.0 * _math.pi * (minute_of_day / 1440.0)
    z_score = None
    if mean_30m is not None:
        if std_30m is None or std_30m == 0:
            z_score = 0.0
        else:
            z_score = (current_risk - mean_30m) / std_30m

    feature_values = {
        "rischio": current_risk,
        "s_sonno": current_s_sonno,
        "s_ppg": current_s_ppg,
        "s_thermal": current_s_thermal,
        "lvl": current_lvl,
        "risk_rmean_5m": mean_5m,
        "risk_rstd_5m": std_5m,
        "risk_rmean_15m": mean_15m,
        "risk_rstd_15m": std_15m,
        "risk_rmean_30m": mean_30m,
        "risk_rstd_30m": std_30m,
        "risk_diff_5m": None if lag_5m is None else (current_risk - lag_5m),
        "risk_diff_10m": None if lag_10m is None else (current_risk - lag_10m),
        "int_sonno_ppg": None if current_s_sonno is None or current_s_ppg is None else current_s_sonno * current_s_ppg,
        "int_thermal_sonno": None if current_s_thermal is None or current_s_sonno is None else current_s_thermal * current_s_sonno,
        "int_sonno_thermal": None if current_s_sonno is None or current_s_thermal is None else current_s_sonno * current_s_thermal,
        "ora_sin": _math.sin(angle),
        "ora_cos": _math.cos(angle),
        "z_score": z_score,
        "is_anomaly": 1.0 if current_risk >= threshold else 0.0,
    }

    diagnostics = {
        "rows_total": len(ordered_rows),
        "rows_with_risk": len(values_5m) if values_5m else sum(1 for row in ordered_rows if _safe_float(row.get("rischio")) is not None),
        "window_5m_points": len(values_5m),
        "window_15m_points": len(values_15m),
        "window_30m_points": len(values_30m),
        "current_timestamp": current_ts.isoformat(),
        "threshold": threshold,
    }

    if feature_order:
        feature_values = {name: feature_values.get(name) for name in feature_order}

    return feature_values, diagnostics


def _build_forecast_policy(payload: dict) -> dict:
    reg_metrics = dict(payload.get("regression_metrics") or (payload.get("xgboost") or {}).get("regression_metrics") or {})
    r2 = _as_float(reg_metrics.get("r2") or reg_metrics.get("regression_r2") or payload.get("regression_r2"))
    policy = dict(payload.get("forecast_policy") or {})
    value_mode = policy.get("value_mode") or ("probability_first" if r2 is not None and r2 < 0 else "risk_first")
    policy["value_mode"] = value_mode
    policy["preferred_signal"] = policy.get("preferred_signal") or ("critical_probability" if value_mode == "probability_first" else "predicted_risk")
    policy["secondary_signal"] = policy.get("secondary_signal") or ("predicted_risk" if value_mode == "probability_first" else "critical_probability")
    policy["regression_r2"] = _as_float(policy.get("regression_r2")) if _as_float(policy.get("regression_r2")) is not None else r2
    policy["regression_reliability"] = policy.get("regression_reliability") or ("low" if r2 is not None and r2 < 0 else ("ok" if r2 is not None else "unknown"))
    if policy.get("classification_threshold") is None:
        policy["classification_threshold"] = _as_float(((payload.get("classifier_meta") or {}).get("metrics") or {}).get("critical_threshold"))
        if policy["classification_threshold"] is None:
            policy["classification_threshold"] = _as_float(payload.get("threshold"))
    return policy


def _feature_signal_text(feature: str, value: float, median: float | None) -> tuple[str, str]:
    label_map = {
        "rischio": "Rischio recente",
        "s_sonno": "Sonnolenza",
        "s_ppg": "PPG",
        "s_thermal": "Termico",
        "lvl": "Livello rischio",
        "z_score": "Deviazione recente",
        "is_anomaly": "Anomalia",
        "risk_diff_5m": "Trend 5m",
        "risk_diff_10m": "Trend 10m",
    }
    label = label_map.get(feature, feature.replace("_", " ").title())
    if feature == "is_anomaly":
        return label, "anomalia attiva" if value >= 0.5 else "nessuna anomalia"
    if feature in {"risk_diff_5m", "risk_diff_10m"}:
        if value > 0.03:
            return label, f"in aumento ({value:+.3f})"
        if value < -0.03:
            return label, f"in calo ({value:+.3f})"
        return label, f"stabile ({value:+.3f})"
    if median is not None and _math.isfinite(median):
        delta = value - median
        relation = "sopra" if delta >= 0 else "sotto"
        return label, f"{relation} mediana ({value:.3f} vs {median:.3f})"
    return label, f"valore {value:.3f}"


def _build_xgb_explanation(feature_values: dict, payload: dict, critical_probability: float | None, critical_threshold: float | None) -> dict:
    forecast_policy = _build_forecast_policy(payload)
    feature_order = (
        (payload.get("classifier_meta") or {}).get("features")
        or payload.get("features")
        or list(feature_values.keys())
    )
    classifier = payload.get("classifier")
    importances = {}
    if classifier is not None and hasattr(classifier, "feature_importances_"):
        try:
            importances = {name: float(score) for name, score in zip(feature_order, classifier.feature_importances_)}
        except Exception:
            importances = {}

    medians = payload.get("medians") or {}
    signals: list[dict] = []
    if critical_probability is not None and critical_threshold is not None:
        relation = "sopra soglia" if critical_probability >= critical_threshold else "sotto soglia"
        signals.append({
            "label": "Probabilita critica",
            "detail": f"{critical_probability:.3f} {relation} {critical_threshold:.3f}",
            "importance": None,
        })

    trend_5m = _safe_float(feature_values.get("risk_diff_5m"))
    trend_10m = _safe_float(feature_values.get("risk_diff_10m"))
    trend_value = trend_5m if trend_5m is not None else trend_10m
    if trend_value is not None:
        trend_label, trend_detail = _feature_signal_text(
            "risk_diff_5m" if trend_5m is not None else "risk_diff_10m",
            float(trend_value),
            None,
        )
        signals.append({
            "label": trend_label,
            "detail": trend_detail,
            "importance": None,
        })

    ranked_features = sorted(
        [
            name
            for name in feature_order
            if _safe_float(feature_values.get(name)) is not None and name not in {"risk_diff_5m", "risk_diff_10m"}
        ],
        key=lambda name: importances.get(name, 0.0),
        reverse=True,
    )
    for feature in ranked_features:
        if len(signals) >= 3:
            break
        value = _safe_float(feature_values.get(feature))
        if value is None:
            continue
        median = _safe_float(medians.get(feature))
        label, detail = _feature_signal_text(feature, float(value), median)
        signals.append({
            "label": label,
            "detail": detail,
            "importance": _safe_float(importances.get(feature)),
        })

    if not signals:
        signals.append({
            "label": "Segnali",
            "detail": "Nessun fattore significativo disponibile per la spiegazione.",
            "importance": None,
        })

    summary = (
        "La previsione operativa privilegia la probabilita critica."
        if forecast_policy.get("value_mode") == "probability_first"
        else "La previsione operativa privilegia il rischio continuo."
    )
    if forecast_policy.get("regression_reliability") == "low":
        summary += " Il regressore ha affidabilita bassa, quindi il valore continuo resta secondario."

    return {
        "summary": summary,
        "signals": signals[:3],
        "forecast_policy": forecast_policy,
        "regression_r2": forecast_policy.get("regression_r2"),
        "value_mode": forecast_policy.get("value_mode"),
    }


def _score_xgb_driver(rows: list[dict], payload: dict) -> dict:
    feature_values, diagnostics = _build_xgb_feature_vector(rows, payload)
    if feature_values is None:
        return {"error": diagnostics.get("reason", "Scoring non disponibile."), "diagnostics": diagnostics}

    feature_order = (
        (payload.get("classifier_meta") or {}).get("features")
        or payload.get("features")
        or list(feature_values.keys())
    )
    X = [[_safe_float(feature_values.get(name)) if _safe_float(feature_values.get(name)) is not None else _math.nan for name in feature_order]]

    classifier = payload.get("classifier")
    regressor = payload.get("regressor")
    critical_probability = None
    predicted_risk = None

    if classifier is not None and hasattr(classifier, "predict_proba"):
        try:
            proba = classifier.predict_proba(X)
            critical_probability = float(proba[0][1])
        except Exception:
            critical_probability = None

    if regressor is not None and hasattr(regressor, "predict"):
        try:
            predicted_risk = float(regressor.predict(X)[0])
        except Exception:
            predicted_risk = None

    critical_threshold = _safe_float(((payload.get("classifier_meta") or {}).get("metrics") or {}).get("critical_threshold"))
    if critical_threshold is None:
        critical_threshold = _safe_float(payload.get("threshold")) or 0.5

    score_for_label = critical_probability
    if score_for_label is None:
        score_for_label = predicted_risk
    if score_for_label is None:
        score_for_label = 0.0

    predicted_label = "critical" if score_for_label >= critical_threshold else "normal"
    current_risk = None
    current_timestamp = None
    if rows:
        latest_row = max(rows, key=lambda row: _parse_driver_datetime(row.get("data_ora")) or _dt.datetime.min)
        current_risk = _safe_float(latest_row.get("rischio"))
        current_timestamp = latest_row.get("data_ora")

    classifier_meta = payload.get("classifier_meta") or {}
    forecast_horizon = _safe_float(classifier_meta.get("forecast_horizon_min"))
    if forecast_horizon is None:
        forecast_horizon = _safe_float(payload.get("forecast_horizon_min")) or _safe_float(payload.get("target_shift")) or 30
    forecast_target = classifier_meta.get("forecast_target") or payload.get("forecast_target") or "max_risk_within_horizon"
    forecast_policy = _build_forecast_policy(payload)
    forecast_value_mode = forecast_policy.get("value_mode") or "risk_first"
    forecast_value_preferred = critical_probability if forecast_value_mode == "probability_first" else predicted_risk
    if forecast_value_preferred is None:
        forecast_value_preferred = predicted_risk if predicted_risk is not None else critical_probability
    forecast_value_secondary = predicted_risk if forecast_value_mode == "probability_first" else critical_probability
    if forecast_value_secondary is None:
        forecast_value_secondary = critical_probability if critical_probability is not None else predicted_risk
    explanation = _build_xgb_explanation(feature_values, payload, critical_probability, critical_threshold)

    return {
        "backend_model": "xgboost",
        "predicted_risk": predicted_risk,
        "forecast_risk": predicted_risk,
        "forecast_horizon_min": int(forecast_horizon),
        "forecast_target": forecast_target,
        "forecast_policy": forecast_policy,
        "forecast_value_mode": forecast_value_mode,
        "forecast_value_preferred": forecast_value_preferred,
        "forecast_value_secondary": forecast_value_secondary,
        "forecast_value_reliability": forecast_policy.get("regression_reliability"),
        "regression_r2": forecast_policy.get("regression_r2"),
        "current_risk": current_risk,
        "current_timestamp": current_timestamp,
        "critical_probability": critical_probability,
        "critical_event_probability": critical_probability,
        "critical_threshold": critical_threshold,
        "predicted_label": predicted_label,
        "feature_order": feature_order,
        "feature_values": feature_values,
        "diagnostics": diagnostics,
        "explanation": explanation,
        "feature_count": len(feature_order),
    }



def _load_lstm_payload() -> dict | None:
    """Carica il modello LSTM e lo scaler di produzione dal disco."""
    try:
        import joblib
        import tensorflow as tf
    except ImportError:
        return None

    registry = _find_registry()
    lstm = registry.get("lstm") or {}
    artifact = _resolve_registry_path(lstm.get("artifact_path"))
    scaler_path = _resolve_registry_path(lstm.get("scaler_path"))

    model_candidates: list[pathlib.Path] = []
    scaler_candidates: list[pathlib.Path] = []
    if artifact and artifact.exists():
        model_candidates.append(artifact)
    if scaler_path and scaler_path.exists():
        scaler_candidates.append(scaler_path)
    for base in _ML_MODEL_DIRS:
        model_candidates += [pathlib.Path(p) for p in sorted(_glob.glob(str(base / "lstm_predictor_*.keras")), reverse=True)]
        scaler_candidates += [pathlib.Path(p) for p in sorted(_glob.glob(str(base / "lstm_scaler_*.joblib")), reverse=True)]

    model_path = next((p for p in model_candidates if p.exists()), None)
    scaler_file = next((p for p in scaler_candidates if p.exists()), None)
    if model_path is None or scaler_file is None:
        return None

    try:
        signature = (
            str(model_path),
            str(scaler_file),
            model_path.stat().st_mtime,
            scaler_file.stat().st_mtime,
        )
    except Exception:
        signature = (str(model_path), str(scaler_file), None, None)

    if _LSTM_MODEL_CACHE.get("signature") == signature and _LSTM_MODEL_CACHE.get("payload") is not None:
        return _LSTM_MODEL_CACHE["payload"]

    try:
        model = tf.keras.models.load_model(str(model_path), compile=False)
    except Exception:
        return None

    try:
        scaler = joblib.load(str(scaler_file))
    except Exception:
        return None

    payload = {
        "model": model,
        "scaler": scaler,
        "registry": registry,
        "_loaded_path": str(model_path),
        "_scaler_path": str(scaler_file),
    }
    _LSTM_MODEL_CACHE["signature"] = signature
    _LSTM_MODEL_CACHE["payload"] = payload
    return payload


def _build_lstm_sequence(rows: list[dict], registry: dict) -> tuple[object | None, dict]:
    try:
        import numpy as _np
    except ImportError:
        return None, {"reason": "NumPy non disponibile per scoring LSTM."}

    lstm = registry.get("lstm") or {}
    feature_order = list(lstm.get("features") or registry.get("features") or [])
    if not feature_order:
        return None, {"reason": "Nessuna feature LSTM disponibile."}

    seq_len = int(_as_float(lstm.get("seq_length")) or _as_float(lstm.get("sequence_length")) or 30)
    medians = dict(lstm.get("medians") or registry.get("medians") or {})
    if not rows:
        return None, {"reason": "Nessun record disponibile per il scoring LSTM."}

    ordered_rows = sorted(rows, key=lambda row: _parse_driver_datetime(row.get("data_ora")) or _dt.datetime.min)
    if len(ordered_rows) < seq_len:
        return None, {"reason": f"Sequenza insufficiente per LSTM: {len(ordered_rows)} < {seq_len}"}

    sequence_rows = ordered_rows[-seq_len:]
    sequence = []
    for row in sequence_rows:
        values = []
        for name in feature_order:
            num = _safe_float(row.get(name))
            if num is None:
                num = _safe_float(medians.get(name))
            if num is None:
                num = 0.0
            values.append(num)
        sequence.append(values)

    latest_values = {name: sequence[-1][idx] for idx, name in enumerate(feature_order)}
    threshold = _safe_float(lstm.get("threshold")) or _safe_float((lstm.get("metrics") or {}).get("threshold")) or 0.5
    diagnostics = {
        "rows_total": len(ordered_rows),
        "sequence_length": seq_len,
        "feature_count": len(feature_order),
        "current_timestamp": (_parse_driver_datetime(sequence_rows[-1].get("data_ora")) or _dt.datetime.min).isoformat(),
        "threshold": threshold,
    }
    return _np.asarray([sequence], dtype=_np.float32), {
        "feature_order": feature_order,
        "feature_values": latest_values,
        "sequence": diagnostics,
    }


def _score_lstm_driver(rows: list[dict], payload: dict) -> dict:
    try:
        import numpy as _np
    except ImportError:
        return {"error": "NumPy non disponibile per scoring LSTM.", "diagnostics": {}}

    registry = payload.get("registry") or _find_registry()
    lstm = registry.get("lstm") or {}
    sequence_result = _build_lstm_sequence(rows, registry)
    if sequence_result[0] is None:
        return {"error": sequence_result[1].get("reason", "Scoring LSTM non disponibile."), "diagnostics": sequence_result[1]}

    sequence = sequence_result[0]
    diagnostics = sequence_result[1]["sequence"]
    feature_order = sequence_result[1]["feature_order"]
    feature_values = sequence_result[1]["feature_values"]
    model = payload.get("model")
    scaler = payload.get("scaler")

    try:
        flat = sequence.reshape(-1, sequence.shape[-1])
        if scaler is not None and hasattr(scaler, "transform"):
            flat = scaler.transform(flat)
        sequence = flat.reshape(sequence.shape)
    except Exception as exc:
        return {"error": f"Scaler LSTM non applicabile: {exc}", "diagnostics": diagnostics}

    threshold = _safe_float(lstm.get("threshold")) or _safe_float((lstm.get("metrics") or {}).get("threshold")) or 0.5
    critical_probability = None
    predicted_risk = None
    if model is not None and hasattr(model, "predict"):
        try:
            proba = model.predict(sequence, verbose=0)
            critical_probability = float(_np.asarray(proba).reshape(-1)[0])
            predicted_risk = critical_probability
        except Exception as exc:
            diagnostics["model_error"] = str(exc)

    score_for_label = critical_probability if critical_probability is not None else (predicted_risk if predicted_risk is not None else 0.0)
    predicted_label = "critical" if score_for_label >= threshold else "normal"
    current_risk = None
    current_timestamp = None
    if rows:
        latest_row = max(rows, key=lambda row: _parse_driver_datetime(row.get("data_ora")) or _dt.datetime.min)
        current_risk = _safe_float(latest_row.get("rischio"))
        current_timestamp = latest_row.get("data_ora")

    forecast_horizon = _safe_float(lstm.get("forecast_horizon_min"))
    if forecast_horizon is None:
        forecast_horizon = _safe_float(lstm.get("target_shift")) or 30
    forecast_target = lstm.get("forecast_target") or "max_risk_within_horizon"
    forecast_policy = _build_forecast_policy(lstm)
    forecast_value_mode = forecast_policy.get("value_mode") or "risk_first"
    forecast_value_preferred = critical_probability if forecast_value_mode == "probability_first" else predicted_risk
    if forecast_value_preferred is None:
        forecast_value_preferred = predicted_risk if predicted_risk is not None else critical_probability
    forecast_value_secondary = predicted_risk if forecast_value_mode == "probability_first" else critical_probability
    if forecast_value_secondary is None:
        forecast_value_secondary = critical_probability if critical_probability is not None else predicted_risk
    explanation = {
        "summary": "LSTM basato sulla sequenza recente del conducente.",
        "signals": [],
        "forecast_policy": forecast_policy,
        "regression_r2": forecast_policy.get("regression_r2"),
        "value_mode": forecast_value_mode,
    }

    return {
        "backend_model": "lstm",
        "predicted_risk": predicted_risk,
        "forecast_risk": predicted_risk,
        "forecast_horizon_min": int(forecast_horizon),
        "forecast_target": forecast_target,
        "forecast_policy": forecast_policy,
        "forecast_value_mode": forecast_value_mode,
        "forecast_value_preferred": forecast_value_preferred,
        "forecast_value_secondary": forecast_value_secondary,
        "forecast_value_reliability": forecast_policy.get("regression_reliability"),
        "regression_r2": forecast_policy.get("regression_r2"),
        "current_risk": current_risk,
        "current_timestamp": current_timestamp,
        "critical_probability": critical_probability,
        "critical_event_probability": critical_probability,
        "critical_threshold": threshold,
        "predicted_label": predicted_label,
        "feature_order": feature_order,
        "feature_values": feature_values,
        "diagnostics": diagnostics,
        "explanation": explanation,
        "feature_count": len(feature_order),
        "sequence_shape": [int(sequence.shape[0]), int(sequence.shape[1]), int(sequence.shape[2])],
    }
@app.get("/api/ml/registry")
def api_ml_registry():
    """Registro di produzione del modello (production_model.json), NaN â†’ null."""
    return _cache_compute("api.ml.registry", 60, lambda: _enrich_ml_registry(_find_registry()))


@app.get("/api/ml/training-report")
def api_ml_training_report():
    """Report dell'ultimo training salvato su disco."""
    report_path = _find_training_report_path()
    if report_path is None:
        return {"ok": False, "message": "Training report non trovato"}

    try:
        raw = report_path.read_text(encoding="utf-8")
        raw = raw.replace(": NaN", ": null").replace(": Infinity", ": null").replace(":-Infinity", ": null")
        data = _json.loads(raw)
        if isinstance(data, dict):
            data["ok"] = True
            data["_report_name"] = report_path.name
            data["_report_trained_at"] = _iso_from_mtime(report_path)
            return _redact_report_paths(data, report_path)
        return {
            "ok": True,
            "report": data,
            "_report_path": _public_project_path(report_path),
            "_report_name": report_path.name,
            "_report_trained_at": _iso_from_mtime(report_path),
        }
    except Exception as exc:
        _log.error("Unable to read training report %s: %s", report_path, exc, exc_info=False)
        return {"ok": False, "message": "Impossibile leggere il report di training."}


@app.get("/api/ml/feature-importance")
def api_ml_feature_importance():
    """Feature importances dal modello XGBoost in produzione."""
    def _build():
        result = _find_xgb_model()
        if result is None:
            return {"error": "Modello XGBoost non trovato o joblib non installato"}
        return result

    return _cache_compute("api.ml.feature_importance", 120, _build)


@app.get("/api/ml/predictions")
def api_ml_predictions(request: Request, days: int = Query(7, ge=1, le=30)):
    """Statistiche predizioni ML da DHA_ML_PREDICTIONS."""
    _require_private_if_configured(request)
    sql = f"""
        SELECT TOP 500
            MODELLO_USATO       AS modello,
            RISCHIO_PREDOTTO    AS predetto,
            RISCHIO_REALE       AS reale,
            ERRORE_ASSOLUTO     AS errore,
            DATA_ORA_PREDIZIONE AS dt,
            ID_CONDUCENTE       AS id_conducente,
            PROBABILITA_L3      AS prob_l3,
            CONFIDENZA          AS confidenza
        FROM DHA_ML_PREDICTIONS
        WHERE DATA_ORA_PREDIZIONE >= DATEADD(day, -{days}, GETDATE())
        ORDER BY DATA_ORA_PREDIZIONE DESC
    """
    return _cache_compute("api.ml.predictions", 20, lambda: safe_query(sql), days)


def _model_router_sequence_stats(rows: list[dict], threshold: int) -> dict:
    """Calcola la qualitÃ  della sequenza per decidere se l'LSTM è davvero usabile."""
    core_fields = [
        "rischio",
        "s_sonno",
        "s_ppg",
        "s_thermal",
        "ear",
        "perclos",
        "mar",
        "head_pitch",
        "blink_freq",
        "eye_stability",
    ]

    def _num(row: dict, key: str) -> float | None:
        try:
            value = row.get(key)
            if value is None or value == "":
                return None
            num = float(value)
            if not _math.isfinite(num):
                return None
            return num
        except Exception:
            return None

    rich_flags: list[bool] = []
    rich_rows = 0
    for row in rows:
        present = sum(1 for key in core_fields if _num(row, key) is not None)
        is_rich = present >= 6
        rich_flags.append(is_rich)
        if is_rich:
            rich_rows += 1

    best_run = 0
    run = 0
    for flag in rich_flags:
        if flag:
            run += 1
            best_run = max(best_run, run)
        else:
            run = 0

    return {
        "rows_total": len(rows),
        "rows_rich": rich_rows,
        "max_consecutive_rich_rows": best_run,
        "sequence_threshold": threshold,
    }


@app.get("/api/driver/{driver_id}/model-router")
def api_driver_model_router(driver_id: int, days: int = Query(30, ge=1, le=90)):
    """Router dinamico: LSTM se pronta e caricabile a runtime, altrimenti XGBoost."""
    registry = _find_registry()
    lstm_registry = registry.get("lstm") or {}
    lstm_readiness = registry.get("lstm_status") or lstm_registry.get("readiness") or {}

    sequence_threshold = int(
        (lstm_readiness.get("thresholds") or {}).get("min_valid_sequences")
        or (lstm_readiness.get("thresholds") or {}).get("min_valid_rows")
        or (lstm_readiness.get("thresholds") or {}).get("min_total_sequences")
        or 24
    )
    lstm_seq_len = int(
        _as_float(lstm_registry.get("seq_length"))
        or _as_float(lstm_registry.get("sequence_length"))
        or 30
    )
    sequence_required = max(sequence_threshold, lstm_seq_len)

    sql = f"""
        SELECT
            data_ora,
            rischio,
            s_sonno,
            s_ppg,
            s_thermal,
            ear,
            perclos,
            mar,
            head_pitch,
            blink_freq,
            eye_stability,
            data_quality
        FROM V_DHA_DASHBOARD
        WHERE id_conducente = ?
          AND data_ora >= DATEADD(day, -{days}, GETDATE())
          AND lvl >= 0
        ORDER BY data_ora ASC
    """
    def _build():
        rows = safe_query(sql, params=[driver_id])
        sequence_stats = _model_router_sequence_stats(rows, sequence_threshold)

        lstm_artifact = _resolve_registry_path(lstm_registry.get("artifact_path"))
        lstm_scaler = _resolve_registry_path(lstm_registry.get("scaler_path"))
        registry_model = str(registry.get("production_model") or registry.get("baseline_model") or "xgboost").lower()
        lstm_selected_in_registry = registry_model == "lstm"
        lstm_available = bool(
            lstm_readiness.get("evaluable")
            and not lstm_readiness.get("candidate_only")
            and lstm_artifact
            and lstm_artifact.exists()
            and lstm_scaler
            and lstm_scaler.exists()
        )
        lstm_runtime_ready = False
        if lstm_available and sequence_stats["max_consecutive_rich_rows"] >= sequence_required:
            lstm_runtime_ready = _load_lstm_payload() is not None

        if lstm_runtime_ready:
            model_used = "lstm"
            if lstm_selected_in_registry:
                reason = (
                    f"LSTM selezionata dal registry e pronta a runtime: sequenza valida "
                    f"{sequence_stats['max_consecutive_rich_rows']} >= soglia {sequence_required}."
                )
            else:
                reason = (
                    f"Router dinamico: LSTM caricabile e sequenza valida "
                    f"{sequence_stats['max_consecutive_rich_rows']} >= soglia {sequence_required}."
                )
        else:
            model_used = "xgboost"
            if not lstm_available:
                reason = "LSTM non disponibile o candidate-only: uso XGBoost come fallback."
            elif sequence_stats["max_consecutive_rich_rows"] < sequence_required:
                reason = (
                    f"Sequenza valida insufficiente per LSTM "
                    f"({sequence_stats['max_consecutive_rich_rows']}/{sequence_required}). "
                    f"Uso XGBoost."
                )
            else:
                reason = "LSTM non caricabile a runtime (TensorFlow/artefatti/scaler): uso XGBoost."

        return {
            "driver_id": driver_id,
            "days": days,
            "model_used": model_used,
            "preferred_model": registry_model,
            "fallback_model": "xgboost",
            "reason": reason,
            "lstm_available": lstm_available,
            "lstm_ready": lstm_runtime_ready,
            "lstm_runtime_ready": lstm_runtime_ready,
            "lstm_selected_in_registry": lstm_selected_in_registry,
            "sequence": sequence_stats,
            "registry_model": registry_model,
            "registry_reason": registry.get("selected_reason") or registry.get("selection_reason") or "",
        }

    return _cache_compute("api.driver.model_router", 10, _build, driver_id, days)


@app.get("/api/driver/{driver_id}/model-score")
def api_driver_model_score(driver_id: int, days: int = Query(30, ge=1, le=90)):
    """Scoring reale del conducente con routing modello e predizione LSTM/XGBoost."""
    def _build():
        router = api_driver_model_router(driver_id, days)
        sql = f"""
        SELECT
            data_ora,
            rischio,
            s_sonno,
            s_ppg,
            s_thermal,
            lvl,
            ear,
            perclos,
            mar,
            head_pitch,
            blink_freq,
            eye_stability,
            data_quality
        FROM V_DHA_DASHBOARD
        WHERE id_conducente = ?
          AND data_ora >= DATEADD(day, -{days}, GETDATE())
          AND lvl >= 0
        ORDER BY data_ora ASC
    """
        rows = safe_query(sql, params=[driver_id])
        if router.get("model_used") == "lstm":
            payload = _load_lstm_payload()
            if payload is not None:
                scoring = _score_lstm_driver(rows, payload)
                if scoring and not scoring.get("error"):
                    return {**router, "scoring": scoring}

        payload = _load_xgb_payload()
        if payload is None:
            return {**router, "scoring": None, "error": "Modello XGBoost non trovato o joblib non installato"}

        scoring = _score_xgb_driver(rows, payload)
        return {**router, "scoring": scoring}

    return _cache_compute("api.driver.model_score", 10, _build, driver_id, days)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
def _build_driver_summary_payload(driver_id: int, days: int, limit: int) -> dict:
    return _build_driver_summary_payload_for_role(driver_id, days, limit, include_sensitive=False)


def _build_driver_summary_payload_for_role(
    driver_id: int,
    days: int,
    limit: int,
    include_sensitive: bool,
) -> dict:
    router = api_driver_model_score(driver_id, days=days)
    scoring = router.get("scoring") if isinstance(router, dict) else None
    payload = {
        "summary_version": 1,
        "driver_id": driver_id,
        "days": days,
        "limit": limit,
        "timeline": api_driver_timeline(driver_id, limit=limit),
        "therapies": api_driver_therapies(driver_id),
        "aiViolations": api_driver_ai_violations(driver_id),
        "thermalViolations": api_driver_thermal_violations(driver_id),
        "diagnoses": api_driver_diagnoses(driver_id),
        "registry": api_ml_registry(),
        "featureImportance": api_ml_feature_importance(),
        "dailySummary": api_driver_daily_summary(driver_id, days=days),
        "router": router,
        "score": scoring,
        "generatedAt": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    if include_sensitive:
        payload["responses"] = _build_driver_responses_payload(driver_id, limit)
    return payload


@app.get("/api/driver/{driver_id}/summary")
def api_driver_summary(
    request: Request,
    driver_id: int,
    days: int = Query(30, ge=1, le=90),
    limit: int = Query(500, ge=10, le=2000),
):
    """Summary unico per Analisi Clinica: dati pubblici + dettagli riservati solo con token riservato."""
    include_sensitive = _is_authenticated(request)
    cache_role = "private" if include_sensitive else "public"
    return _cache_compute(
        f"api.driver.summary.{cache_role}",
        15,
        lambda: _build_driver_summary_payload_for_role(driver_id, days, limit, include_sensitive=include_sensitive),
        driver_id,
        days,
        limit,
        cache_role,
    )


# ENDPOINT /api/system/*  â€” Sistema
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

import sys as _sys
import platform as _platform
import importlib as _importlib

@app.get("/api/system/info")
def api_system_info():
    """Info sistema: DB, percorsi, env, dipendenze Python."""
    ok_db, msg_db = test_connection()

    # Dipendenze
    required_deps = ["pandas", "pyodbc", "fastapi", "uvicorn", "joblib", "xgboost", "shap", "sklearn", "openpyxl", "numpy"]
    optional_deps = ["tensorflow"]
    dep_rows: dict[str, dict[str, object]] = {}
    for lib in required_deps:
        try:
            m = _importlib.import_module(lib)
            dep_rows[lib] = {"libreria": lib, "stato": "ok", "versione": getattr(m, "__version__", "?"), "richiesto": True}
        except ImportError:
            dep_rows[lib] = {"libreria": lib, "stato": "mancante", "versione": "-", "richiesto": True}
    for lib in optional_deps:
        try:
            m = _importlib.import_module(lib)
            dep_rows[lib] = {"libreria": lib, "stato": "ok", "versione": getattr(m, "__version__", "?"), "richiesto": False}
        except ImportError:
            dep_rows[lib] = {"libreria": lib, "stato": "opzionale", "versione": "-", "richiesto": False}

    # Percorsi modelli
    model_paths = []
    for base in _ML_MODEL_DIRS:
        model_paths.append({"path": _public_project_path(base), "exists": base.exists()})

    # Env vars
    conn_str_set = bool(os.environ.get("DHA_DB_CONNECTION_STRING","").strip())
    dev_mode = os.environ.get("DHA_DEV_MODE","false").strip().lower() in {"1","true","yes","on"}

    def _build():
        return {
            "db": {"ok": ok_db, "message": msg_db},
            "python": _sys.version,
            "platform": _platform.platform(),
            "dependencies": dep_rows,
            "model_paths": model_paths,
            "env": {
                "DHA_DB_CONNECTION_STRING": "impostata" if conn_str_set else "non impostata (serve DHA_DB_CONNECTION_STRING o DHA_CONN_STR)",
                "DHA_DEV_MODE": "attiva" if dev_mode else "spenta",
            },
        }

    return _cache_compute("api.system.info", 30, _build)


@app.get("/api/system/users")
def api_system_users():
    """Endpoint riservato non esposto nella UI pubblica."""
    raise HTTPException(status_code=404, detail="Not found")


@app.get("/api/system/models-disk")
def api_system_models_disk(request: Request):
    """File modelli (.joblib, .keras, .json) presenti su disco."""

    def _build():
        import glob as _g
        rows = []
        for base in _ML_MODEL_DIRS:
            for ext in ["*.joblib", "*.keras", "*.json"]:
                for f in sorted(_g.glob(str(base / ext)), reverse=True):
                    p = pathlib.Path(f)
                    rows.append({
                        "file": p.name,
                        "directory": _public_project_path(p.parent),
                        "size_kb": round(p.stat().st_size / 1024, 1),
                        "modified": _platform.os.path.getmtime(f) if hasattr(_platform, "os") else p.stat().st_mtime,
                    })
        rows.sort(key=lambda r: r["modified"], reverse=True)
        import datetime as _dt
        for r in rows:
            r["modified"] = _dt.datetime.fromtimestamp(r["modified"]).strftime("%Y-%m-%d %H:%M")
        return rows

    return _cache_compute("api.system.models_disk", 30, _build)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/alerts/analysis  â€” Analisi Alert & Performance AI
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/alerts/analysis")
def api_alerts_analysis(days: int = Query(30, ge=1, le=180)):
    """
    Analisi completa alert: risposte AI (DHA17) + esiti (DHA18).
    Estrae campi JSON, calcola TP/FP/FN/TN e aggrega le metriche.
    """
    import datetime as _adt

    batch_expr = (
        "NULLIF(LTRIM(RTRIM(CAST("
        "COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.batch_id'),"
        "JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.batch_id'))"
        " AS NVARCHAR(100)))),'')"
    )

    sql = f"""
        SELECT TOP 5000
            r.DHA17_CODICE       AS codice_resp,
            r.DHA17_CODICE_DHA05 AS id_conducente,
            a.DHA01_NOME         AS nome,
            a.DHA01_COGNOME      AS cognome,
            r.DHA17_DATAEORA     AS dataora,
            {batch_expr}         AS batch_id,
            TRY_CAST(
                JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.alert_required')
                AS BIT)          AS alert_required,
            TRY_CAST(
                COALESCE(
                    JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),
                    JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')
                ) AS INT)        AS ai_level,
            TRY_CAST(
                JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score')
                AS FLOAT)        AS final_score,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.category')    AS category,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.confidence')  AS confidence,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.scenario')    AS scenario,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.data_quality') AS data_quality,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.fusion_method')        AS fusion_method,
            e.DHA18_ESITO        AS esito,
            CASE WHEN e.DHA18_ESITO IS NOT NULL THEN 1 ELSE 0 END AS gestito
        FROM DHA17_RESPONSES r
        LEFT JOIN DHA18_ESITI e
               ON NULLIF(LTRIM(RTRIM(CAST(e.DHA18_IDRESPONSE AS NVARCHAR(100)))), '')
                = {batch_expr}
        LEFT JOIN DHA05_USRFRAGILE u ON u.DHA05_CODICE = r.DHA17_CODICE_DHA05
        LEFT JOIN DHA01_ANAGGEN    a ON a.DHA01_CODICE  = u.DHA05_CODICE_DHA01
        WHERE r.DHA17_DATAEORA >= DATEADD(day, -{days}, GETDATE())
        ORDER BY r.DHA17_DATAEORA DESC
    """
    rows = safe_query(sql)

    # â”€â”€ Classifica ogni record â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    def classify(alert_req, esito):
        if esito is None:
            return "PENDING"
        ar = bool(alert_req) if alert_req is not None else False
        if isinstance(esito, str):
            raw = esito.strip().upper()
            if not raw:
                return "PENDING"
            if raw in {"TP", "FP", "FN", "TN", "PENDING"}:
                return raw
            if raw in {"TRUE", "YES", "SI", "SÃŒ"}:
                es = 1
            elif raw in {"FALSE", "NO"}:
                es = 0
            else:
                try:
                    es = int(float(raw))
                except Exception:
                    return "PENDING"
        else:
            try:
                es = int(esito)
            except Exception:
                return "PENDING"
        if ar and es == 1:  return "TP"
        if ar and es == 0:  return "FP"
        if not ar and es == 1: return "FN"
        return "TN"

    for r in rows:
        r["classification"] = classify(r.get("alert_required"), r.get("esito"))
        # normalizza nome
        nome = " ".join(filter(None, [r.get("nome"), r.get("cognome")])) or f"ID {r.get('id_conducente')}"
        r["nome_completo"] = nome

    # â”€â”€ KPI globali â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    total     = len(rows)
    n_alert   = sum(1 for r in rows if r.get("alert_required"))
    n_gestiti = sum(1 for r in rows if r.get("gestito"))
    n_pending = sum(1 for r in rows if r["classification"] == "PENDING")
    tp = sum(1 for r in rows if r["classification"] == "TP")
    fp = sum(1 for r in rows if r["classification"] == "FP")
    fn = sum(1 for r in rows if r["classification"] == "FN")
    tn = sum(1 for r in rows if r["classification"] == "TN")
    precision   = tp / (tp + fp) if (tp + fp) > 0 else None
    recall      = tp / (tp + fn) if (tp + fn) > 0 else None
    f1          = (2 * precision * recall / (precision + recall)) if (precision and recall and (precision + recall) > 0) else None
    specificity = tn / (tn + fp) if (tn + fp) > 0 else None

    # â”€â”€ Aggregazione per livello â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    level_labels = {0: "L0 Vigile", 1: "L1 Lieve", 2: "L2 Significativo", 3: "L3 Grave"}
    by_level = {}
    for r in rows:
        lvl = r.get("ai_level")
        if lvl is None:
            lvl = -1
        if lvl not in by_level:
            by_level[lvl] = {"level": lvl, "label": level_labels.get(lvl, f"L{lvl}"),
                             "total": 0, "alert_true": 0, "gestiti": 0,
                             "tp": 0, "fp": 0, "fn": 0, "tn": 0, "pending": 0,
                             "scores": []}
        by_level[lvl]["total"] += 1
        if r.get("alert_required"):
            by_level[lvl]["alert_true"] += 1
        if r.get("gestito"):
            by_level[lvl]["gestiti"] += 1
        by_level[lvl][r["classification"].lower()] += 1
        if r.get("final_score") is not None:
            by_level[lvl]["scores"].append(float(r["final_score"]))

    by_level_list = []
    for lvl, d in sorted(by_level.items()):
        scores = d.pop("scores")
        _tp, _fp, _fn = d["tp"], d["fp"], d["fn"]
        _prec = _tp / (_tp + _fp) if (_tp + _fp) > 0 else None
        _rec  = _tp / (_tp + _fn) if (_tp + _fn) > 0 else None
        _f1   = (2 * _prec * _rec / (_prec + _rec)) if (_prec and _rec) else None
        d["precision"]   = round(_prec, 4) if _prec is not None else None
        d["recall"]      = round(_rec,  4) if _rec  is not None else None
        d["f1"]          = round(_f1,   4) if _f1   is not None else None
        d["score_min"]   = round(min(scores), 4) if scores else None
        d["score_max"]   = round(max(scores), 4) if scores else None
        d["score_avg"]   = round(sum(scores) / len(scores), 4) if scores else None
        d["alert_false"] = d["total"] - d["alert_true"]
        by_level_list.append(d)

    # â”€â”€ Aggregazione per scenario â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    by_scenario: dict = {}
    for r in rows:
        sc = r.get("scenario") or "N/D"
        if sc not in by_scenario:
            by_scenario[sc] = {"scenario": sc, "total": 0, "alert_true": 0,
                               "tp": 0, "fp": 0, "fn": 0, "tn": 0, "pending": 0}
        by_scenario[sc]["total"] += 1
        if r.get("alert_required"):
            by_scenario[sc]["alert_true"] += 1
        by_scenario[sc][r["classification"].lower()] += 1

    by_scenario_list = sorted(by_scenario.values(), key=lambda x: x["total"], reverse=True)

    # â”€â”€ Trend giornaliero â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    daily: dict = {}
    for r in rows:
        dt = r.get("dataora")
        if dt:
            try:
                day = str(dt)[:10]
            except Exception:
                day = "?"
            if day not in daily:
                daily[day] = {"date": day, "alert_true": 0, "alert_false": 0, "total": 0}
            daily[day]["total"] += 1
            if r.get("alert_required"):
                daily[day]["alert_true"] += 1
            else:
                daily[day]["alert_false"] += 1

    daily_list = sorted(daily.values(), key=lambda x: x["date"])

    result = {
        "kpi": {
            "total": total,
            "n_alert": n_alert,
            "n_no_alert": total - n_alert,
            "n_gestiti": n_gestiti,
            "n_pending": n_pending,
            "tp": tp, "fp": fp, "fn": fn, "tn": tn,
            "precision":   round(precision,   4) if precision   is not None else None,
            "recall":      round(recall,       4) if recall      is not None else None,
            "f1":          round(f1,           4) if f1          is not None else None,
            "specificity": round(specificity,  4) if specificity is not None else None,
        },
        "by_level":    by_level_list,
        "by_scenario": by_scenario_list,
        "daily_trend": daily_list,
        "records":     rows,
    }
    return _cache_compute("api.alerts.analysis", 30, lambda: result, days)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT Deep Analysis â€” risposte con JSON parsing, vitali, termica, perclos
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/driver/{driver_id}/deep-responses")
def api_driver_deep_responses(request: Request, driver_id: int, hours: int = Query(48, ge=1, le=720)):
    """Risposte AI con campi JSON estratti per Deep Analysis."""
    _require_private_if_configured(request)
    sql = f"""
        SELECT TOP 2000
            r.DHA17_CODICE    AS codice,
            r.DHA17_DATAEORA  AS dataora,
            r.DHA17_WSIARESPONSE AS wsiaresponse,
            TRY_CAST(
                JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.alert_required')
                AS BIT)       AS alert_required,
            TRY_CAST(
                COALESCE(
                    JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),
                    JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')
                ) AS INT)     AS ai_level,
            TRY_CAST(
                JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score')
                AS FLOAT)     AS final_score,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.category')   AS category,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.confidence') AS confidence,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.scenario')   AS scenario,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.data_quality') AS data_quality,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.warmup_status') AS warmup_status,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.fusion_details.fusion_method') AS fusion_method,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.fusion_details.explanation') AS explanation,
            TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,
                '$.ia_response.fusion_details.component_assessments.ppg.score') AS FLOAT) AS ppg_score,
            TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,
                '$.ia_response.fusion_details.component_assessments.thermal.score') AS FLOAT) AS therm_score,
            TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,
                '$.ia_response.fusion_details.component_assessments.ai_video.score') AS FLOAT) AS vis_score,
            JSON_VALUE(r.DHA17_WSIARESPONSE,
                '$.ia_response.fusion_details.component_assessments.ppg.level') AS ppg_lvl,
            JSON_VALUE(r.DHA17_WSIARESPONSE,
                '$.ia_response.fusion_details.component_assessments.thermal.level') AS therm_lvl,
            JSON_VALUE(r.DHA17_WSIARESPONSE,
                '$.ia_response.fusion_details.component_assessments.ai_video.level') AS vis_lvl,
            TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,
                '$.ai_drowsiness_detection.explaining_features.perclos.value') AS FLOAT) AS perclos_json,
            TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,
                '$.ai_drowsiness_detection.detection_statistics.face_detection_rate') AS FLOAT) AS face_rate,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.recommendations') AS recommendations_raw,
            e.DHA18_ESITO AS esito
        FROM DHA17_RESPONSES r
        LEFT JOIN DHA18_ESITI e
               ON NULLIF(LTRIM(RTRIM(CAST(e.DHA18_IDRESPONSE AS NVARCHAR(100)))),'')
                = NULLIF(LTRIM(RTRIM(CAST(
                    COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.batch_id'),
                             JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.batch_id'))
                  AS NVARCHAR(100)))), '')
        WHERE r.DHA17_CODICE_DHA05 = ?
          AND r.DHA17_DATAEORA >= DATEADD(hour, -{hours}, GETDATE())
        ORDER BY r.DHA17_DATAEORA ASC
    """
    return _cache_compute("api.driver.deep_responses", 30, lambda: safe_query(sql, params=[driver_id]), driver_id, hours)


@app.get("/api/driver/{driver_id}/monitor-vitals")
def api_driver_monitor_vitals(driver_id: int, hours: int = Query(48, ge=1, le=720)):
    """Dati vitali da DHA11_MONITOR (RR, SPO2, HR, temperatura corporea)."""
    sql = f"""
        SELECT TOP 2000
            m.DHA11_DATAORARIL  AS dataora,
            p.DHA10_DESCR       AS param,
            m.DHA11_VALORE      AS valore,
            m.DHA11_BATCHID     AS batch_id
        FROM DHA11_MONITOR m
        LEFT JOIN DHA10_ANAGPARMON p ON p.DHA10_CODICE = m.DHA11_CODICE_DHA10
        WHERE m.DHA11_CODICE_DHA05 = ?
          AND m.DHA11_DATAORARIL >= DATEADD(hour, -{hours}, GETDATE())
        ORDER BY m.DHA11_DATAORARIL ASC
    """
    return _cache_compute("api.driver.monitor_vitals", 30, lambda: safe_query(sql, params=[driver_id]), driver_id, hours)


@app.get("/api/driver/{driver_id}/thermal-vitals")
def api_driver_thermal_vitals(driver_id: int, hours: int = Query(48, ge=1, le=720)):
    """Dati termici da DHA16_VIOLTHERMAL (stress score per zona)."""
    sql = f"""
        SELECT TOP 2000
            v.DHA16_DATETIME    AS dt,
            p.DHA15_PARAMETER   AS param,
            v.DHA16_VALORE      AS valore,
            v.DHA16_DESCRIZIONE AS descrizione,
            v.DHA16_BATCHID     AS batch_id
        FROM DHA16_VIOLTHERMAL v
        LEFT JOIN DHA15_ANAGTHERM p ON p.DHA15_CODICE = v.DHA16_CODICE_DHA15
        WHERE v.DHA16_CODICE_DHA05 = ?
          AND v.DHA16_DATETIME >= DATEADD(hour, -{hours}, GETDATE())
        ORDER BY v.DHA16_DATETIME ASC
    """
    return _cache_compute("api.driver.thermal_vitals", 30, lambda: safe_query(sql, params=[driver_id]), driver_id, hours)


@app.get("/api/driver/{driver_id}/perclos-history")
def api_driver_perclos(driver_id: int, hours: int = Query(48, ge=1, le=720)):
    """Storico PERCLOS da DHA19_VIOLAI."""
    sql = f"""
        SELECT TOP 2000
            v.DHA19_DATETIME  AS dt,
            v.DHA19_PARAM     AS param,
            TRY_CAST(v.DHA19_VALUE AS FLOAT) AS valore,
            v.DHA19_STATUS    AS status,
            v.DHA19_BATCHID   AS batch_id
        FROM DHA19_VIOLAI v
        WHERE v.DHA19_CODICE_DHA05 = ?
          AND v.DHA19_DATETIME >= DATEADD(hour, -{hours}, GETDATE())
          AND v.DHA19_PARAM = 'perclos'
        ORDER BY v.DHA19_DATETIME ASC
    """
    return _cache_compute("api.driver.perclos", 30, lambda: safe_query(sql, params=[driver_id]), driver_id, hours)


@app.get("/api/driver/{driver_id}/daily-summary")
def api_driver_daily_summary(driver_id: int, days: int = Query(30, ge=1, le=90)):
    """Riepilogo giornaliero score AI per confronto giorni."""
    sql = f"""
        SELECT
            CAST(r.DHA17_DATAEORA AS DATE)  AS giorno,
            COUNT(*)                         AS n_risposte,
            AVG(TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score') AS FLOAT)) AS score_medio,
            MAX(TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score') AS FLOAT)) AS score_max,
            SUM(CASE WHEN TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.alert_required') AS BIT) = 1 THEN 1 ELSE 0 END) AS n_alert,
            SUM(CASE WHEN TRY_CAST(COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')) AS INT) = 2 THEN 1 ELSE 0 END) AS n_l2,
            SUM(CASE WHEN TRY_CAST(COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')) AS INT) = 3 THEN 1 ELSE 0 END) AS n_l3
        FROM DHA17_RESPONSES r
        WHERE r.DHA17_CODICE_DHA05 = ?
          AND r.DHA17_DATAEORA >= DATEADD(day, -{days}, GETDATE())
        GROUP BY CAST(r.DHA17_DATAEORA AS DATE)
        ORDER BY giorno ASC
    """
    return _cache_compute("api.driver.daily_summary", 60, lambda: safe_query(sql, params=[driver_id]), driver_id, days)


def _build_driver_responses_payload(driver_id: int, limit: int) -> list[dict]:
    batch_expr = (
        "NULLIF(LTRIM(RTRIM(CAST("
        "COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.batch_id'),"
        "JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.batch_id'))"
        " AS NVARCHAR(100)))),'')"
    )
    sql = f"""
        SELECT TOP {limit}
            r.DHA17_CODICE       AS codice,
            r.DHA17_DATAEORA     AS timestamp,
            r.DHA17_DATAEORA     AS dataora,
            r.DHA17_WSIARESPONSE AS wsiaresponse,
            {batch_expr}         AS batch_id,
            e.DHA18_ESITO        AS esito
        FROM DHA17_RESPONSES r
        LEFT JOIN DHA18_ESITI e
               ON NULLIF(LTRIM(RTRIM(CAST(e.DHA18_IDRESPONSE AS NVARCHAR(100)))),'')
                = {batch_expr}
        WHERE r.DHA17_CODICE_DHA05 = ?
        ORDER BY r.DHA17_DATAEORA DESC
    """
    return _cache_compute("api.driver.responses", 30, lambda: safe_query(sql, params=[driver_id]), driver_id, limit)


@app.get("/api/driver/{driver_id}/responses")
def api_driver_responses(request: Request, driver_id: int, limit: int = Query(20, ge=1, le=100)):
    _require_private_if_configured(request)
    return _build_driver_responses_payload(driver_id, limit)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/archivio/*  â€” Archivio Storico
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

@app.get("/api/archivio/drivers")
def api_archivio_drivers(days: int = Query(90, ge=1, le=365)):
    """Lista conducenti con statistiche aggregate per l'archivio storico."""
    sql = f"""
        SELECT
            u.DHA05_CODICE                  AS id_conducente,
            a.DHA01_NOME                    AS nome,
            a.DHA01_COGNOME                 AS cognome,
            COUNT(r.DHA17_CODICE)           AS n_sessioni,
            COUNT(DISTINCT CAST(r.DHA17_DATAEORA AS DATE)) AS n_giorni,
            AVG(TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score') AS FLOAT)) AS score_medio,
            MAX(TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score') AS FLOAT)) AS score_max,
            SUM(CASE WHEN TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.alert_required') AS BIT) = 1 THEN 1 ELSE 0 END) AS n_alert,
            SUM(CASE WHEN TRY_CAST(COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')) AS INT) = 2 THEN 1 ELSE 0 END) AS n_l2,
            SUM(CASE WHEN TRY_CAST(COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')) AS INT) = 3 THEN 1 ELSE 0 END) AS n_l3,
            MIN(r.DHA17_DATAEORA)           AS prima_sessione,
            MAX(r.DHA17_DATAEORA)           AS ultima_sessione
        FROM DHA05_USRFRAGILE u
        LEFT JOIN DHA01_ANAGGEN a ON a.DHA01_CODICE = u.DHA05_CODICE_DHA01
        LEFT JOIN DHA17_RESPONSES r
               ON r.DHA17_CODICE_DHA05 = u.DHA05_CODICE
              AND r.DHA17_DATAEORA >= DATEADD(day, -{days}, GETDATE())
        GROUP BY u.DHA05_CODICE, a.DHA01_NOME, a.DHA01_COGNOME
        ORDER BY n_alert DESC, n_sessioni DESC
    """
    return _cache_compute("api.archivio.drivers", 60, lambda: safe_query(sql), days)


@app.get("/api/archivio/overview")
def api_archivio_overview(driver_id: int, days: int = Query(90, ge=1, le=365)):
    """KPI aggregate + trend giornaliero per un conducente."""
    def _build():
        # KPI totali
        sql_kpi = f"""
        SELECT
            COUNT(*)                         AS n_sessioni,
            COUNT(DISTINCT CAST(r.DHA17_DATAEORA AS DATE)) AS n_giorni,
            AVG(TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score') AS FLOAT)) AS score_medio,
            MAX(TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score') AS FLOAT)) AS score_max,
            MIN(TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score') AS FLOAT)) AS score_min,
            SUM(CASE WHEN TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.alert_required') AS BIT) = 1 THEN 1 ELSE 0 END) AS n_alert,
            SUM(CASE WHEN TRY_CAST(COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')) AS INT) = 0 THEN 1 ELSE 0 END) AS n_l0,
            SUM(CASE WHEN TRY_CAST(COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')) AS INT) = 1 THEN 1 ELSE 0 END) AS n_l1,
            SUM(CASE WHEN TRY_CAST(COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')) AS INT) = 2 THEN 1 ELSE 0 END) AS n_l2,
            SUM(CASE WHEN TRY_CAST(COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')) AS INT) = 3 THEN 1 ELSE 0 END) AS n_l3,
            MIN(r.DHA17_DATAEORA) AS prima_sessione,
            MAX(r.DHA17_DATAEORA) AS ultima_sessione
        FROM DHA17_RESPONSES r
        WHERE r.DHA17_CODICE_DHA05 = ?
          AND r.DHA17_DATAEORA >= DATEADD(day, -{days}, GETDATE())
    """
        kpi_rows = safe_query(sql_kpi, params=[driver_id])
        kpi = kpi_rows[0] if kpi_rows else {}

        # Trend giornaliero
        sql_trend = f"""
        SELECT
            CAST(r.DHA17_DATAEORA AS DATE)   AS giorno,
            COUNT(*)                          AS n_sessioni,
            AVG(TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score') AS FLOAT)) AS score_medio,
            MAX(TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score') AS FLOAT)) AS score_max,
            SUM(CASE WHEN TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.alert_required') AS BIT) = 1 THEN 1 ELSE 0 END) AS n_alert,
            SUM(CASE WHEN TRY_CAST(COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')) AS INT) >= 2 THEN 1 ELSE 0 END) AS n_critico
        FROM DHA17_RESPONSES r
        WHERE r.DHA17_CODICE_DHA05 = ?
          AND r.DHA17_DATAEORA >= DATEADD(day, -{days}, GETDATE())
        GROUP BY CAST(r.DHA17_DATAEORA AS DATE)
        ORDER BY giorno ASC
    """
        trend = safe_query(sql_trend, params=[driver_id])

        return {"kpi": kpi, "trend": trend}

    return _cache_compute("api.archivio.overview", 60, _build, driver_id, days)


@app.get("/api/archivio/records")
def api_archivio_records(
    driver_id: Optional[int] = Query(None),
    days: int = Query(90, ge=1, le=365),
    limit: int = Query(500, ge=1, le=2000),
    level: Optional[int] = Query(None),
    alert_only: bool = Query(False)
):
    """Record storici dettagliati con filtri."""
    level_filter = f"AND TRY_CAST(COALESCE(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')) AS INT) = {level}" if level is not None else ""
    alert_filter = "AND TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.alert_required') AS BIT) = 1" if alert_only else ""
    driver_filter = "AND r.DHA17_CODICE_DHA05 = ?" if driver_id is not None else ""
    params = [driver_id] if driver_id is not None else []

    sql = f"""
        SELECT TOP {limit}
            r.DHA17_CODICE      AS id,
            r.DHA17_CODICE_DHA05 AS id_conducente,
            a.DHA01_NOME        AS nome,
            a.DHA01_COGNOME     AS cognome,
            r.DHA17_DATAEORA    AS dataora,
            TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.final_score') AS FLOAT) AS final_score,
            TRY_CAST(COALESCE(
                JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.level'),
                JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.ai_level')
            ) AS INT) AS ai_level,
            TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.alert_required') AS BIT) AS alert_required,
            JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.summary.scenario')       AS scenario,
            TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.ppg.score') AS FLOAT)   AS ppg_score,
            TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.thermal.score') AS FLOAT) AS thermal_score,
            TRY_CAST(JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.vision.score') AS FLOAT) AS vision_score,
            e.DHA18_ESITO       AS esito
        FROM DHA17_RESPONSES r
        LEFT JOIN DHA05_USRFRAGILE u ON u.DHA05_CODICE = r.DHA17_CODICE_DHA05
        LEFT JOIN DHA01_ANAGGEN    a ON a.DHA01_CODICE = u.DHA05_CODICE_DHA01
        LEFT JOIN DHA18_ESITI e ON NULLIF(LTRIM(RTRIM(CAST(e.DHA18_IDRESPONSE AS NVARCHAR(100)))),'')
            = NULLIF(LTRIM(RTRIM(CAST(COALESCE(
                JSON_VALUE(r.DHA17_WSIARESPONSE,'$.batch_id'),
                JSON_VALUE(r.DHA17_WSIARESPONSE,'$.ia_response.batch_id')
            ) AS NVARCHAR(100)))),'' )
        WHERE r.DHA17_DATAEORA >= DATEADD(day, -{days}, GETDATE())
          {driver_filter}
          {level_filter}
          {alert_filter}
        ORDER BY r.DHA17_DATAEORA DESC
    """
    return _cache_compute("api.archivio.records", 30, lambda: safe_query(sql, params=params), driver_id, days, limit, level, alert_only)


# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔
# ENDPOINT /api/training/*  â€” Training AI via Web (no Docker, no CLI)
# ╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔╔

_train_proc: subprocess.Popen | None = None
_train_log: list[str] = []
_train_status: dict = {"running": False, "exit_code": None, "started_at": None, "mode": None}
_train_lock = threading.Lock()


def _read_proc_output(proc: subprocess.Popen):
    """Thread che legge stdout del processo training e lo accumula in _train_log."""
    global _train_status
    try:
        for line in proc.stdout:
            _train_log.append(line.rstrip("\n\r"))
    finally:
        proc.wait()
        with _train_lock:
            _train_status["running"]   = False
            _train_status["exit_code"] = proc.returncode
        logging.info(f"Training completato con exit code {proc.returncode}")


@app.post("/api/training/start")
def api_training_start(request: Request, mode: str = Query("full", regex="^(full|smoke)$")):
    """Avvia train_all.py in background e streamma l'output via /api/training/log."""
    global _train_proc, _train_log, _train_status

    with _train_lock:
        if _train_status["running"]:
            raise HTTPException(409, "Training giÃ  in esecuzione. Attendi il completamento.")

        script = _ROOT / "train_all.py"
        if not script.exists():
            raise HTTPException(404, "Script training non trovato. Carica train_all.py nella cartella del progetto.")

        _train_log.clear()
        _train_status = {
            "running":    True,
            "exit_code":  None,
            "started_at": _dt2.datetime.now().isoformat(timespec="seconds"),
            "mode":       mode,
        }

        args = [sys.executable, str(script)]
        if mode == "smoke":
            args.append("--smoke")

        try:
            _train_proc = subprocess.Popen(
                args,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                cwd=str(_ROOT),
                encoding="utf-8",
                errors="replace",
            )
        except Exception as exc:
            _train_status["running"] = False
            _log.error("Impossible to start training process: %s", exc, exc_info=False)
            raise HTTPException(500, "Impossibile avviare il processo di training.")

    t = threading.Thread(target=_read_proc_output, args=(_train_proc,), daemon=True)
    t.start()
    return {"ok": True, "mode": mode, "started_at": _train_status["started_at"]}


@app.post("/api/training/stop")
def api_training_stop(request: Request):
    """Termina il processo training se in esecuzione."""
    global _train_proc
    if _train_proc and _train_status["running"]:
        _train_proc.terminate()
        return {"ok": True, "message": "Segnale SIGTERM inviato al processo."}
    raise HTTPException(400, "Nessun training in corso.")


@app.get("/api/training/status")
def api_training_status_ep(request: Request):
    """Stato corrente del training."""
    return {**_train_status, "log_lines": len(_train_log)}


@app.get("/api/training/log")
def api_training_log(request: Request, offset: int = Query(0, ge=0)):
    """Righe di log dalla posizione offset in poi (per polling incrementale)."""
    return {
        "lines":   _train_log[offset:],
        "total":   len(_train_log),
        "running": _train_status["running"],
        "exit_code": _train_status["exit_code"],
    }
