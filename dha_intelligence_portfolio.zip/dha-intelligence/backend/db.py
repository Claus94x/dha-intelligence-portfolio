﻿"""
db.py â€” Connessione SQL Server per DHA Intelligence v1.
Legge la stringa di connessione da variabile d'ambiente o file .env.
"""
from __future__ import annotations

import json
import os
import logging
from contextlib import contextmanager
from typing import Optional

import pyodbc
import pandas as pd
from dotenv import load_dotenv

load_dotenv()  # carica .env se presente

_log = logging.getLogger("dha.db")

# The connection string must come from the environment.
_CONN_ENV_KEYS = ("DHA_DB_CONNECTION_STRING", "DHA_CONN_STR")


def get_conn_str() -> str:
    """Recupera la stringa di connessione da env senza fallback segreti."""
    for key in _CONN_ENV_KEYS:
        value = os.environ.get(key, "").strip()
        if value:
            return value
    raise RuntimeError(
        "Missing database connection string. Set DHA_DB_CONNECTION_STRING "
        "(or DHA_CONN_STR) in .env."
    )


# â”€â”€â”€ Context manager connessione â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@contextmanager
def get_db():
    """Apre e chiude la connessione pyodbc in modo sicuro."""
    conn = pyodbc.connect(get_conn_str(), timeout=10)
    try:
        yield conn
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# â”€â”€â”€ Helper query â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

def safe_query(sql: str, params: Optional[list] = None) -> list[dict]:
    """
    Esegue una SELECT e restituisce una lista di dict (JSON-serializzabile).
    Restituisce [] in caso di errore.
    """
    try:
        with get_db() as conn:
            df = pd.read_sql(sql, conn, params=params or [])
        # datetime â†’ stringa ISO
        for col in df.select_dtypes(include=["datetime64[ns]", "datetimetz"]).columns:
            df[col] = df[col].dt.strftime("%Y-%m-%dT%H:%M:%S")
        # Usa un passaggio JSON intermedio per normalizzare NaN/NaT in null
        # e restituire valori sempre serializzabili da FastAPI.
        return json.loads(df.to_json(orient="records", date_format="iso"))
    except Exception as exc:
        _log.error("DB query error: %s", exc, exc_info=False)
        return []


def test_connection() -> tuple[bool, str]:
    """Verifica la raggiungibilitÃ  del database."""
    try:
        with get_db() as conn:
            conn.cursor().execute("SELECT 1")
        return True, "Database raggiungibile"
    except pyodbc.Error as exc:
        raw = str(exc)
        if "53" in raw or "named pipe" in raw.lower():
            msg = "Server SQL non raggiungibile (err 53). Verificare rete/VPN."
        elif "timeout" in raw.lower():
            msg = "Timeout di connessione."
        elif "login" in raw.lower() or "28000" in raw:
            msg = "Credenziali non valide."
        else:
            _log.warning("DB connection failed: %s", raw, exc_info=False)
            msg = "Connessione al database non disponibile."
        return False, msg
    except Exception as exc:
        _log.error("Unexpected DB connection error: %s", exc, exc_info=False)
        return False, "Connessione al database non disponibile."

