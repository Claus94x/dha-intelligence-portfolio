@echo off
REM --- DHA Intelligence v1 - Avvio locale (Windows) ---
cd /d "%~dp0"
echo.
echo  =========================================
echo   DHA Intelligence v1 - Biometric OS
echo  =========================================
echo.
echo  Avvio backend...
echo.

REM Attiva virtualenv se presente
if exist ".venv\Scripts\activate.bat" (
    call .venv\Scripts\activate.bat
    echo  [OK] Virtualenv attivato
) else (
    echo  [!] Nessun virtualenv trovato, uso Python di sistema
)

if not defined PORT set "PORT=7001"

REM Installa dipendenze se necessario
echo  Verifica dipendenze...
pip install -r backend\requirements.txt -q

REM Avvio server
echo.
echo  Server disponibile su: http://localhost:%PORT%
echo  Premi CTRL+C per fermare.
echo.
uvicorn backend.main:app --host 0.0.0.0 --port %PORT% --reload
pause
