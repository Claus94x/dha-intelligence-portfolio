# Guida Utente Completa

Questa guida descrive la versione attuale della piattaforma: pagine, grafici, dati letti, indicazioni operative e tabelle SQL o fonti locali da cui arrivano.

Se un elemento non legge il database ma usa file locali o stato del sistema, lo trovi segnato come "fonte locale".

## Legenda Rapida

- `Normale` / `L0`: situazione sotto controllo.
- `Attenzione` / `L1`: da monitorare, il rischio sta salendo.
- `Allerta` / `L2`: serve attenzione concreta e possibile intervento.
- `Critico` / `L3`: situazione grave, priorita alta.

## Fonti Dati Principali

- `V_DHA_DASHBOARD`: vista unificata usata per gran parte dei dati di flotta e dei trend.
- `DHA17_RESPONSES`: archivio delle risposte AI, con score, livello, raccomandazioni e metadati JSON.
- `DHA18_ESITI`: esiti/chiusura degli alert e delle risposte.
- `DHA13_ALERT`: alert operativi.
- `DHA11_MONITOR`: monitoraggio vitale (HR, SpO2, RR, temperatura).
- `DHA16_VIOLTHERMAL`: violazioni o stress termico per zona.
- `DHA19_VIOLAI`: violazioni AI video, PERCLOS e segnali visivi.
- `DHA05_USRFRAGILE`: anagrafica/associazione del conducente.
- `DHA01_ANAGGEN`: anagrafica generale.
- `DHA10_ANAGPARMON`: parametri del monitor.
- `DHA15_ANAGTHERM`: anagrafica zone termiche.
- `DHA06_ANAMNESI_TESTA`, `DHA07_ANAMNESI_CORPO`, `DHA08_DIAGNOSI`: anamnesi e diagnosi.
- `DHA_TERAPIE_LIVE`: terapie attive o storiche.
- `DHA_ML_PREDICTIONS`: storico predizioni ML.
- `models/production_model.json`: registry di produzione.
- `models/*.joblib`: artefatti modello, in particolare XGBoost.
- `models/*training_report*.json`: report training.
- `train_all.py`: pipeline di training.

## 1. Dashboard Hub (`index.html`)

Questa e la vista di sintesi della flotta. Serve per capire subito come sta andando il parco conducenti, dove ci sono criticita e se il rischio medio si sta spostando verso l'alto.

| Elemento | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| Conducenti Attivi | numero di conducenti con dati nel periodo selezionato | `GET /api/kpi` -> `V_DHA_DASHBOARD` | Ti dice quanti conducenti sono effettivamente osservati in quel periodo |
| In Stato Normale | conducenti sotto la soglia bassa di rischio | `GET /api/kpi` -> `V_DHA_DASHBOARD` | Se cala, la flotta sta peggiorando |
| In Attenzione/Allerta | conducenti nella fascia intermedia di rischio | `GET /api/kpi` -> `V_DHA_DASHBOARD` | Segnale di peggioramento progressivo |
| In Stato Critico | conducenti sopra la soglia critica | `GET /api/kpi` -> `V_DHA_DASHBOARD` | Richiede presa in carico immediata |
| Rischio Medio Flotta | media del rischio complessivo della flotta | `GET /api/kpi` -> `V_DHA_DASHBOARD` | Se sale, la flotta sta diventando piu instabile |
| Alert AI Pendenti | risposte AI con `alert_required=true` e senza esito | `GET /api/alerts/ai-pending` -> `DHA17_RESPONSES` + `DHA18_ESITI` | Ti mostra gli alert ancora da chiudere |
| Alert Operativi | eventi operativi unici aperti nel periodo | `GET /api/alerts` -> `DHA13_ALERT`, `DHA11_MONITOR`, `DHA16_VIOLTHERMAL`, `DHA19_VIOLAI`, esclusi gli esiti gia gestiti in `DHA18_ESITI` | Ti dice dove c'e lavoro operativo reale |
| Distribuzione Rischio | donut con `Normale`, `Attenzione`, `Allerta`, `Critico` | `GET /api/kpi` -> `V_DHA_DASHBOARD` | Se il rosso cresce, la flotta si sta spostando verso zone di rischio alte |
| Andamento Rischio Medio | linea del rischio medio nel tempo | `GET /api/trend` -> `V_DHA_DASHBOARD` | Fa vedere se il problema e stabile, in salita o in discesa |
| Conducenti - Stato Attuale | tabella con il record piu recente per conducente | `GET /api/drivers` -> `V_DHA_DASHBOARD` + `DHA05_USRFRAGILE` + `DHA01_ANAGGEN` | Ti fa vedere chi va attenzionato per primo |
| Feed Operativo | lista degli alert aperti e recenti | `GET /api/alerts` -> tabelle di alert e monitor | Ti mostra gli eventi da aprire o chiudere operativamente |

Note utili:
- Il donut e il trend sono i due grafici da guardare per primi.
- Se il trend sale e il donut si colora sempre piu di rosso, la situazione generale sta peggiorando.
- La tabella conducenti e ordinata per rischio, quindi i casi piu urgenti stanno in alto.

## 2. Monitor Real-Time (`realtime.html`)

Questa pagina non ha grafici. E una vista operativa "adesso", pensata per vedere cosa sta succedendo in tempo quasi reale.

| Sezione | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| KPI live e schede stato | conteggi e stato corrente dei driver | `GET /api/drivers` + `GET /api/alerts` | Ti dice chi e online, chi e fuori soglia e dove ci sono urgenze |
| Watchlist | conducenti fissati dall'utente | `localStorage` del browser | Serve per seguire i nomi piu importanti senza cercarli ogni volta |
| Driver grid | card riassuntive per conducente | `V_DHA_DASHBOARD` via `/api/drivers` | Fa vedere a colpo d'occhio il profilo corrente |
| Alert pendenti / urgenti | elenco eventi che richiedono attenzione | `DHA13_ALERT`, `DHA11_MONITOR`, `DHA16_VIOLTHERMAL`, `DHA19_VIOLAI` | Ti dice dove intervenire subito |

Note utili:
- La watchlist non viene salvata su SQL, ma solo nel browser.
- Questa pagina e la piu adatta per il controllo continuo durante la giornata.

## 3. Analisi Clinica (`analisi_clinica.html`)

Questa e la pagina piu importante per capire un singolo conducente: unisce rischio, segnali fisiologici, segnali video, terapie, diagnosi e output del modello.

| Elemento | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| Gauge Rischio Corrente | ultimo rischio disponibile nel periodo | `GET /api/driver/{id}/timeline` -> `V_DHA_DASHBOARD` | Ti dice lo stato attuale del conducente |
| Gauge Rischio Massimo | picco piu alto nella finestra selezionata | `GET /api/driver/{id}/timeline` -> `V_DHA_DASHBOARD` | Serve per capire se ci sono stati momenti critici anche brevi |
| Gauge Rischio Medio | media del rischio nella finestra | `GET /api/driver/{id}/timeline` -> `V_DHA_DASHBOARD` | Misura il carico complessivo, non solo il picco |
| Timeline Rischio / Sonno / PPG / Termica | andamento delle componenti che entrano nel punteggio | `GET /api/driver/{id}/timeline` -> `V_DHA_DASHBOARD` | Se una curva sale prima delle altre, puoi capire da dove parte il problema |
| Grafico Vitali | HR, SpO2, temperatura e frequenza respiratoria | `GET /api/driver/{id}/timeline` -> `V_DHA_DASHBOARD` | Ti aiuta a capire se il rischio e accompagnato da stress fisiologico |
| Grafico Visivi | EAR, PERCLOS, MAR, head pitch, blink freq, eye stability | `GET /api/driver/{id}/timeline` -> `V_DHA_DASHBOARD` | Ti dice se ci sono segnali di affaticamento visivo o postura anomala |
| XGBoost Short Term | storico recente + previsione breve del modello | `GET /api/driver/{id}/model-score?days=30` + registry locale | Ti mostra il rischio che il modello sta stimando nel breve periodo |
| Feature Importance XGBoost | importanza delle feature nel modello attivo | `GET /api/ml/feature-importance` -> artefatto XGBoost locale | Ti dice quali segnali pesano di piu sulla decisione |
| XGBoost Daily | media e picco giornalieri del rischio | `GET /api/driver/{id}/daily-summary?days=30` -> `DHA17_RESPONSES` | Ti fa vedere l'evoluzione giorno per giorno |
| Terapie | elenco terapie associate | `GET /api/driver/{id}/therapies` -> `DHA_TERAPIE_LIVE` | Ti mostra le terapie rilevanti o attive |
| Violazioni AI | eventi di violazione AI video | `GET /api/driver/{id}/ai-violations` -> `DHA19_VIOLAI` | Ti aiuta a collegare il rischio al video/occhi |
| Violazioni Termiche | stress o violazioni termiche per zona | `GET /api/driver/{id}/thermal-violations` -> `DHA16_VIOLTHERMAL` + `DHA15_ANAGTHERM` | Ti dice se la parte termica ha contribuito al rischio |
| Diagnosi | anamnesi e diagnosi del conducente | `GET /api/driver/{id}/diagnoses` -> `DHA05_USRFRAGILE`, `DHA06_ANAMNESI_TESTA`, `DHA07_ANAMNESI_CORPO`, `DHA08_DIAGNOSI` | Serve per leggere il contesto clinico del caso |
| Risposte | dettaglio delle risposte AI e del loro esito | `GET /api/driver/{id}/responses` -> `DHA17_RESPONSES` + `DHA18_ESITI` | Ti mostra come e stata trattata ogni risposta |
| Registry modello | modello in produzione e motivazione | `GET /api/ml/registry` -> `models/production_model.json` | Ti spiega quale modello sta lavorando e perche |

Indicazioni pratiche:
- Se il gauge corrente e alto ma il medio e basso, hai un picco isolato.
- Se rischio, PPG, termica e visivi crescono insieme, il problema e multi-fattore.
- Se il grafico visivi sale prima degli altri, il segnale di affaticamento arriva prima dalla parte video.
- Se il modello breve termine prevede una salita, conviene attenzionare il conducente prima del picco.

## 4. Archivio Storico (`archivio_storico.html`)

Questa pagina e pensata per analisi nel tempo: quante sessioni ci sono state, come evolve il punteggio, quanti alert si accumulano e quali giorni sono peggiori.

| Elemento | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| KPI Fleet Overview | conducenti, sessioni, score medio, alert, L2, L3 | `GET /api/archivio/overview` -> `DHA17_RESPONSES` + `DHA18_ESITI` + `DHA05_USRFRAGILE` + `DHA01_ANAGGEN` | Ti dice la fotografia storica della flotta |
| Trend Score AI - Giornaliero | score medio e score massimo per giorno | `GET /api/archivio/overview` | Serve per capire se il rischio storico cresce o si stabilizza |
| Distribuzione Livelli AI | donut L0/L1/L2/L3 | `GET /api/archivio/overview` | Ti fa vedere la distribuzione dei livelli nel tempo |
| Sessioni Giornaliere & Alert | sessioni, alert, L2+L3 per giorno | `GET /api/archivio/overview` | Ti mostra dove si concentrano gli eventi critici |
| Analisi Individuale | KPI e grafici del conducente selezionato | `GET /api/archivio/overview?driver_id=...` | Serve per confrontare i singoli conducenti |
| Registro Sessioni | tabella record dettagliati con filtri | `GET /api/archivio/records` -> `DHA17_RESPONSES` + `DHA18_ESITI` | Utile per audit e ricerca di sessioni specifiche |

Indicazioni pratiche:
- Se il grafico dei livelli mostra molte L2/L3, la flotta o il conducente hanno una criticita storica non episodica.
- Se le sessioni aumentano ma lo score resta sotto controllo, la situazione e stabile.
- Se gli alert crescono piu delle sessioni, il sistema sta vedendo piu problemi per ogni sessione.

## 5. Alert & Performance AI (`alert.html`)

Questa pagina non parla del conducente in se, ma della qualita del sistema di alert: quante volte l'AI sbaglia, quando si attiva, e come si distribuisce il comportamento per livello.

| Elemento | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| Confusion Matrix | confronto tra alert attesi e alert gestiti | `GET /api/alerts/analysis` -> `DHA17_RESPONSES` + `DHA18_ESITI` | Ti dice se il sistema tende a centrare o mancare gli alert |
| Alert per Livello | `Alert True`, `Alert False`, `Gestiti` per L0-L3 | `GET /api/alerts/analysis` | Ti fa capire su quali livelli il sistema si comporta meglio o peggio |
| TP/FP/FN/TN per Livello | conteggio vero/falso positivo/negativo | `GET /api/alerts/analysis` | Serve per valutare il bilanciamento del modello |
| Performance per Scenario | performance per scenario rilevato nel JSON | `GET /api/alerts/analysis` | Ti mostra se alcuni scenari sono piu difficili di altri |
| Score Distribution | scatter score finale vs livello AI | `GET /api/alerts/analysis` | Verifica quanto bene il punteggio si separa tra le classi |
| Tabella Range Score | fasce score per livello e alert | `GET /api/alerts/analysis` | Aiuta a leggere le soglie operative |
| Trend Giornaliero Alert | alert true/false per giorno | `GET /api/alerts/analysis` | Ti mostra se il numero di alert sta salendo o scendendo |
| Tabella Dettaglio | record completi filtrabili | `GET /api/alerts/analysis` | Utile per audit e controllo puntuale |

Indicazioni pratiche:
- Molti FP significano che il sistema segnala troppo.
- Molti FN significano che il sistema perde situazioni importanti.
- Se lo scatter e molto distante dalla linea perfetta, il modello va rivisto.

## 6. Deep Analysis (`deep_analysis.html`)

Questa e la pagina piu tecnica: serve per capire il perche del punteggio e non solo il punteggio finale.

### Tab 0 - Timeline

| Grafico | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| Andamento Final Score nel Tempo | score finale di ogni risposta | `GET /api/driver/{id}/deep-responses` -> `DHA17_RESPONSES` + `DHA18_ESITI` | Ti mostra dove nasce il picco di rischio |
| Distribuzione Livelli | conteggio L0/L1/L2/L3 | stesso endpoint | Ti dice quanto tempo il conducente passa nelle varie fasce |
| Fasi Affaticamento L2/L3 | durata degli episodi consecutivi critici | stesso endpoint | Ti fa vedere se i picchi sono brevi o persistenti |

### Tab 1 - Root Cause

| Grafico | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| Score per Sensore nel Tempo | score PPG, termico e AI video | stesso endpoint | Ti dice quale sottosistema spinge il rischio |
| Stati PPG | distribuzione o stato delle componenti PPG | stesso endpoint | Aiuta a capire se il problema e cardiocircolatorio o di segnale |
| Stati Thermal | distribuzione dello stato termico | stesso endpoint | Evidenzia il contributo termico |
| Stati AI Video | distribuzione dello stato video | stesso endpoint | Evidenzia il contributo visivo |

### Tab 2 - Vitals

| Grafico | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| RR Interval & BPM | intervallo respiratorio e battiti | `GET /api/driver/{id}/monitor-vitals` -> `DHA11_MONITOR` + `DHA10_ANAGPARMON` | Ti mostra il carico fisiologico |
| SpO2 nel Tempo | saturazione ossigeno | stesso endpoint | Se scende, c'e una criticita fisiologica da controllare |
| Score Termici per Zona | stress termico nelle zone monitorate | `GET /api/driver/{id}/thermal-vitals` -> `DHA16_VIOLTHERMAL` + `DHA15_ANAGTHERM` | Ti dice quale zona termica e piu problematica |

### Tab 3 - PERCLOS

| Grafico / tabella | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| PERCLOS nel Tempo | PERCLOS da entrambe le fonti disponibili | `GET /api/driver/{id}/perclos-history` -> `DHA19_VIOLAI` + dati deep responses | Misura l'affaticamento visivo |
| Distribuzione Valori PERCLOS | istogramma dei valori | stesso endpoint | Ti dice se il conducente resta su valori bassi o entra spesso in fascia alta |
| Top 10 eventi PERCLOS | episodi con PERCLOS piu alto | stesso endpoint | Ti fa vedere gli episodi piu critici |

### Tab 4 - Quality

| Grafico | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| Warmup Status | conteggio per stato di warmup | `GET /api/driver/{id}/deep-responses` -> `DHA17_RESPONSES` | Ti dice se il dato e maturato o ancora in avvio |
| Data Quality | conteggio dei valori di qualita | stesso endpoint | Ti fa vedere se il dato e pulito o rumoroso |
| Face Detection Rate | tasso di rilevamento volto nel tempo | stesso endpoint | Se e basso, la parte video e meno affidabile |

### Tab 5 - Recommendations

| Grafico / lista | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| Top 10 Raccomandazioni | messaggi piu frequenti | `GET /api/driver/{id}/deep-responses` -> `DHA17_RESPONSES` | Ti dice cosa consiglia il sistema piu spesso |
| Distribuzione per Priorita | HIGH / MEDIUM / LOW | stesso endpoint | Ti mostra quante raccomandazioni sono urgenti |
| Ultimi 8 messaggi unici | ultime raccomandazioni distinte | stesso endpoint | Ti aiuta a leggere gli interventi piu recenti |

### Tab 6 - Confronto Giorni

| Grafico / tabella | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| Score Giornaliero | score medio e picco per giorno | `GET /api/driver/{id}/daily-summary?days=30` -> `DHA17_RESPONSES` | Ti fa vedere i giorni peggiori |
| Alert e L3 per Giorno | numero alert e L3 per giorno | stesso endpoint | Ti dice se i picchi coincidono con le giornate piu difficili |
| Riepilogo Giornaliero | tabella riepilogo | stesso endpoint | Ti fa un audit veloce del periodo |

Indicazioni pratiche:
- Se i segnali video salgono prima dei vitali, il problema nasce prima dalla parte visiva.
- Se le raccomandazioni HIGH crescono, il caso richiede piu attenzione.
- Se la qualita dati e bassa, i grafici vanno letti con piu cautela.

## 7. AI Lab (`ai_lab.html`)

Questa pagina serve per capire il modello, non il conducente.

| Elemento | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| Feature Importance - Top 20 | importanza delle feature del modello | fonte locale: `models/*.joblib` tramite `/api/ml/feature-importance` | Ti dice quali segnali il modello usa di piu |
| Distribuzione per Categoria | raggruppamento delle feature per famiglia | fonte locale: modello XGBoost | Ti fa capire se il peso del modello e piu clinico, video o termico |
| KPI Performance ML | predizioni totali, MAE, driver coperti, modelli attivi | `GET /api/ml/predictions?days=7` -> `DHA_ML_PREDICTIONS` | Misura la qualita dell'ultima finestra di predizioni |
| Trend MAE Giornaliero per Modello | errore assoluto medio per giorno e per modello | `DHA_ML_PREDICTIONS` | Se cresce, c'e drift o peggioramento del modello |
| Predetto vs Reale | scatter predetto/rilevato per modello | `DHA_ML_PREDICTIONS` | Ti mostra se il modello e ben allineato alla realta |
| Confronto XGBoost vs LSTM | radar comparativo concettuale | dati di registry e valori illustrativi nel front-end | Non e un calcolo SQL: serve a spiegare il trade-off tra i due modelli |
| Registry | modello in produzione, criteri selezione, training info, summary modelli | `models/production_model.json`, `models/*training_report*.json`, artefatti locali | Ti dice quale modello e attivo e perche |

Note utili:
- Il radar XGBoost vs LSTM e una vista concettuale, non una misura letta da SQL.
- Se il MAE sale nel tempo, il modello sta peggiorando e va ritrainato o controllato.

## 8. Sistema (`sistema.html`)

Questa pagina non mostra grafici. Serve per stato piattaforma, training e diagnostica del server.

| Sezione | Cosa pesca | Origine SQL / fonte | Indicazione operativa |
|---|---|---|---|
| Decisione attuale | modello in produzione, stato LSTM, latenza | `GET /api/ml/registry` + file locali | Ti dice quale modello sta lavorando e se la LSTM e pronta |
| Cosa fare ora | suggerimento operativo del sistema | calcolo front-end | Ti orienta se devi allenare, valutare o lasciare stabile |
| Prerequisiti | stato database, dipendenze, percorsi | `GET /api/system/info` + `GET /api/status` | Ti fa capire se l'ambiente e pronto |
| Avvio Training | stato della pipeline e terminale live | `train_all.py` tramite `/api/training/start` | Ti mostra l'avanzamento del training |
| Training Report | metriche e report dell'ultimo training | file locale in `models/` | Ti dice come e andato l'ultimo addestramento |
| Database | test connessione e informazioni base | `GET /api/system/info` | Ti conferma se il DB risponde |
| Dipendenze Python | librerie installate e mancanti | `GET /api/system/info` | Ti dice se l'ambiente e pronto a eseguire training o inferenza |
| Percorsi Configurati | cartelle e file usati dal sistema | `GET /api/system/info` | Utile per controllare dove il software legge e salva |
| Variabili d'Ambiente | configurazione runtime | `GET /api/system/info` + env | Ti fa vedere se la macchina e configurata bene |
| Info Sistema | OS, Python, memoria, paths | `GET /api/system/info` | Serve per troubleshooting e supporto |

Note utili:
- Questa pagina e quella da guardare prima di fare un training o un controllo di ambiente.
- Se il database non e raggiungibile, molte altre pagine possono mostrarsi parziali o vuote.

## 9. Riepilogo Veloce: quale pagina usare per cosa

- `index.html`: vedere subito la flotta nel suo insieme.
- `realtime.html`: controllare cosa sta succedendo ora.
- `analisi_clinica.html`: capire un singolo conducente e il motivo del suo rischio.
- `archivio_storico.html`: analisi storica e audit sui giorni passati.
- `alert.html`: valutare la qualita del sistema di alert.
- `deep_analysis.html`: root cause, segnali, qualita dato e raccomandazioni.
- `ai_lab.html`: spiegare il modello, confrontare XGBoost e LSTM, leggere la qualita delle predizioni.
- `sistema.html`: stato del server, training e diagnostica tecnica.

## 10. Tavola SQL di Riferimento

| Tabella / vista | Cosa contiene in pratica | Pagine che la usano |
|---|---|---|
| `V_DHA_DASHBOARD` | vista unificata con record operativi, score, livelli e trend temporali | Dashboard Hub, Realtime, Analisi Clinica, Archivio Storico, Deep Analysis |
| `DHA17_RESPONSES` | risposte AI, score finale, livello, alert, raccomandazioni, JSON di dettaglio | Analisi Clinica, Alert, Archivio Storico, Deep Analysis |
| `DHA18_ESITI` | esiti di lavorazione e chiusura alert | Dashboard, Alert, Archivio Storico, Analisi Clinica, Deep Analysis |
| `DHA13_ALERT` | alert operativi | Dashboard Hub, Realtime |
| `DHA11_MONITOR` | vitali e monitoraggio fisiologico | Analisi Clinica, Deep Analysis |
| `DHA10_ANAGPARMON` | anagrafica parametri monitor | Deep Analysis |
| `DHA16_VIOLTHERMAL` | stress/violazioni termiche | Analisi Clinica, Deep Analysis, Dashboard operativa indiretta |
| `DHA15_ANAGTHERM` | anagrafica zone termiche | Analisi Clinica, Deep Analysis |
| `DHA19_VIOLAI` | violazioni AI video e PERCLOS | Analisi Clinica, Alert, Deep Analysis, Archivio Storico |
| `DHA05_USRFRAGILE` | associazione conducente / soggetto | Dashboard, Analisi Clinica, Archivio Storico, Alert |
| `DHA01_ANAGGEN` | anagrafica generale | Dashboard, Analisi Clinica, Archivio Storico, Alert |
| `DHA06_ANAMNESI_TESTA` | anamnesi testa | Analisi Clinica |
| `DHA07_ANAMNESI_CORPO` | anamnesi corpo | Analisi Clinica |
| `DHA08_DIAGNOSI` | diagnosi | Analisi Clinica |
| `DHA_TERAPIE_LIVE` | terapie | Analisi Clinica |
| `DHA_ML_PREDICTIONS` | storico predizioni e confronto predetto/reale | AI Lab |

## 11. Fonti Locali Non SQL

| File o fonte | Cosa contiene | Pagine che la usano |
|---|---|---|
| `models/production_model.json` | registry di produzione e motivo della selezione | Analisi Clinica, AI Lab, Sistema |
| `models/*.joblib` | artefatto XGBoost e altri modelli salvati | Analisi Clinica, AI Lab |
| `models/*training_report*.json` | report del training | AI Lab, Sistema |
| `train_all.py` | pipeline di training | Sistema |
| `localStorage` del browser | watchlist e preferenze locali | Realtime |

Se vuoi leggere il sistema nel modo piu semplice possibile:
- apri prima `index.html` per la fotografia generale;
- poi `analisi_clinica.html` per il singolo conducente;
- poi `deep_analysis.html` se devi capire il perche del punteggio;
- infine `sistema.html` se devi verificare training, modelli o stato server.
